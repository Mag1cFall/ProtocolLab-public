package app

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/Mag1cFall/AIStudio2API/internal/aistudio"
	"github.com/Mag1cFall/AIStudio2API/internal/api"
	"github.com/Mag1cFall/AIStudio2API/internal/camoufoxnative"
	"github.com/Mag1cFall/AIStudio2API/internal/chromeauth"
)

type chromeCookieRefreshFunc func(context.Context, aistudio.AuthSource, aistudio.ChromeOAuthMaterial, string) ([]aistudio.StateCookie, *aistudio.BoundSession, error)

// boundRefreshThreshold 是 Chromium 主动刷新 DBSC 会话时绑定 Cookie 的剩余时间
const boundRefreshThreshold = 2 * time.Minute

// authRuntimeRefresher 使用账户保存的 Chrome OAuth 材料原地续签
type authRuntimeRefresher struct {
	pool          *aistudio.AccountPool
	refresh       chromeCookieRefreshFunc
	importCurrent func(context.Context, aistudio.AuthSource, *aistudio.ChromeOAuthMaterial, string) (aistudio.StorageState, error)
	chromeHas     func(string) bool
	reset         func(string) error
	prepareWorker func(*aistudio.Account, aistudio.AccountConfig) (*accountWorkerUpdate, error)
	// rotate 刷新账户的 DBSC 会话并返回响应 Cookie
	rotate func(context.Context, aistudio.StorageState, aistudio.AuthExtension, string) ([]string, error)
	// mergeWorker 把响应 Cookie 写入账户当前 Worker 的页面
	mergeWorker func(context.Context, string, []string, string) error
	// boundLocks 是各账户 DBSC 会话刷新的互斥锁
	boundLocks  sync.Map
	globalProxy string
	requests    *requestRegistry
}

// authRetryTransport 为普通 RPC 执行一次认证续签重试
type authRetryTransport struct {
	transport aistudio.RPCTransport
	refresher *authRuntimeRefresher
}

// authRetryProtectedTransport 为受保护 RPC 执行一次认证续签重试
type authRetryProtectedTransport struct {
	transport aistudio.ProtectedTransport
	refresher *authRuntimeRefresher
}

type bidiReleaseGate struct {
	mu        sync.Mutex
	once      sync.Once
	release   func() error
	requested bool
	committed bool
	abandoned bool
	err       error
}

func newBidiReleaseGate(release func() error) *bidiReleaseGate {
	return &bidiReleaseGate{release: release}
}

func (gate *bidiReleaseGate) Release() error {
	gate.mu.Lock()
	if gate.abandoned {
		gate.mu.Unlock()
		return nil
	}
	if !gate.committed {
		gate.requested = true
		gate.mu.Unlock()
		return nil
	}
	gate.mu.Unlock()
	return gate.releaseNow()
}

func (gate *bidiReleaseGate) Commit() error {
	gate.mu.Lock()
	gate.committed = true
	requested := gate.requested
	gate.mu.Unlock()
	if !requested {
		return nil
	}
	return gate.releaseNow()
}

func (gate *bidiReleaseGate) Abandon() {
	gate.mu.Lock()
	gate.abandoned = true
	gate.mu.Unlock()
}

func (gate *bidiReleaseGate) releaseNow() error {
	gate.once.Do(func() {
		if gate.release != nil {
			gate.err = gate.release()
		}
	})
	return gate.err
}

// UploadDrive 将 Drive 上传委托给同一认证传输
func (transport *authRetryTransport) UploadDrive(
	ctx context.Context,
	accountID string,
	token string,
	request aistudio.UploadRequest,
) (aistudio.FileRef, error) {
	return transport.transport.(aistudio.DriveTransport).UploadDrive(ctx, accountID, token, request)
}

// DownloadDrive 将 Drive 下载委托给同一认证传输
func (transport *authRetryTransport) DownloadDrive(
	ctx context.Context,
	accountID string,
	token string,
	fileID string,
) (aistudio.MediaStream, error) {
	return transport.transport.(aistudio.DriveTransport).DownloadDrive(ctx, accountID, token, fileID)
}

// DeleteDrive 将 Drive 删除委托给同一认证传输
func (transport *authRetryTransport) DeleteDrive(
	ctx context.Context,
	accountID string,
	token string,
	fileID string,
) error {
	return transport.transport.(aistudio.DriveTransport).DeleteDrive(ctx, accountID, token, fileID)
}

// DriveFileExists 将 Drive 文件查询委托给同一认证传输
func (transport *authRetryTransport) DriveFileExists(ctx context.Context, accountID string, token string, fileID string) (bool, error) {
	return transport.transport.(aistudio.DriveFileChecker).DriveFileExists(ctx, accountID, token, fileID)
}

// UploadAssistantFile 将写代码助手附件上传委托给同一认证传输
func (transport *authRetryTransport) UploadAssistantFile(ctx context.Context, accountID string, blob aistudio.Blob) (string, error) {
	return transport.transport.(aistudio.AssistantUploader).UploadAssistantFile(ctx, accountID, blob)
}

// newAuthRuntimeRefresher 创建生产环境认证续签器
func newAuthRuntimeRefresher(
	workers *accountWorkerManager,
	requests *requestRegistry,
	globalProxy string,
) *authRuntimeRefresher {
	return &authRuntimeRefresher{
		pool:    workers.pool,
		refresh: chromeauth.Refresh, importCurrent: importCurrentChromeState, chromeHas: chromeIdentityImportable,
		reset: workers.Reset, prepareWorker: workers.prepareUpdate,
		rotate: chromeauth.RotateBoundCookies, mergeWorker: workers.MergeCookies,
		globalProxy: globalProxy,
		requests:    requests,
	}
}

// chromeIdentityImportable 判断本机 Chrome 是否登录着该邮箱且材料可导入
func chromeIdentityImportable(email string) bool {
	root, err := chromeauth.DefaultChromeRoot()
	if err != nil {
		return false
	}
	accounts, err := chromeauth.Discover(root)
	if err != nil {
		return false
	}
	for _, account := range accounts {
		if account.Importable && strings.EqualFold(account.Email, email) {
			return true
		}
	}
	return false
}

// importCurrentChromeState 从原来源中更新同一 Google 账户的认证材料
func importCurrentChromeState(ctx context.Context, source aistudio.AuthSource, material *aistudio.ChromeOAuthMaterial, proxy string) (aistudio.StorageState, error) {
	root, err := chromeauth.DefaultChromeRoot()
	if err != nil {
		return aistudio.StorageState{}, err
	}
	accounts, err := chromeauth.Discover(root)
	if err != nil {
		return aistudio.StorageState{}, err
	}
	var selected string
	for _, account := range accounts {
		if !account.Importable || !strings.EqualFold(account.Email, source.Email) || material != nil && account.GaiaID != material.GaiaID {
			continue
		}
		selected = account.ID
		if account.Profile == source.Profile {
			break
		}
	}
	if selected == "" {
		return aistudio.StorageState{}, fmt.Errorf("Chrome 中没有可更新的原账户 %s", source.Email)
	}
	results, err := chromeauth.Import(ctx, chromeauth.ImportOptions{ChromeRoot: root, Proxy: proxy, AccountIDs: []string{selected}})
	if err != nil {
		return aistudio.StorageState{}, err
	}
	if len(results) != 1 || !strings.EqualFold(results[0].Email, source.Email) {
		return aistudio.StorageState{}, fmt.Errorf("Chrome 更新账户与原账户不匹配")
	}
	return results[0].State, nil
}

// markAuthenticationRequired 发布当前认证版本号的账户状态
func (refresher *authRuntimeRefresher) markAuthenticationRequired(ctx context.Context, cause error) error {
	lease, ok := aistudio.AccountLeaseFromContext(ctx)
	if !ok || ctx.Err() != nil || !aistudio.DefinitiveAuthenticationFailure(cause) {
		return cause
	}
	err := lease.ConfirmAuthenticationFailure(ctx, cause)
	statuses := refresher.pool.Status()
	accounts := make([]api.AdminAccount, 0, len(statuses))
	for _, status := range statuses {
		accounts = append(accounts, adminAccountDTO(status))
	}
	refresher.requests.publish(api.AdminEvent{Type: "accounts", Data: map[string]any{"accounts": accounts}})
	return errors.Join(cause, err)
}

// authGeneration 返回 ctx 中账户租约的当前认证版本号，没有租约时为 0
func authGeneration(ctx context.Context) uint64 {
	lease, ok := aistudio.AccountLeaseFromContext(ctx)
	if !ok {
		return 0
	}
	return lease.AuthGeneration()
}

// Recover 为 generation 下失效的认证恢复一次登录并保留最终失败原因
func (refresher *authRuntimeRefresher) Recover(ctx context.Context, cause error, generation uint64) error {
	var startup *accountWorkerInitError
	if errors.As(cause, &startup) && startup.authHandled {
		return cause
	}
	if refresher.Available(ctx) {
		if err := refresher.Refresh(ctx, generation); err == nil {
			return nil
		} else {
			cause = errors.Join(cause, err)
		}
	}
	return refresher.markAuthenticationRequired(ctx, cause)
}

// do 重放认证恢复前尚未产生语义输出的普通或受保护 RPC
func (refresher *authRuntimeRefresher) do(ctx context.Context, method string, send func() (*aistudio.RPCResponse, error)) (*aistudio.RPCResponse, error) {
	for attempt := 0; ; attempt++ {
		generation := authGeneration(ctx)
		var response *aistudio.RPCResponse
		err := refresher.ensureBound(ctx)
		if err == nil {
			response, err = send()
		}
		if err == nil && authenticationFailed(response) {
			original, readErr := readAuthenticationFailure(method, response)
			if readErr != nil {
				return nil, readErr
			}
			err = original
			response = nil
		}
		if !aistudio.DefinitiveAuthenticationFailure(err) {
			return response, err
		}
		if attempt == 1 {
			return nil, refresher.markAuthenticationRequired(ctx, err)
		}
		if err := refresher.Recover(ctx, err, generation); err != nil {
			return nil, err
		}
	}
}

// Do 在 401 后续签同一账户并重放一次请求
func (transport *authRetryTransport) Do(ctx context.Context, request aistudio.RPCRequest) (*aistudio.RPCResponse, error) {
	return transport.refresher.do(ctx, request.Method, func() (*aistudio.RPCResponse, error) {
		return transport.transport.Do(ctx, request)
	})
}

// DoProtected 在 401 后续签同一账户并重放一次受保护请求
func (transport *authRetryProtectedTransport) DoProtected(
	ctx context.Context,
	request aistudio.GenerateRequest,
	rpc aistudio.RPCRequest,
) (*aistudio.RPCResponse, error) {
	return transport.refresher.do(ctx, rpc.Method, func() (*aistudio.RPCResponse, error) {
		return transport.transport.DoProtected(ctx, request, rpc)
	})
}

// OpenBidiProtected 在 401 后续签同一账户并重新建立 WebChannel
func (transport *authRetryProtectedTransport) OpenBidiProtected(
	ctx context.Context,
	request aistudio.BidiRequest,
	runtime aistudio.RequestContext,
	lease *aistudio.AccountLease,
	release func() error,
) (*aistudio.BidiSession, error) {
	bidiTransport := transport.transport.(aistudio.BidiProtectedTransport)
	gate := newBidiReleaseGate(release)
	generation := authGeneration(ctx)
	var session *aistudio.BidiSession
	err := transport.refresher.ensureBound(ctx)
	if err == nil {
		session, err = bidiTransport.OpenBidiProtected(ctx, request, runtime, lease, gate.Release)
	}
	if err == nil {
		if releaseErr := gate.Commit(); releaseErr != nil {
			return nil, errors.Join(releaseErr, session.Close())
		}
		return session, nil
	}
	if !aistudio.DefinitiveAuthenticationFailure(err) {
		return nil, errors.Join(err, gate.Commit())
	}
	gate.Abandon()
	if recoverErr := transport.refresher.Recover(ctx, err, generation); recoverErr != nil {
		return nil, recoverErr
	}
	session, err = bidiTransport.OpenBidiProtected(ctx, request, runtime, lease, release)
	if aistudio.DefinitiveAuthenticationFailure(err) {
		err = transport.refresher.markAuthenticationRequired(ctx, err)
	}
	return session, err
}

// DoProtectedTitle 在认证失败后续签同一账户并重放 GenerateTitle 请求
func (transport *authRetryProtectedTransport) DoProtectedTitle(
	ctx context.Context,
	request aistudio.TitleRequest,
	rpc aistudio.RPCRequest,
) (*aistudio.RPCResponse, error) {
	return transport.refresher.do(ctx, rpc.Method, func() (*aistudio.RPCResponse, error) {
		return transport.transport.(aistudio.TitleProtectedTransport).DoProtectedTitle(ctx, request, rpc)
	})
}

// DoProtectedApplet 在认证失败后续签同一账户并重放 Build 应用与云项目请求
func (transport *authRetryProtectedTransport) DoProtectedApplet(
	ctx context.Context,
	request aistudio.AppletProtectedRequest,
	rpc aistudio.RPCRequest,
) (*aistudio.RPCResponse, error) {
	return transport.refresher.do(ctx, rpc.Method, func() (*aistudio.RPCResponse, error) {
		return transport.transport.(aistudio.AppletProtectedTransport).DoProtectedApplet(ctx, request, rpc)
	})
}

// DoProtectedImage 在认证失败后续签同一账户并重放 GenerateImage 请求
func (transport *authRetryProtectedTransport) DoProtectedImage(
	ctx context.Context,
	request aistudio.ImageRequest,
	rpc aistudio.RPCRequest,
) (*aistudio.RPCResponse, error) {
	return transport.refresher.do(ctx, rpc.Method, func() (*aistudio.RPCResponse, error) {
		return transport.transport.(aistudio.ImageProtectedTransport).DoProtectedImage(ctx, request, rpc)
	})
}

// DoProtectedDecision 在认证失败后续签同一账户并重放 CreateDecision 请求
func (transport *authRetryProtectedTransport) DoProtectedDecision(
	ctx context.Context,
	request aistudio.DecisionRequest,
	rpc aistudio.RPCRequest,
) (*aistudio.RPCResponse, error) {
	return transport.refresher.do(ctx, rpc.Method, func() (*aistudio.RPCResponse, error) {
		return transport.transport.(aistudio.DecisionProtectedTransport).DoProtectedDecision(ctx, request, rpc)
	})
}

// Refresh 续签 generation 下失效的租约账户并保存新的 storage state，此后已有续签提交时直接复用
func (refresher *authRuntimeRefresher) Refresh(ctx context.Context, generation uint64) error {
	lease, ok := aistudio.AccountLeaseFromContext(ctx)
	if !ok {
		return fmt.Errorf("认证续签缺少账户租约")
	}
	endRefresh, ok := lease.BeginAuthRefresh()
	if !ok {
		return fmt.Errorf("%w: 账户存在活动生成", aistudio.ErrAccountLeased)
	}
	defer endRefresh()
	if err := lease.WaitForAuthRefresh(ctx, generation); err != nil {
		return err
	}
	account := lease.Account()
	startedAt := time.Now()
	refreshed := false
	logRenewal := func(level string, stage api.LogStage, message string, attrs ...any) {
		if startup, _ := ctx.Value(workerStartupRenewalKey{}).(bool); !startup {
			stage.Name = "账户认证续签"
			refresher.requests.logStage(account.Config.Label, level, stage, message, attrs...)
		}
	}
	err := lease.RefreshStorageState(generation, func(state *aistudio.StorageState) error {
		refreshed = true
		logRenewal("INFO", api.LogStage{Step: 1, Steps: 2}, "刷新 Cookie")
		extension, _, err := state.AuthExtension()
		if err != nil {
			return err
		}
		if extension.OAuth == nil {
			extension = aistudio.AuthExtension{Source: aistudio.AuthSource{Browser: "chrome", Email: account.ID}}
		}
		proxy := account.EffectiveProxy(refresher.globalProxy)
		var cookies []aistudio.StateCookie
		if extension.OAuth != nil {
			cookies, extension.Bound, err = refresher.refresh(ctx, extension.Source, *extension.OAuth, proxy)
		}
		if extension.OAuth == nil || errors.Is(err, chromeauth.ErrCredentialsRejected) {
			if extension.Source.Browser != "chrome" || !strings.EqualFold(extension.Source.Email, account.ID) {
				return errors.Join(fmt.Errorf("账户 %s 缺少可更新的 Chrome 来源", account.ID), err)
			}
			logRenewal("INFO", api.LogStage{}, "更新 Chrome 来源材料")
			updated, importErr := refresher.importCurrent(ctx, extension.Source, extension.OAuth, proxy)
			if importErr != nil {
				return errors.Join(err, importErr)
			}
			current, exists, importErr := updated.AuthExtension()
			if importErr != nil || !exists || current.OAuth == nil || !strings.EqualFold(current.Source.Email, account.ID) ||
				extension.OAuth != nil && current.OAuth.GaiaID != extension.OAuth.GaiaID {
				return fmt.Errorf("Chrome 更新结果与账户 %s 不匹配", account.ID)
			}
			extension = current
			cookies, err = updated.Cookies, nil
		}
		if err != nil {
			return fmt.Errorf("续签账户 %s: %w", account.ID, err)
		}
		state.SetAuthExtension(extension)
		state.Cookies = cookies
		_, err = aistudio.NewSigner().Authorization(*state)
		return err
	}, func() error {
		logRenewal("INFO", api.LogStage{Step: 2, Steps: 2}, "重置协议运行时")
		if err := refresher.reset(account.ID); err != nil {
			return fmt.Errorf("重置账户 %s runtime: %w", account.ID, err)
		}
		return nil
	})
	if err != nil {
		wrapped := fmt.Errorf("保存账户 %s 认证状态: %w", account.ID, err)
		logRenewal("ERROR", api.LogStage{State: "failed"}, "账户认证续签失败", "duration", time.Since(startedAt), "error", wrapped)
		return wrapped
	}
	if !refreshed {
		return nil
	}
	if err := setCookieAuthUser(lease, 0, refresher.prepareWorker); err != nil {
		return fmt.Errorf("保存账户 %s 会话序号: %w", account.ID, err)
	}
	logRenewal("INFO", api.LogStage{State: "completed"}, "账户认证续签完成", "duration", time.Since(startedAt))
	return nil
}

// ensureBound 在租约账户 DBSC 会话的绑定 Cookie 剩余不足 boundRefreshThreshold 时刷新，并写回账户与当前 Worker 的页面
func (refresher *authRuntimeRefresher) ensureBound(ctx context.Context) error {
	lease, ok := aistudio.AccountLeaseFromContext(ctx)
	if !ok {
		return nil
	}
	due := func() (aistudio.StorageState, aistudio.AuthExtension, bool, error) {
		state, err := lease.ReloadStorageState()
		if err != nil {
			return state, aistudio.AuthExtension{}, false, err
		}
		extension, _, err := state.AuthExtension()
		if err != nil || extension.Bound == nil {
			return state, extension, false, err
		}
		return state, extension, state.BoundCookieLifetime(*extension.Bound, time.Now()) <= boundRefreshThreshold, nil
	}
	if _, _, refresh, err := due(); err != nil || !refresh {
		return err
	}
	account := lease.Account()
	value, _ := refresher.boundLocks.LoadOrStore(account.ID, &sync.Mutex{})
	mu := value.(*sync.Mutex)
	mu.Lock()
	defer mu.Unlock()
	state, extension, refresh, err := due()
	if err != nil || !refresh {
		return err
	}
	headers, err := refresher.rotate(ctx, state, extension, account.EffectiveProxy(refresher.globalProxy))
	if errors.Is(err, chromeauth.ErrBoundSessionRejected) {
		return errors.Join(camoufoxnative.ErrAuthenticationRequired, err)
	}
	if err != nil {
		return fmt.Errorf("刷新账户 %s DBSC 会话: %w", account.ID, err)
	}
	if err := lease.MergeSetCookieHeaders(headers, extension.Bound.RefreshURL, time.Now()); err != nil {
		return fmt.Errorf("保存账户 %s DBSC 会话 Cookie: %w", account.ID, err)
	}
	return refresher.mergeWorker(ctx, account.ID, headers, extension.Bound.RefreshURL)
}

// Available 返回当前租约账户能否续签：保存了 Chrome OAuth 续签材料，或本机 Chrome 登录着同一邮箱
func (refresher *authRuntimeRefresher) Available(ctx context.Context) bool {
	lease, ok := aistudio.AccountLeaseFromContext(ctx)
	if !ok {
		return false
	}
	state, err := lease.ReloadStorageState()
	if err != nil {
		return false
	}
	extension, _, err := state.AuthExtension()
	if err != nil {
		return false
	}
	return extension.OAuth != nil || refresher.chromeHas != nil && refresher.chromeHas(lease.Account().ID)
}

func authenticationFailed(response *aistudio.RPCResponse) bool {
	return response.StatusCode == http.StatusUnauthorized
}

// readAuthenticationFailure 读取并关闭认证失败响应，返回原始原因
func readAuthenticationFailure(method string, response *aistudio.RPCResponse) (*aistudio.RPCError, error) {
	body, readErr := io.ReadAll(response.Body)
	if err := errors.Join(readErr, response.Body.Close()); err != nil {
		return nil, fmt.Errorf("读取认证失败响应: %w", err)
	}
	return aistudio.DecodeRPCError(method, response.StatusCode, body), nil
}

var _ aistudio.RPCTransport = (*authRetryTransport)(nil)
var _ aistudio.DriveTransport = (*authRetryTransport)(nil)
var _ aistudio.ProtectedTransport = (*authRetryProtectedTransport)(nil)
var _ aistudio.BidiProtectedTransport = (*authRetryProtectedTransport)(nil)
