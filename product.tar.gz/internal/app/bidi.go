package app

import (
	"context"
	"errors"
	"strings"

	"github.com/Mag1cFall/AIStudio2API/internal/aistudio"
	"github.com/Mag1cFall/AIStudio2API/internal/api"
)

// OpenBidi 将实时会话绑定到当前生成服务生命周期
func (service *trackedService) OpenBidi(ctx context.Context, request aistudio.BidiRequest) (*aistudio.BidiSession, error) {
	request.Model = service.mappedModel(request.Model)
	api.SetAccessLogTarget(ctx, request.Model, "")
	request.Model = service.catalogModelID(ctx, request.Model)
	requestCtx, cancel, err := service.bidiRequestContext(ctx)
	if err != nil {
		api.SetAccessLogError(ctx, err)
		return nil, err
	}
	if request.AccountID == "" && len(request.AllowedAccountIDs) == 0 {
		request.AllowedAccountIDs, err = service.bidiCandidates(requestCtx, request.Model, request.ModelAccessScope)
		if err != nil {
			api.SetAccessLogError(ctx, err)
			cancel()
			return nil, err
		}
	}
	workerGenerations := make(map[string]uint64)
	recoveredWorkers := make(map[string]struct{})
	request.ObserveWAARuntime = func(accountID string, generation uint64) {
		workerGenerations[accountID] = generation
	}
	request.ObserveModelAccessChange = service.publishModelAccess
	request.ObserveAccountFailure = func(accountID string, cause error) {
		service.requests.log(service.accountLabel(accountID), "WARN", "账号切换", attemptFields(strings.TrimPrefix(request.Model, "models/"), cause)...)
	}
	request.RecoverWAARuntime = func(recoveryCtx context.Context, accountID string, cause error) (bool, error) {
		workerFailed := service.workers.WorkerFailed(accountID)
		waaRuntimeFailed := aistudio.DefinitiveWAARuntimeFailure(cause)
		workerReplaced := errors.Is(cause, errAccountWorkerReplaced)
		if recoveryCtx.Err() != nil || !needsWAARuntimeRecovery(cause, workerFailed, workerReplaced) {
			return false, nil
		}
		expectedGeneration := workerGenerations[accountID]
		recovered, _, recoveryErr := service.recoverWorkerOnce(
			recoveryCtx, accountID, expectedGeneration, recoveredWorkers,
			true, workerFailed || waaRuntimeFailed,
		)
		return recovered, recoveryErr
	}
	requestCtx = aistudio.ContextWithAccountSelectionObserver(requestCtx, func(account *aistudio.Account) {
		workerGenerations[account.ID] = service.workers.WorkerGeneration(account.ID)
		api.SetAccessLogTarget(ctx, request.Model, account.Config.Label)
	})
	session, err := service.service.(aistudio.BidiService).OpenBidi(requestCtx, request)
	if err != nil {
		api.SetAccessLogError(ctx, err)
		cancel()
		return nil, err
	}
	api.SetAccessLogChannel(ctx, string(session.Channel()))
	return session, nil
}

// WorkerGeneration 返回当前 preparer 对应的 Worker 版本号
func (preparer *accountWorkerPreparer) WorkerGeneration() uint64 {
	return preparer.account.generation.Load()
}

func (service *trackedService) bidiCandidates(ctx context.Context, model string, modelAccessScope string) ([]string, error) {
	modelID := strings.TrimPrefix(strings.TrimSpace(model), "models/")
	groups, err := service.pool.ClassifyCandidates(
		ctx,
		aistudio.AccountSelection{
			ModelID: modelID, ModelAccessScope: modelAccessScope, Method: service.pool.BidiMethod(modelID),
		},
		service.workers.WarmAccountIDs(),
	)
	if err != nil {
		return nil, err
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	warmAvailable := append(append([]string(nil), groups.WarmReady...), groups.WarmAvailable...)
	candidates := service.preferBidiAccounts(warmAvailable, modelID, modelAccessScope)
	candidates = append(candidates, service.preferBidiAccounts(groups.StandbyReady, modelID, modelAccessScope)...)
	candidates = append(candidates, service.preferBidiAccounts(groups.WarmBusy, modelID, modelAccessScope)...)
	candidates = append(candidates, service.preferBidiAccounts(groups.StandbyBusy, modelID, modelAccessScope)...)
	if len(candidates) == 0 {
		return nil, aistudio.ErrNoEligibleAccount
	}
	return candidates, nil
}

// preferBidiAccounts 在实测资格分组内按账户策略排列候选
func (service *trackedService) preferBidiAccounts(accountIDs []string, modelID string, modelAccessScope string) []string {
	scope := modelAccessScope
	if scope == "" {
		scope = modelID
	}
	candidates := service.pool.OrderCandidates(accountIDs, scope)
	if modelAccessScope == "" {
		return candidates
	}
	states := service.pool.CandidateStatesForScope(candidates, modelID, modelAccessScope)
	verified := make([]string, 0, len(candidates))
	unverified := make([]string, 0, len(candidates))
	for _, accountID := range candidates {
		if states[accountID].ModelAccess == aistudio.ModelAccessVerified {
			verified = append(verified, accountID)
			continue
		}
		unverified = append(unverified, accountID)
	}
	return append(verified, unverified...)
}

func (service *trackedService) bidiRequestContext(ctx context.Context) (context.Context, context.CancelFunc, error) {
	service.lifecycleMu.Lock()
	if service.state.Load() != serviceRunning || service.dataContext == nil {
		service.lifecycleMu.Unlock()
		return nil, nil, service.stoppedError()
	}
	requestCtx, cancel := context.WithCancel(ctx)
	stopData := context.AfterFunc(service.dataContext, cancel)
	context.AfterFunc(requestCtx, func() {
		stopData()
	})
	service.lifecycleMu.Unlock()
	return requestCtx, func() {
		stopData()
		cancel()
	}, nil
}
