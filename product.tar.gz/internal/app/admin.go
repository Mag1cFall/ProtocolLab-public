package app

import (
	"bytes"
	"cmp"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"runtime/debug"
	"slices"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/Mag1cFall/AIStudio2API/internal/aistudio"
	"github.com/Mag1cFall/AIStudio2API/internal/api"
	"github.com/Mag1cFall/AIStudio2API/internal/camoufoxnative"
	"github.com/Mag1cFall/AIStudio2API/internal/chromeauth"
	"github.com/Mag1cFall/AIStudio2API/internal/config"
	"github.com/Mag1cFall/AIStudio2API/internal/egress"
)

// runtimeAdmin 投影运行时权威状态
type runtimeAdmin struct {
	lifecycle   context.Context
	pool        *aistudio.AccountPool
	store       *aistudio.AccountStore
	service     *trackedService
	requests    *requestRegistry
	login       aistudio.IsolatedLoginDriver
	workers     *accountWorkerManager
	configPath  string
	config      config.Config
	proxies     *aistudio.ProxyPool
	globalProxy string

	transitionMu sync.Mutex
	// transitions 是各账户进行中的启停后台收尾
	transitions map[string]*accountTransition
}

// accountTransition 是一次进行中的账户启停后台收尾
type accountTransition struct {
	cancel context.CancelFunc
	done   chan struct{}
}

type adminOperationError struct {
	status  int
	code    string
	message string
}

func (err *adminOperationError) Error() string {
	return err.message
}

func (err *adminOperationError) HTTPStatus() int {
	return err.status
}

func (err *adminOperationError) ErrorCode() string {
	return err.code
}

// invalidConfigError 将配置校验失败标记为客户端输入错误
func invalidConfigError(err error) error {
	return &adminOperationError{status: http.StatusBadRequest, code: "invalid_config", message: err.Error()}
}

// newRuntimeAdmin 创建管理端服务
func newRuntimeAdmin(
	lifecycle context.Context,
	pool *aistudio.AccountPool,
	store *aistudio.AccountStore,
	service *trackedService,
	registry *requestRegistry,
	login aistudio.IsolatedLoginDriver,
	workers *accountWorkerManager,
	cfg config.Config,
) *runtimeAdmin {
	return &runtimeAdmin{
		lifecycle: lifecycle, pool: pool, store: store, service: service, requests: registry, login: login,
		workers:    workers,
		configPath: ".env", config: cfg,
	}
}

func (admin *runtimeAdmin) Status(context.Context) (api.AdminStatus, error) {
	counts := api.AdminAccountCounts{}
	for _, account := range admin.pool.Status() {
		counts.Total++
		switch account.State {
		case aistudio.AccountReady:
			counts.Ready++
		case aistudio.AccountBusy:
			counts.Busy++
		case aistudio.AccountCooldown:
			counts.Cooldown++
		case aistudio.AccountAuthRequired:
			counts.AuthRequired++
		}
	}
	state := admin.service.State()
	running := state == "RUNNING"
	status := api.AdminStatus{
		State:          state,
		Running:        running,
		Ready:          running && counts.Ready+counts.Busy > 0,
		Version:        buildVersion(),
		ActiveRequests: admin.requests.count(),
		Accounts:       counts,
		Camoufox:       camoufoxnative.PreparationState(),
		ChromeImport:   chromeauth.Supported,
	}
	return status, nil
}

func (admin *runtimeAdmin) Accounts(context.Context) ([]api.AdminAccount, error) {
	statuses := admin.pool.Status()
	accounts := make([]api.AdminAccount, 0, len(statuses))
	for _, status := range statuses {
		accounts = append(accounts, adminAccountDTO(status))
	}
	return accounts, nil
}

// AccountExits 并发查询各账户出口代理的公网 IP 与地理位置，每个代理一行，查询失败的代理带原因
func (admin *runtimeAdmin) AccountExits(ctx context.Context) ([]api.AccountExit, error) {
	var proxies []string
	for _, status := range admin.pool.Status() {
		if !slices.Contains(proxies, status.Egress) {
			proxies = append(proxies, status.Egress)
		}
	}
	exits := make([]api.AccountExit, len(proxies))
	var wait sync.WaitGroup
	for index, proxy := range proxies {
		wait.Go(func() {
			exits[index] = api.AccountExit{Proxy: proxy}
			exit, err := egress.Lookup(ctx, proxy)
			if err != nil {
				exits[index].Error = err.Error()
				return
			}
			exits[index].IP, exits[index].Country, exits[index].Timezone, exits[index].Locale = exit.IP, exit.Country, exit.Timezone, exit.Locale
		})
	}
	wait.Wait()
	return exits, nil
}

// accountEnvironment 返回新账户的语言与时区：locale 或 timezone 未给出时按 proxy 出口的地理位置填写并写入日志
func (admin *runtimeAdmin) accountEnvironment(ctx context.Context, proxy string, locale string, timezone string) (egress.Exit, error) {
	exit, err := egress.Environment(ctx, proxy, strings.TrimSpace(locale), timezone)
	if err != nil {
		return egress.Exit{}, fmt.Errorf("按出口位置确定账户语言与时区: %w", err)
	}
	if exit.IP != "" {
		admin.requests.log("auth", "INFO", "账户语言与时区按出口位置填写", "egress", exit.IP, "country", exit.Country, "locale", exit.Locale, "timezone", exit.Timezone)
	}
	return exit, nil
}

func (admin *runtimeAdmin) CreateAccount(ctx context.Context, input api.AccountCreateInput, view *camoufoxnative.LiveView) (api.AdminAccount, error) {
	accountConfig := aistudio.DefaultAccountConfig("")
	accountConfig.Proxy = strings.TrimSpace(input.Proxy)
	timezone, err := accountTimezone(input.Timezone)
	if err != nil {
		return api.AdminAccount{}, invalidAccount(err)
	}
	if err := config.ValidateProxy(accountConfig.Proxy); err != nil {
		return api.AdminAccount{}, invalidAccount(err)
	}
	environment, err := admin.accountEnvironment(ctx, admin.effectiveProxy(accountConfig.Proxy), input.Locale, timezone)
	if err != nil {
		return api.AdminAccount{}, err
	}
	accountConfig.Locale, accountConfig.Timezone = environment.Locale, environment.Timezone
	directory, err := os.MkdirTemp("", "aistudio2api-account-login-*")
	if err != nil {
		return api.AdminAccount{}, fmt.Errorf("创建隔离登录目录: %w", err)
	}
	defer os.RemoveAll(directory)
	startedAt := time.Now()
	admin.requests.logStage("auth", "INFO", api.LogStage{Name: "账户添加", Step: 1, Steps: 2}, "等待隔离登录")
	result, err := admin.login.Login(ctx, aistudio.IsolatedLoginRequest{
		Directory: directory, Proxy: admin.effectiveProxy(accountConfig.Proxy),
		Locale: accountConfig.Locale, Timezone: accountConfig.Timezone, View: view,
	})
	if err != nil {
		admin.requests.logStage("auth", "ERROR", api.LogStage{Name: "账户添加", State: "failed"}, "账户添加失败", "duration", time.Since(startedAt), "error", err)
		return api.AdminAccount{}, err
	}
	if result.DriveError != "" {
		admin.requests.logStage("auth", "WARN", api.LogStage{Name: "账户添加"}, "Drive 授权失败", "error", result.DriveError)
	}
	if result.CloseError != "" {
		admin.requests.logStage("auth", "WARN", api.LogStage{Name: "账户添加"}, "关闭 Camoufox 失败", "error", result.CloseError)
	}
	admin.requests.logStage("auth", "INFO", api.LogStage{Name: "账户添加", Step: 2, Steps: 2}, "保存认证状态")
	if _, err := aistudio.NewSigner().Authorization(result.StorageState); err != nil {
		return api.AdminAccount{}, fmt.Errorf("认证状态无法用于 AI Studio: %w", err)
	}
	accountConfig.Label = result.Email
	if err := accountConfig.Validate(); err != nil {
		return api.AdminAccount{}, invalidAccount(err)
	}
	created, err := admin.upsertAccount(ctx, accountConfig.Label, accountConfig, result.StorageState, directory)
	if err != nil {
		return api.AdminAccount{}, err
	}
	admin.requests.logStage("auth", "INFO", api.LogStage{Name: "账户添加", State: "completed"}, "账户添加完成", "account", created.Label, "duration", time.Since(startedAt))
	return created, nil
}

func (admin *runtimeAdmin) ChromeImportProfiles(context.Context) ([]api.ChromeImportProfile, error) {
	root, err := chromeauth.DefaultChromeRoot()
	if err != nil {
		return nil, err
	}
	accounts, err := chromeauth.Discover(root)
	if err != nil {
		return nil, err
	}
	recorded, err := admin.store.RestrictedImports()
	if err != nil {
		return nil, err
	}
	return chromeImportProfiles(accounts, admin.accountIDs(), recorded), nil
}

// chromeImportProfiles 返回可导入的 Chrome 账户，已导入且未受限的账户不列出，服务受限的已导入账户与导入时被拒绝的账户带受限原因
func chromeImportProfiles(accounts []chromeauth.Account, existing map[string]string, recorded map[string]string) []api.ChromeImportProfile {
	seen := make(map[string]struct{}, len(accounts))
	profiles := make([]api.ChromeImportProfile, 0, len(accounts))
	for _, account := range accounts {
		email := strings.ToLower(strings.TrimSpace(account.Email))
		if !account.Importable || email == "" {
			continue
		}
		restricted, exists := existing[email]
		if _, duplicate := seen[email]; duplicate || exists && restricted == "" {
			continue
		}
		seen[email] = struct{}{}
		profiles = append(profiles, api.ChromeImportProfile{
			ID: account.ID, Profile: account.Profile, DisplayName: account.DisplayName, Email: email,
			Restricted: cmp.Or(restricted, recorded[email]),
		})
	}
	return profiles
}

// restrictedChromeSelection 在 Chrome 认证交换之前拒绝所选账户中服务受限的已导入账户与导入时被记下服务受限的账户
func restrictedChromeSelection(accounts []chromeauth.Account, ids []string, existing map[string]string, recorded map[string]string) error {
	for _, account := range accounts {
		if !slices.ContainsFunc(ids, func(id string) bool { return strings.EqualFold(strings.TrimSpace(id), account.ID) }) {
			continue
		}
		email := strings.ToLower(strings.TrimSpace(account.Email))
		if reason := cmp.Or(existing[email], recorded[email]); reason != "" {
			return accountRestricted(email, reason)
		}
	}
	return nil
}

// CookieBrowsers 列出本机开启远程调试的浏览器，读取其 Cookie 并经 proxy 识别其中各会话登录 AI Studio 的账户，每个账户一项，proxy 为空时用默认出口
func (admin *runtimeAdmin) CookieBrowsers(ctx context.Context, proxy string) ([]api.CookieBrowser, error) {
	addresses, err := chromeauth.DebugAddresses(ctx)
	if err != nil {
		return nil, err
	}
	existing := admin.accountIDs()
	browsers := make([][]api.CookieBrowser, len(addresses))
	var group sync.WaitGroup
	for index, address := range addresses {
		group.Go(func() {
			browser := api.CookieBrowser{Address: address}
			name, err := chromeauth.DebugBrowserName(ctx, address)
			if err != nil {
				browser.Error = err.Error()
				browsers[index] = []api.CookieBrowser{browser}
				return
			}
			browser.Browser = name
			accounts, err := admin.readCookieBrowser(ctx, &browser, proxy)
			browser.SignedOut = errors.Is(err, chromeauth.ErrSignedOut) || errors.Is(err, aistudio.ErrLoginCookieMissing)
			if err != nil && !browser.SignedOut {
				browser.Error = err.Error()
			}
			browsers[index] = cookieAccountEntries(browser, accounts, existing)
		})
	}
	group.Wait()
	return append([]api.CookieBrowser{}, slices.Concat(browsers...)...), nil
}

// readCookieBrowser 读取调试浏览器的 Cookie，经 proxy 识别其中各会话登录 AI Studio 的账户
func (admin *runtimeAdmin) readCookieBrowser(ctx context.Context, browser *api.CookieBrowser, proxy string) ([]chromeauth.CookieAccount, error) {
	source, err := chromeauth.ReadCDPBrowser(ctx, browser.Address)
	if err != nil {
		return nil, err
	}
	state, err := aistudio.ParseCookieText(source.Cookies)
	if err != nil {
		return nil, err
	}
	browser.DeviceBound = deviceBoundSession(state)
	return chromeauth.DiscoverCookieAccounts(ctx, &state, admin.effectiveProxy(proxy))
}

// DiscoverCookieAccounts 解析粘贴的 Cookie，返回其中各会话登录 AI Studio 的账户
func (admin *runtimeAdmin) DiscoverCookieAccounts(ctx context.Context, input api.CookieImportInput) ([]api.CookieBrowser, error) {
	state, err := aistudio.ParseCookieText(input.Cookies)
	if err != nil {
		return nil, &adminOperationError{status: http.StatusBadRequest, code: "invalid_cookies", message: err.Error()}
	}
	accounts, err := chromeauth.DiscoverCookieAccounts(ctx, &state, admin.effectiveProxy(input.Proxy))
	if errors.Is(err, chromeauth.ErrSignedOut) {
		return nil, &adminOperationError{status: http.StatusBadRequest, code: "signed_out", message: err.Error()}
	}
	if err != nil {
		return nil, invalidAccount(err)
	}
	return cookieAccountEntries(api.CookieBrowser{DeviceBound: deviceBoundSession(state)}, accounts, admin.accountIDs()), nil
}

// deviceBoundSession 表示 Cookie 带 __Secure-1PSIDRTS，会话绑定签发它的设备
func deviceBoundSession(state aistudio.StorageState) bool {
	return slices.ContainsFunc(state.Cookies, func(cookie aistudio.StateCookie) bool { return cookie.Name == "__Secure-1PSIDRTS" })
}

// cookieAccountEntries 以 template 为模板为每个会话账户生成一项并标记已导入与服务受限的账户，没有账户时只返回 template
func cookieAccountEntries(template api.CookieBrowser, accounts []chromeauth.CookieAccount, existing map[string]string) []api.CookieBrowser {
	if len(accounts) == 0 {
		return []api.CookieBrowser{template}
	}
	entries := make([]api.CookieBrowser, len(accounts))
	for index, account := range accounts {
		entry := template
		entry.Email, entry.AuthUser, entry.Restricted = account.Email, account.AuthUser, account.Restricted
		if restricted, imported := existing[account.Email]; imported {
			entry.Imported = true
			if restricted != "" {
				entry.Restricted = restricted
			}
		}
		entries[index] = entry
	}
	return entries
}

// accountIDs 返回已导入且不需要重新登录的账户小写 ID 与其服务受限的原因，没有受限时原因为空
func (admin *runtimeAdmin) accountIDs() map[string]string {
	existing := make(map[string]string)
	for _, status := range admin.pool.Status() {
		if status.State == aistudio.AccountAuthRequired {
			continue
		}
		restricted := ""
		if status.State == aistudio.AccountRestricted {
			restricted = status.Message
		}
		existing[strings.ToLower(strings.TrimSpace(status.ID))] = restricted
	}
	return existing
}

// checkAccountAccess 在导入前确认账户不在服务受限状态，再以认证状态打开 AI Studio，Google 拒绝该账户使用 AI Studio 时返回说明原因的错误，服务受限时另在账户根目录记下原因
func (admin *runtimeAdmin) checkAccountAccess(ctx context.Context, email string, state *aistudio.StorageState, proxy string, authUser int) error {
	if restricted := admin.accountIDs()[strings.ToLower(email)]; restricted != "" {
		return accountRestricted(email, restricted)
	}
	err := chromeauth.CheckAccess(ctx, state, proxy, authUser)
	if denial := aistudio.RestrictionDenial(err); denial != nil {
		if !errors.Is(denial, camoufoxnative.ErrServiceRestricted) {
			return accountRestricted(email, denial.Error())
		}
		return errors.Join(accountRestricted(email, denial.Error()), admin.store.RecordRestrictedImport(email, denial.Error()))
	}
	return err
}

// accountRestricted 返回账户服务受限、拒绝导入的错误
func accountRestricted(email string, reason string) error {
	return &adminOperationError{status: http.StatusForbidden, code: "account_restricted", message: fmt.Sprintf("%s 服务受限，未导入：%s", email, reason)}
}

func (admin *runtimeAdmin) ImportChromeAccounts(ctx context.Context, input api.ChromeImportInput) ([]api.AdminAccount, error) {
	if len(input.AccountIDs) == 0 {
		return nil, invalidAccount(fmt.Errorf("未选择 Chrome 账号"))
	}
	root, err := chromeauth.DefaultChromeRoot()
	if err != nil {
		return nil, err
	}
	accountProxy := strings.TrimSpace(input.Proxy)
	timezone, err := accountTimezone(input.Timezone)
	if err != nil {
		return nil, invalidAccount(err)
	}
	discovered, err := chromeauth.Discover(root)
	if err != nil {
		return nil, err
	}
	recorded, err := admin.store.RestrictedImports()
	if err != nil {
		return nil, err
	}
	if err := restrictedChromeSelection(discovered, input.AccountIDs, admin.accountIDs(), recorded); err != nil {
		return nil, err
	}
	results, err := chromeauth.Import(ctx, chromeauth.ImportOptions{
		ChromeRoot: root, Proxy: admin.effectiveProxy(accountProxy), AccountIDs: input.AccountIDs,
	})
	if err != nil {
		return nil, err
	}
	environment, err := admin.accountEnvironment(ctx, admin.effectiveProxy(accountProxy), input.Locale, timezone)
	if err != nil {
		return nil, err
	}
	configs := make([]aistudio.AccountConfig, len(results))
	seen := make(map[string]struct{}, len(results))
	for index, result := range results {
		email := strings.ToLower(strings.TrimSpace(result.Email))
		if _, exists := seen[email]; exists {
			return nil, invalidAccount(fmt.Errorf("Chrome 账号重复: %s", email))
		}
		seen[email] = struct{}{}
		accountConfig := aistudio.DefaultAccountConfig(email)
		accountConfig.Proxy = accountProxy
		accountConfig.Locale, accountConfig.Timezone = environment.Locale, environment.Timezone
		if err := accountConfig.Validate(); err != nil {
			return nil, invalidAccount(err)
		}
		if _, err := aistudio.NewSigner().Authorization(result.State); err != nil {
			return nil, fmt.Errorf("认证状态无法用于 AI Studio: %w", err)
		}
		if err := admin.checkAccountAccess(ctx, email, &results[index].State, admin.effectiveProxy(accountProxy), 0); err != nil {
			return nil, err
		}
		configs[index] = accountConfig
	}
	accounts := make([]api.AdminAccount, 0, len(results))
	for index, result := range results {
		account, err := admin.upsertAccount(ctx, configs[index].Label, configs[index], result.State, "")
		if err != nil {
			return nil, err
		}
		accounts = append(accounts, account)
		admin.requests.log("auth", "INFO", "Chrome 账户已导入", "account", account.Label)
	}
	return accounts, nil
}

// ImportAccountState 导入远程配对上传或 Cookie 导入的认证状态与 Camoufox 指纹，未给标签时以 Cookie 中第 auth_user 个会话登录的账户邮箱为标签
func (admin *runtimeAdmin) ImportAccountState(ctx context.Context, input api.AccountStateInput) (api.AdminAccount, error) {
	timezone, err := accountTimezone(input.Timezone)
	if err != nil {
		return api.AdminAccount{}, invalidAccount(err)
	}
	label := strings.TrimSpace(input.Label)
	if label == "" {
		verification, err := chromeauth.VerifyAuthUser(ctx, &input.StorageState, admin.effectiveProxy(input.Proxy), input.AuthUser)
		if errors.Is(err, chromeauth.ErrSignedOut) {
			return api.AdminAccount{}, &adminOperationError{status: http.StatusBadRequest, code: "signed_out", message: err.Error()}
		}
		if denial := aistudio.RestrictionDenial(err); denial != nil {
			return api.AdminAccount{}, accountRestricted(fmt.Sprintf("u/%d", input.AuthUser), denial.Error())
		}
		if err != nil {
			return api.AdminAccount{}, invalidAccount(err)
		}
		label = strings.ToLower(verification.Email)
	}
	accountConfig := aistudio.DefaultAccountConfig(label)
	accountConfig.AuthUser = input.AuthUser
	accountConfig.Proxy = strings.TrimSpace(input.Proxy)
	environment, err := admin.accountEnvironment(ctx, admin.effectiveProxy(accountConfig.Proxy), input.Locale, timezone)
	if err != nil {
		return api.AdminAccount{}, err
	}
	accountConfig.Locale, accountConfig.Timezone = environment.Locale, environment.Timezone
	if err := accountConfig.Validate(); err != nil {
		return api.AdminAccount{}, invalidAccount(err)
	}
	if err := input.StorageState.Validate(); err != nil {
		return api.AdminAccount{}, invalidAccount(err)
	}
	if _, err := aistudio.NewSigner().Authorization(input.StorageState); err != nil {
		return api.AdminAccount{}, invalidAccount(fmt.Errorf("认证状态无法用于 AI Studio: %w", err))
	}
	email := accountConfig.Label
	if extension, exists, err := input.StorageState.AuthExtension(); err != nil {
		return api.AdminAccount{}, invalidAccount(err)
	} else if exists && strings.TrimSpace(extension.Source.Email) != "" {
		email = extension.Source.Email
	}
	if err := admin.checkAccountAccess(ctx, email, &input.StorageState, admin.effectiveProxy(input.Proxy), input.AuthUser); err != nil {
		return api.AdminAccount{}, err
	}
	if existing := admin.accountID(email); existing != "" && input.RenewalToken != "" {
		return api.AdminAccount{}, &adminOperationError{
			status: http.StatusConflict, code: "account_exists", message: "账户已存在: " + existing,
		}
	}
	fingerprintDirectory := ""
	if len(input.Fingerprint) != 0 {
		directory, err := os.MkdirTemp("", "aistudio2api-pairing-*")
		if err != nil {
			return api.AdminAccount{}, fmt.Errorf("创建配对指纹目录: %w", err)
		}
		defer os.RemoveAll(directory)
		if err := os.WriteFile(filepath.Join(directory, "camoufox-fingerprint.json"), input.Fingerprint, 0o600); err != nil {
			return api.AdminAccount{}, fmt.Errorf("写入配对指纹: %w", err)
		}
		fingerprintDirectory = directory
	}
	account, err := admin.upsertAccount(ctx, email, accountConfig, input.StorageState, fingerprintDirectory)
	if err != nil {
		return api.AdminAccount{}, err
	}
	if input.RenewalToken != "" {
		if err := admin.savePairingRenewal(account.ID, input.RenewalToken); err != nil {
			return api.AdminAccount{}, err
		}
	}
	admin.requests.log("auth", "INFO", "认证状态账户已导入", "account", account.Label)
	return account, nil
}

// upsertAccount 在 id 对应的账户已存在时就地更新其认证状态并保留运行态资源绑定，否则以 accountConfig 新增账户
func (admin *runtimeAdmin) upsertAccount(
	ctx context.Context,
	id string,
	accountConfig aistudio.AccountConfig,
	state aistudio.StorageState,
	fingerprintDirectory string,
) (api.AdminAccount, error) {
	if existing := admin.accountID(id); existing != "" {
		return admin.updateImportedAccount(ctx, existing, accountConfig.AuthUser, state, fingerprintDirectory)
	}
	return admin.addAccount(ctx, accountConfig, state, fingerprintDirectory)
}

// accountID 返回与 id 不区分大小写相同的已有账户 ID，没有时为空
func (admin *runtimeAdmin) accountID(id string) string {
	for _, status := range admin.pool.Status() {
		if strings.EqualFold(status.ID, strings.TrimSpace(id)) {
			return status.ID
		}
	}
	return ""
}

// updateImportedAccount 就地替换已有账户的 Cookie、认证材料与会话序号，保留 runtime-state.json 中的文件资源绑定与模型资格
func (admin *runtimeAdmin) updateImportedAccount(
	ctx context.Context,
	accountID string,
	authUser int,
	state aistudio.StorageState,
	fingerprintDirectory string,
) (api.AdminAccount, error) {
	admin.cancelTransition(accountID)
	lease, err := admin.pool.AcquireAccount(ctx, accountID)
	if err != nil {
		return api.AdminAccount{}, accountOperationError(err)
	}
	account := lease.Account()
	if err := admin.workers.Reset(account.ID); err != nil {
		return api.AdminAccount{}, errors.Join(err, lease.Release())
	}
	if err := replaceAccountState(lease, state, fingerprintDirectory); err != nil {
		return api.AdminAccount{}, errors.Join(err, lease.Release())
	}
	if err := setCookieAuthUser(lease, authUser, admin.workers.prepareUpdate); err != nil {
		return api.AdminAccount{}, errors.Join(err, lease.Release())
	}
	if err := admin.service.changeModels(func() error {
		return admin.pool.MarkReady(account.ID)
	}); err != nil {
		return api.AdminAccount{}, errors.Join(err, lease.Release())
	}
	if err := lease.Release(); err != nil {
		return api.AdminAccount{}, err
	}
	admin.syncAccountModelCatalog(ctx, account)
	return admin.account(account.ID)
}

func (admin *runtimeAdmin) addAccount(
	ctx context.Context,
	accountConfig aistudio.AccountConfig,
	state aistudio.StorageState,
	fingerprintDirectory string,
) (created api.AdminAccount, resultErr error) {
	account, publishLease, err := admin.store.Create(accountConfig, state)
	if errors.Is(err, aistudio.ErrAccountExists) {
		return api.AdminAccount{}, &adminOperationError{status: http.StatusConflict, code: "account_exists", message: err.Error()}
	}
	if err != nil {
		return api.AdminAccount{}, err
	}
	defer func() {
		if publishLease != nil {
			resultErr = errors.Join(resultErr, publishLease.Release())
		}
	}()
	if fingerprintDirectory != "" {
		if err := camoufoxnative.PersistAccountFingerprint(fingerprintDirectory, account.Directory); err != nil {
			return api.AdminAccount{}, errors.Join(err, admin.store.Delete(account))
		}
	}
	if strings.TrimSpace(account.Config.Proxy) == "" {
		account.SetPoolProxy(admin.proxies.Next())
	}
	if err := admin.workers.Add(account); err != nil {
		return api.AdminAccount{}, errors.Join(err, admin.store.Delete(account))
	}
	if err := admin.service.changeModels(func() error {
		return admin.pool.Add(account)
	}); err != nil {
		return api.AdminAccount{}, errors.Join(err, admin.workers.Remove(account.ID), admin.store.Delete(account))
	}
	if err := publishLease.Release(); err != nil {
		return api.AdminAccount{}, err
	}
	publishLease = nil
	if _, err := admin.proxies.Assign(); err != nil {
		return api.AdminAccount{}, err
	}
	admin.syncAccountModelCatalog(ctx, account)
	return admin.account(account.ID)
}

func (admin *runtimeAdmin) UpdateAccount(ctx context.Context, accountID string, input api.AccountInput) (api.AdminAccount, error) {
	if !strings.EqualFold(strings.TrimSpace(input.Label), strings.TrimSpace(accountID)) {
		return api.AdminAccount{}, invalidAccount(fmt.Errorf("账户邮箱不可修改"))
	}
	accountConfig := aistudio.DefaultAccountConfig(strings.ToLower(strings.TrimSpace(accountID)))
	accountConfig.Enabled = input.Enabled
	accountConfig.Proxy = strings.TrimSpace(input.Proxy)
	accountConfig.Locale = strings.TrimSpace(input.Locale)
	timezone, err := accountTimezone(input.Timezone)
	if err != nil {
		return api.AdminAccount{}, invalidAccount(err)
	}
	accountConfig.Timezone = timezone
	if err := accountConfig.Validate(); err != nil {
		return api.AdminAccount{}, invalidAccount(err)
	}
	current, err := admin.account(accountID)
	if err != nil {
		return api.AdminAccount{}, err
	}
	if current.Enabled != accountConfig.Enabled && current.Proxy == accountConfig.Proxy &&
		current.Locale == accountConfig.Locale && current.Timezone == accountConfig.Timezone {
		return admin.setAccountEnabled(accountID, accountConfig.Enabled)
	}
	admin.cancelTransition(accountID)
	lease, err := admin.pool.AcquireAccount(ctx, accountID)
	if err != nil {
		return api.AdminAccount{}, accountOperationError(err)
	}
	account := lease.Account()
	accountConfig.AuthUser = account.Config.AuthUser
	enabling := accountConfig.Enabled && !account.Config.Enabled
	if accountConfig.Proxy == "" && !admin.proxies.Available(account.PoolProxy("")) {
		account.SetPoolProxy(admin.proxies.Next())
	}
	workerUpdate, err := admin.workers.prepareUpdate(account, accountConfig)
	if err != nil {
		return api.AdminAccount{}, errors.Join(err, lease.Release())
	}
	if err := admin.service.changeModels(func() error {
		return lease.SaveConfig(accountConfig)
	}); err != nil {
		workerUpdate.Discard()
		return api.AdminAccount{}, errors.Join(err, lease.Release())
	}
	workerUpdate.Commit()
	if err := lease.Release(); err != nil {
		return api.AdminAccount{}, err
	}
	if _, err := admin.proxies.Assign(); err != nil {
		return api.AdminAccount{}, err
	}
	admin.syncModelCache()
	if enabling {
		admin.syncAccountModelCatalog(ctx, account)
	}
	admin.requests.log("auth", "INFO", "账户配置已更新", "account", accountConfig.Label)
	return admin.account(account.ID)
}

// setAccountEnabled 立即保存账户启用状态并返回，等待在途请求、关闭 Worker 与同步模型目录转入后台，阶段显示在账户状态上
func (admin *runtimeAdmin) setAccountEnabled(accountID string, enabled bool) (api.AdminAccount, error) {
	admin.cancelTransition(accountID)
	var account *aistudio.Account
	if err := admin.service.changeModels(func() (err error) {
		account, err = admin.pool.SetEnabled(accountID, enabled)
		return err
	}); err != nil {
		return api.AdminAccount{}, accountOperationError(err)
	}
	stage := aistudio.AccountDraining
	if enabled {
		stage = aistudio.AccountSyncing
	}
	admin.pool.SetTransition(accountID, stage)
	ctx, cancel := context.WithCancel(admin.lifecycle)
	transition := &accountTransition{cancel: cancel, done: make(chan struct{})}
	admin.transitionMu.Lock()
	if admin.transitions == nil {
		admin.transitions = make(map[string]*accountTransition)
	}
	admin.transitions[accountID] = transition
	admin.transitionMu.Unlock()
	go func() {
		defer close(transition.done)
		defer cancel()
		if enabled {
			admin.finishEnable(ctx, account)
		} else {
			admin.finishDisable(ctx, account)
		}
		admin.pool.SetTransition(accountID, "")
		admin.transitionMu.Lock()
		if admin.transitions[accountID] == transition {
			delete(admin.transitions, accountID)
		}
		admin.transitionMu.Unlock()
		status, _ := admin.Status(admin.lifecycle)
		admin.publishRuntimeSnapshot(admin.lifecycle, status)
	}()
	admin.requests.log("auth", "INFO", "账户配置已更新", "account", account.Config.Label)
	status, _ := admin.Status(admin.lifecycle)
	admin.publishRuntimeSnapshot(admin.lifecycle, status)
	return admin.account(accountID)
}

// finishDisable 等账户在途请求结束后关闭 Worker 并刷新目录
func (admin *runtimeAdmin) finishDisable(ctx context.Context, account *aistudio.Account) {
	lease, err := admin.pool.AcquireAccount(ctx, account.ID)
	if err != nil {
		if ctx.Err() == nil {
			admin.requests.log("auth", "ERROR", "账户停用收尾失败", "account", account.ID, "error", err)
		}
		return
	}
	if err := errors.Join(admin.workers.Reset(account.ID), lease.Release()); err != nil {
		admin.requests.log("auth", "ERROR", "账户停用收尾失败", "account", account.ID, "error", err)
	}
	admin.syncModelCache()
}

// finishEnable 为启用的账户分配代理池出口、刷新目录并同步账户模型目录
func (admin *runtimeAdmin) finishEnable(ctx context.Context, account *aistudio.Account) {
	if strings.TrimSpace(account.Config.Proxy) == "" && !admin.proxies.Available(account.PoolProxy("")) {
		account.SetPoolProxy(admin.proxies.Next())
	}
	if _, err := admin.proxies.Assign(); err != nil {
		admin.requests.log("auth", "ERROR", "账户启用收尾失败", "account", account.ID, "error", err)
	}
	admin.syncModelCache()
	admin.syncAccountModelCatalog(ctx, account)
}

// cancelTransition 取消账户进行中的启停后台收尾并等待它结束
func (admin *runtimeAdmin) cancelTransition(accountID string) {
	admin.transitionMu.Lock()
	transition := admin.transitions[accountID]
	admin.transitionMu.Unlock()
	if transition != nil {
		transition.cancel()
		<-transition.done
	}
}

func (admin *runtimeAdmin) DeleteAccount(ctx context.Context, accountID string) error {
	admin.cancelTransition(accountID)
	account, err := admin.account(accountID)
	if err != nil {
		return err
	}
	defer admin.syncModelCache()
	err = admin.service.changeModels(func() error {
		_, removeErr := admin.pool.Remove(accountID, func(account *aistudio.Account) error {
			if workerErr := admin.workers.Reset(account.ID); workerErr != nil {
				return workerErr
			}
			return admin.store.Delete(account)
		})
		return removeErr
	})
	if err != nil {
		return accountOperationError(err)
	}
	admin.service.removeAccountModelRetry(accountID)
	if err := admin.workers.Remove(accountID); err != nil {
		return err
	}
	admin.requests.log("auth", "INFO", "账户已删除", "account", account.Label)
	return nil
}

func (admin *runtimeAdmin) LoginAccount(ctx context.Context, accountID string, view *camoufoxnative.LiveView) (api.AdminAccount, error) {
	lease, err := admin.pool.AcquireAccount(ctx, accountID)
	if err != nil {
		return api.AdminAccount{}, accountOperationError(err)
	}
	account := lease.Account()
	if err := admin.workers.Reset(account.ID); err != nil {
		return api.AdminAccount{}, errors.Join(err, lease.Release())
	}
	directory, err := os.MkdirTemp("", "aistudio2api-account-login-*")
	if err != nil {
		return api.AdminAccount{}, errors.Join(fmt.Errorf("创建隔离登录目录: %w", err), lease.Release())
	}
	defer os.RemoveAll(directory)
	if err := camoufoxnative.PersistAccountFingerprint(account.Directory, directory); err != nil {
		return api.AdminAccount{}, errors.Join(err, lease.Release())
	}
	startedAt := time.Now()
	admin.requests.logStage(account.Config.Label, "INFO", api.LogStage{Name: "账户登录", Step: 1, Steps: 2}, "等待隔离登录")
	request := admin.loginRequest(account, directory)
	request.View = view
	result, err := admin.login.Login(ctx, request)
	if err != nil {
		admin.requests.logStage(account.Config.Label, "ERROR", api.LogStage{Name: "账户登录", State: "failed"}, "账户登录失败", "duration", time.Since(startedAt), "error", err)
		return api.AdminAccount{}, errors.Join(err, lease.Release())
	}
	if !strings.EqualFold(strings.TrimSpace(result.Email), account.ID) {
		return api.AdminAccount{}, errors.Join(
			invalidAccount(fmt.Errorf("登录邮箱与账户不一致: %s", result.Email)), lease.Release(),
		)
	}
	if result.DriveError != "" {
		admin.requests.logStage(account.Config.Label, "WARN", api.LogStage{Name: "账户登录"}, "Drive 授权失败", "error", result.DriveError)
	}
	if result.CloseError != "" {
		admin.requests.logStage(account.Config.Label, "WARN", api.LogStage{Name: "账户登录"}, "关闭 Camoufox 失败", "error", result.CloseError)
	}
	admin.requests.logStage(account.Config.Label, "INFO", api.LogStage{Name: "账户登录", Step: 2, Steps: 2}, "保存认证状态")
	if _, err := aistudio.NewSigner().Authorization(result.StorageState); err != nil {
		return api.AdminAccount{}, errors.Join(fmt.Errorf("认证状态无法用于 AI Studio: %w", err), lease.Release())
	}
	if err := replaceAccountState(lease, result.StorageState, directory); err != nil {
		return api.AdminAccount{}, errors.Join(err, lease.Release())
	}
	if err := setCookieAuthUser(lease, 0, admin.workers.prepareUpdate); err != nil {
		return api.AdminAccount{}, errors.Join(err, lease.Release())
	}
	if err := admin.service.changeModels(func() error {
		return errors.Join(
			admin.pool.MarkReady(account.ID),
			admin.pool.ResetModelAccess(account.ID),
			admin.pool.SetCatalog(account.ID, account.BenefitTier, nil),
		)
	}); err != nil {
		return api.AdminAccount{}, errors.Join(err, lease.Release())
	}
	if err := lease.Release(); err != nil {
		return api.AdminAccount{}, err
	}
	admin.syncAccountModelCatalog(ctx, account)
	admin.requests.logStage(account.Config.Label, "INFO", api.LogStage{Name: "账户登录", State: "completed"}, "账户登录完成", "duration", time.Since(startedAt))
	return admin.account(account.ID)
}

// replaceAccountState 以新登录状态替换账户的认证状态并沿用账户已有的续签材料，fingerprintDirectory 非空时一并替换 Camoufox 指纹
func replaceAccountState(lease *aistudio.AccountLease, state aistudio.StorageState, fingerprintDirectory string) error {
	account := lease.Account()
	if fingerprintDirectory != "" {
		if err := camoufoxnative.PersistAccountFingerprint(fingerprintDirectory, account.Directory); err != nil {
			return err
		}
	}
	if err := keepAuthExtension(&state, account.StorageState); err != nil {
		return err
	}
	return lease.SaveStorageState(state)
}

// setCookieAuthUser 把账户 Cookie 的会话序号改为 authUser 并同步到 Worker
func setCookieAuthUser(lease *aistudio.AccountLease, authUser int, prepare func(*aistudio.Account, aistudio.AccountConfig) (*accountWorkerUpdate, error)) error {
	account := lease.Account()
	if account.Config.AuthUser == authUser {
		return nil
	}
	accountConfig := account.Config
	accountConfig.AuthUser = authUser
	workerUpdate, err := prepare(account, accountConfig)
	if err != nil {
		return err
	}
	if err := lease.SaveConfig(accountConfig); err != nil {
		workerUpdate.Discard()
		return err
	}
	workerUpdate.Commit()
	return nil
}

// keepAuthExtension 在新登录状态没有 OAuth 续签材料时沿用账户已有的 Chrome 来源与 OAuth 材料，DBSC 会话登记属于旧会话不沿用
func keepAuthExtension(next *aistudio.StorageState, current aistudio.StorageState) error {
	if extension, _, err := next.AuthExtension(); err != nil || extension.OAuth != nil {
		return err
	}
	extension, _, err := current.AuthExtension()
	if err != nil || extension.OAuth == nil {
		return err
	}
	extension.Bound = nil
	next.SetAuthExtension(extension)
	return nil
}

// RefreshAccount 在服务生命周期中立即读取账户权益与模型目录，管理页断开不中止
func (admin *runtimeAdmin) RefreshAccount(_ context.Context, accountID string) (api.AdminAccountRefresh, error) {
	refresh, err := admin.service.refreshAccountState(admin.service.lifecycle, accountID, true)
	if err != nil {
		return api.AdminAccountRefresh{}, accountOperationError(err)
	}
	account, err := admin.account(accountID)
	if err != nil {
		return api.AdminAccountRefresh{}, err
	}
	return api.AdminAccountRefresh{
		Account: account, PreviousTier: refresh.PreviousTier.String(), Tier: refresh.Tier.String(),
		PreviousModels: refresh.PreviousModels, Models: refresh.Models,
	}, nil
}

// StartService 使用管理器提供的启动生命周期启动生成服务
func (admin *runtimeAdmin) StartService(ctx context.Context) (api.AdminStatus, error) {
	startedAt := time.Now()
	models, started, err := admin.service.Start(ctx, func() {
		status, _ := admin.Status(ctx)
		admin.publishRuntimeSnapshot(ctx, status)
	})
	if errors.Is(err, errServiceTransitioning) {
		return admin.Status(ctx)
	}
	if err != nil {
		status, _ := admin.Status(ctx)
		admin.publishRuntimeSnapshot(ctx, status)
		if errors.Is(err, context.Canceled) && admin.service.State() == "STOPPED" {
			admin.requests.logStage("service", "INFO", api.LogStage{Name: "生成服务启动", State: "cancelled"}, "生成服务启动已取消", "duration", time.Since(startedAt))
			return status, nil
		}
		admin.requests.logStage("service", "ERROR", api.LogStage{Name: "生成服务启动", State: "failed"}, "生成服务启动失败", "duration", time.Since(startedAt), "error", err)
		if errors.Is(err, aistudio.ErrNoEligibleAccount) {
			return api.AdminStatus{}, &adminOperationError{
				status: http.StatusBadRequest, code: "account_required", message: "请先启用一个可用账户",
			}
		}
		return api.AdminStatus{}, err
	}
	if len(models) == 0 {
		admin.requests.logStage("service", "ERROR", api.LogStage{Name: "生成服务启动", State: "failed"}, "生成服务启动失败", "duration", time.Since(startedAt), "error", "没有可用账户")
		return api.AdminStatus{}, &adminOperationError{
			status: http.StatusBadRequest, code: "account_required", message: "请先添加一个可用账户",
		}
	}
	if started {
		admin.requests.logStage("service", "INFO", api.LogStage{Name: "生成服务启动", State: "completed"}, "生成服务就绪",
			"models", len(models), "workers", fmt.Sprintf("%d/%d", len(admin.workers.WarmAccountIDs()), admin.workers.PrewarmTarget()),
			"duration", time.Since(startedAt))
	} else {
		admin.requests.log("service", "INFO", "生成服务运行中",
			"models", len(models), "workers", fmt.Sprintf("%d/%d", len(admin.workers.WarmAccountIDs()), admin.workers.PrewarmTarget()))
	}
	status, _ := admin.Status(ctx)
	admin.publishRuntimeSnapshot(ctx, status)
	return status, nil
}

func (admin *runtimeAdmin) StopService(ctx context.Context) (api.AdminStatus, error) {
	startedAt := time.Now()
	admin.requests.log("service", "INFO", "生成服务停止", "workers", len(admin.workers.WarmAccountIDs()))
	stopped, err := admin.service.Stop()
	if err != nil {
		admin.requests.log("service", "ERROR", "生成服务停止失败", "duration", time.Since(startedAt), "error", err)
		return api.AdminStatus{}, err
	}
	if stopped {
		admin.requests.log("service", "INFO", "生成服务已停止", "duration", time.Since(startedAt))
	} else {
		admin.requests.log("service", "INFO", "生成服务已处于停止状态")
	}
	status, _ := admin.Status(ctx)
	admin.publishRuntimeSnapshot(ctx, status)
	return status, nil
}

// syncModelCache 在账户写入后刷新权威快照
func (admin *runtimeAdmin) syncModelCache() {
	ctx := admin.lifecycle
	_ = admin.service.SyncModels(ctx)
	status, _ := admin.Status(ctx)
	admin.publishRuntimeSnapshot(ctx, status)
}

func (admin *runtimeAdmin) syncAccountModelCatalog(ctx context.Context, account *aistudio.Account) {
	models, err := admin.service.syncAccountModels(ctx, account.ID)
	if err != nil {
		admin.service.publishModelAccess()
		return
	}
	if len(models) > 0 {
		admin.requests.log(account.Config.Label, "INFO", "账户模型目录同步完成", "models", len(models))
	}
	admin.service.publishModelAccess()
}

// publishRuntimeSnapshot 推送管理页权威运行状态
func (admin *runtimeAdmin) publishRuntimeSnapshot(ctx context.Context, status api.AdminStatus) {
	models, _ := admin.CatalogModels(ctx)
	accounts, _ := admin.Accounts(ctx)
	admin.requests.publish(api.AdminEvent{Type: "status", Data: status})
	admin.requests.publish(api.AdminEvent{Type: "models", Data: map[string]any{"models": models}})
	admin.requests.publish(api.AdminEvent{Type: "accounts", Data: map[string]any{"accounts": accounts}})
}

func (admin *runtimeAdmin) account(accountID string) (api.AdminAccount, error) {
	for _, status := range admin.pool.Status() {
		if status.ID == accountID {
			return adminAccountDTO(status), nil
		}
	}
	return api.AdminAccount{}, accountOperationError(fmt.Errorf("%w: %s", aistudio.ErrAccountNotFound, accountID))
}

func (admin *runtimeAdmin) proxyPoolStatus() []api.AdminProxy {
	statuses := admin.proxies.Status()
	pool := make([]api.AdminProxy, 0, len(statuses))
	for _, status := range statuses {
		pool = append(pool, api.AdminProxy{
			Proxy: status.Proxy, Available: status.Available, Accounts: status.Accounts, CheckedAt: status.CheckedAt, Error: status.Error,
		})
	}
	return pool
}

func (admin *runtimeAdmin) effectiveProxy(accountProxy string) string {
	if proxy := strings.TrimSpace(accountProxy); proxy != "" {
		return proxy
	}
	if proxy := admin.proxies.Next(); proxy != "" {
		return proxy
	}
	return admin.globalProxy
}

func (admin *runtimeAdmin) loginRequest(account *aistudio.Account, directory string) aistudio.IsolatedLoginRequest {
	return aistudio.IsolatedLoginRequest{
		Directory: directory, Proxy: account.EffectiveProxy(admin.globalProxy),
		Locale: account.Config.Locale, Timezone: account.Config.Timezone,
	}
}

func adminAccountDTO(status aistudio.AccountStatus) api.AdminAccount {
	return api.AdminAccount{
		ID: status.ID, Label: status.Label, Enabled: status.Enabled, State: string(status.State),
		Proxy: status.Proxy, Egress: status.Egress, Locale: status.Locale, Timezone: status.Timezone,
		Models: status.Models, BenefitTier: status.BenefitTier, Message: status.Message,
		PairingRenewedAt: pairingRenewedAt(status.Directory),
		Transition:       string(status.Transition), ActiveRequests: status.ActiveRequests,
	}
}

// accountTimezone 返回去掉不可见字符后的账户时区，为空时返回空串，无法加载时返回带原值的错误
func accountTimezone(value string) (string, error) {
	timezone := aistudio.NormalizeTimezone(value)
	if timezone == "" {
		return "", nil
	}
	if _, err := time.LoadLocation(timezone); err != nil {
		return "", fmt.Errorf("账户 timezone 无效: %q", value)
	}
	return timezone, nil
}

func invalidAccount(err error) error {
	return &adminOperationError{
		status: http.StatusBadRequest, code: "invalid_account", message: err.Error(),
	}
}

func accountOperationError(err error) error {
	switch {
	case errors.Is(err, aistudio.ErrAccountNotFound):
		return &adminOperationError{
			status: http.StatusNotFound, code: "account_not_found", message: err.Error(),
		}
	case errors.Is(err, aistudio.ErrAccountLeased):
		return &adminOperationError{
			status: http.StatusConflict, code: "account_busy", message: err.Error(),
		}
	default:
		return err
	}
}

func (admin *runtimeAdmin) RuntimeConfig(context.Context) (api.RuntimeConfig, error) {
	cfg, err := config.Load(admin.configPath)
	if err != nil {
		return api.RuntimeConfig{}, err
	}
	value := runtimeConfigDTO(cfg)
	value.ActiveProxy = admin.config.Proxy
	value.ProxyPool = admin.proxyPoolStatus()
	return value, nil
}

func (admin *runtimeAdmin) UpdateRuntimeConfig(_ context.Context, value api.RuntimeConfig) (api.RuntimeConfig, error) {
	saved, err := config.Load(admin.configPath)
	if err != nil {
		return api.RuntimeConfig{}, err
	}
	password := saved.AdminPassword
	if value.AdminPassword != nil {
		password = *value.AdminPassword
	}
	initTimeout, err := time.ParseDuration(value.InitTimeout)
	if err != nil {
		return api.RuntimeConfig{}, invalidConfigError(fmt.Errorf("INIT_TIMEOUT 无效: %w", err))
	}
	requestTimeout, err := time.ParseDuration(value.RequestTimeout)
	if err != nil {
		return api.RuntimeConfig{}, invalidConfigError(fmt.Errorf("REQUEST_TIMEOUT 无效: %w", err))
	}
	cfg := config.Config{
		AutoStart:      value.AutoStart,
		HideDockIcon:   value.HideDockIcon,
		RequestBodyLog: value.RequestBodyLog,
		LogFile:        value.LogFile, LogMaxTotalMB: value.LogMaxTotalMB,
		AdminAuthEnabled: value.AdminAuthEnabled, AdminUsername: strings.TrimSpace(value.AdminUsername), AdminPassword: password,
		BuildNativeNonstream: value.BuildNativeNonstream,
		NonstreamKeepalive:   value.NonstreamKeepalive, FakeStream: value.FakeStream, YouTubeLinks: value.YouTubeLinks,
		SearchModelAliases: value.SearchModelAliases, DiscoverHiddenModels: value.DiscoverHiddenModels, GoogleSearch: value.GoogleSearch, StripThoughtSignatures: value.StripThoughtSignatures,
		ContinuationRewrite: value.ContinuationRewrite, ContinuationPrompt: strings.TrimSpace(value.ContinuationPrompt),
		FirstEventHedge: strings.ToLower(strings.TrimSpace(value.FirstEventHedge)), FirstEventHedgeModels: strings.TrimSpace(value.FirstEventHedgeModels), AuthStates: value.AuthStates, ListenAddr: value.ListenAddr, PreviewListenAddr: value.PreviewListenAddr,
		ProxyAPIKey: value.APIKey, Proxy: value.Proxy, InitTimeout: initTimeout, RequestTimeout: requestTimeout,
		WarmWorkerLimit: value.WarmWorkerLimit, MaxActiveWorkers: value.MaxActiveWorkers,
		WarmStartupConcurrency: value.WarmStartupConcurrency,
		PerAccountConcurrency:  value.PerAccountConcurrency,
		RoutingStrategy:        value.RoutingStrategy,
		AccountOrder:           strings.TrimSpace(value.AccountOrder),
		MaxAccountSwitches:     value.MaxAccountSwitches,
		UpstreamChannels:       value.UpstreamChannels,
		ModelMapping:           strings.TrimSpace(value.ModelMapping),
		ModelChannels:          strings.TrimSpace(value.ModelChannels),
		ModelAccounts:          strings.TrimSpace(value.ModelAccounts),
		APIKeyAccounts:         strings.TrimSpace(value.APIKeyAccounts),
		WAABackend:             value.WAABackend,
		MediaOutput:            strings.ToLower(strings.TrimSpace(value.MediaOutput)),
		MediaBaseURL:           strings.TrimSpace(value.MediaBaseURL),
	}.KeepEnvironment(saved)
	if err := cfg.Validate(); err != nil {
		return api.RuntimeConfig{}, invalidConfigError(err)
	}
	if err := cfg.Save(admin.configPath); err != nil {
		return api.RuntimeConfig{}, err
	}
	admin.pool.SetRoutingStrategy(cfg.RoutingStrategy)
	admin.pool.SetAccountOrder(accountOrder(cfg.AccountOrder))
	admin.pool.SetModelChannels(modelChannels(cfg.ModelChannels))
	admin.pool.SetModelAccounts(modelAccounts(cfg.ModelAccounts))
	admin.requests.log("service", "INFO", "服务配置已保存")
	models, _ := admin.CatalogModels(context.Background())
	admin.requests.publish(api.AdminEvent{Type: "models", Data: map[string]any{"models": models}})
	value = runtimeConfigDTO(cfg)
	value.ActiveProxy = admin.config.Proxy
	value.ProxyPool = admin.proxyPoolStatus()
	return value, nil
}

func (admin *runtimeAdmin) Cooldowns(context.Context) ([]api.AdminCooldown, error) {
	statuses := admin.pool.Status()
	cooldowns := make([]api.AdminCooldown, 0)
	now := time.Now()
	for _, account := range statuses {
		models := make(map[string]struct{}, len(account.Models))
		for _, modelID := range account.Models {
			models[modelID] = struct{}{}
		}
		effective := make(map[string]aistudio.CooldownState)
		scopes := make(map[string]string)
		if global, ok := account.Cooldowns["*"]; ok && global.Active(now) {
			for modelID := range models {
				effective[modelID] = global
				scopes[modelID] = "*"
			}
		}
		for key, cooldown := range account.Cooldowns {
			if key == "*" || !cooldown.Active(now) {
				continue
			}
			modelID, build := strings.CutPrefix(key, string(aistudio.ChannelBuild)+":")
			if _, ok := models[modelID]; !ok && !build {
				continue
			}
			if current, ok := effective[key]; !ok || cooldown.Until.After(current.Until) {
				effective[key] = cooldown
				scopes[key] = key
			}
		}
		modelIDs := make([]string, 0, len(effective))
		for modelID := range effective {
			modelIDs = append(modelIDs, modelID)
		}
		sort.Strings(modelIDs)
		for _, key := range modelIDs {
			cooldown := effective[key]
			channel := string(aistudio.ChannelPlayground)
			modelID, build := strings.CutPrefix(key, string(aistudio.ChannelBuild)+":")
			if build {
				channel = string(aistudio.ChannelBuild)
			} else if admin.pool.AssistantModel(modelID) {
				channel = string(aistudio.ChannelAssistant)
			}
			cooldowns = append(cooldowns, api.AdminCooldown{
				AccountID: account.ID, AccountLabel: account.Label, Channel: channel,
				ModelID: modelID, Scope: scopes[key], Until: cooldown.Until, Reason: cooldown.Reason,
			})
		}
	}
	return cooldowns, nil
}

// ClearCooldown 手动清除账户在一个作用域上的冷却，并推送新的冷却列表与账户状态
func (admin *runtimeAdmin) ClearCooldown(ctx context.Context, accountID string, scope string) error {
	account, err := admin.account(accountID)
	if err != nil {
		return err
	}
	if err := admin.pool.ClearCooldown(accountID, scope); err != nil {
		return err
	}
	admin.requests.log(account.Label, "INFO", "冷却已手动清除", "scope", scope)
	cooldowns, _ := admin.Cooldowns(ctx)
	admin.requests.publish(api.AdminEvent{Type: "cooldowns", Data: cooldowns})
	accounts, _ := admin.Accounts(ctx)
	admin.requests.publish(api.AdminEvent{Type: "accounts", Data: map[string]any{"accounts": accounts}})
	return nil
}

func (admin *runtimeAdmin) Requests(context.Context) ([]api.AdminRequest, error) {
	return admin.requests.list(), nil
}

func (admin *runtimeAdmin) CancelRequest(_ context.Context, id string) error {
	return admin.requests.cancel(id)
}

// adminEventSource 提供管理事件流的当前快照
type adminEventSource interface {
	CatalogModels(context.Context) ([]aistudio.Model, error)
	Status(context.Context) (api.AdminStatus, error)
	Accounts(context.Context) ([]api.AdminAccount, error)
	Cooldowns(context.Context) ([]api.AdminCooldown, error)
}

// CatalogModels 返回当前运行时完整目录与各模型可用通道
func (admin *runtimeAdmin) CatalogModels(ctx context.Context) ([]aistudio.Model, error) {
	return admin.service.catalogModels(), nil
}

// openAdminEvents 创建绑定进程生命周期的管理事件流
func openAdminEvents(
	ctx context.Context,
	lifecycle context.Context,
	requests *requestRegistry,
	source adminEventSource,
) (<-chan api.AdminEvent, error) {
	eventCtx, cancel := context.WithCancel(ctx)
	stopLifecycle := context.AfterFunc(lifecycle, cancel)
	subscriber := requests.subscribe(eventCtx)
	models, err := source.CatalogModels(eventCtx)
	if err != nil {
		stopLifecycle()
		cancel()
		return nil, err
	}
	status, err := source.Status(eventCtx)
	if err != nil {
		stopLifecycle()
		cancel()
		return nil, err
	}
	accounts, err := source.Accounts(eventCtx)
	if err != nil {
		stopLifecycle()
		cancel()
		return nil, err
	}
	cooldowns, err := source.Cooldowns(eventCtx)
	if err != nil {
		stopLifecycle()
		cancel()
		return nil, err
	}
	live := requests.activateSubscriber(
		subscriber,
		[]api.AdminEvent{
			{Type: "status", Data: status},
			{Type: "models", Data: map[string]any{"models": models}},
			{Type: "accounts", Data: map[string]any{"accounts": accounts}},
		},
		[]api.AdminEvent{{Type: "cooldowns", Data: cooldowns}},
	)
	events := make(chan api.AdminEvent, 16)
	go func() {
		defer stopLifecycle()
		defer cancel()
		defer close(events)
		var refreshTimer *time.Timer
		var refresh <-chan time.Time
		refreshAccounts := false
		refreshCooldowns := false
		defer func() {
			if refreshTimer != nil {
				refreshTimer.Stop()
			}
		}()
		// sent 是本连接各类快照最近一次发出的内容，内容相同的快照跳过发送
		sent := map[string][]byte{}
		send := func(event api.AdminEvent) bool {
			switch event.Type {
			case "status", "models", "accounts", "cooldowns":
				encoded, err := json.Marshal(event.Data)
				if err == nil && bytes.Equal(encoded, sent[event.Type]) {
					return true
				}
				sent[event.Type] = encoded
			}
			select {
			case events <- event:
				return true
			case <-eventCtx.Done():
				return false
			}
		}
		scheduleRequestRefresh := func(event api.AdminEvent) {
			request := event.Data.(api.AdminRequest)
			if request.State != "queued" {
				refreshAccounts = true
			}
			if request.State != "queued" && request.State != "running" {
				refreshCooldowns = true
			}
			if refresh != nil {
				return
			}
			if refreshTimer == nil {
				refreshTimer = time.NewTimer(adminRequestRefreshLatency)
			} else {
				refreshTimer.Reset(adminRequestRefreshLatency)
			}
			refresh = refreshTimer.C
		}
		for {
			select {
			case event, ok := <-live:
				if !ok {
					return
				}
				if !send(event) {
					return
				}
				if event.Type == "request" {
					scheduleRequestRefresh(event)
				}
			case <-refresh:
				refresh = nil
				accountsChanged := refreshAccounts
				cooldownsChanged := refreshCooldowns
				refreshAccounts = false
				refreshCooldowns = false
				updates, err := adminRequestStateUpdates(eventCtx, source, accountsChanged, cooldownsChanged)
				if err != nil {
					return
				}
				for _, update := range updates {
					if !send(update) {
						return
					}
				}
			case <-eventCtx.Done():
				return
			}
		}
	}()
	return events, nil
}

// adminRequestStateUpdates 合并请求状态引起的管理页快照变化
func adminRequestStateUpdates(
	ctx context.Context,
	source adminEventSource,
	accountsChanged bool,
	cooldownsChanged bool,
) ([]api.AdminEvent, error) {
	status, err := source.Status(ctx)
	if err != nil {
		return nil, err
	}
	updates := []api.AdminEvent{{Type: "status", Data: status}}
	if accountsChanged {
		accounts, accountsErr := source.Accounts(ctx)
		if accountsErr != nil {
			return nil, accountsErr
		}
		updates = append(updates, api.AdminEvent{Type: "accounts", Data: map[string]any{"accounts": accounts}})
	}
	if cooldownsChanged {
		cooldowns, cooldownsErr := source.Cooldowns(ctx)
		if cooldownsErr != nil {
			return nil, cooldownsErr
		}
		updates = append(updates, api.AdminEvent{Type: "cooldowns", Data: cooldowns})
	}
	return updates, nil
}

// version 是编译时写入的版本号
var version string

// managedBy 是编译时写入的更新管理方，非空时在线更新由该分发方负责
var managedBy string

// buildVersion 返回链接时写入的版本号，没有时读取 Go 构建信息
func buildVersion() string {
	if version != "" {
		return version
	}
	info, ok := debug.ReadBuildInfo()
	if !ok || info.Main.Version == "" {
		return "(devel)"
	}
	return info.Main.Version
}

func runtimeConfigDTO(cfg config.Config) api.RuntimeConfig {
	return api.RuntimeConfig{
		AutoStart:      cfg.AutoStart,
		HideDockIcon:   cfg.HideDockIcon,
		RequestBodyLog: cfg.RequestBodyLog,
		LogFile:        cfg.LogFile, LogMaxTotalMB: cfg.LogMaxTotalMB,
		AdminAuthEnabled: cfg.AdminAuthEnabled, AdminUsername: cfg.AdminUsername,
		AdminPasswordSet: cfg.AdminPassword != "", SavedAdminPassword: cfg.AdminPassword,
		BuildNativeNonstream: cfg.BuildNativeNonstream,
		NonstreamKeepalive:   cfg.NonstreamKeepalive, FakeStream: cfg.FakeStream, YouTubeLinks: cfg.YouTubeLinks,
		SearchModelAliases: cfg.SearchModelAliases, DiscoverHiddenModels: cfg.DiscoverHiddenModels, GoogleSearch: cfg.GoogleSearch, StripThoughtSignatures: cfg.StripThoughtSignatures,
		ContinuationRewrite: cfg.ContinuationRewrite, ContinuationPrompt: cfg.ContinuationPrompt,
		FirstEventHedge: cfg.FirstEventHedge, FirstEventHedgeModels: cfg.FirstEventHedgeModels, AuthStates: cfg.AuthStates, ListenAddr: cfg.ListenAddr, APIKey: cfg.ProxyAPIKey,
		ActiveListenAddr: cfg.ListenAddr, ActiveAPIKey: cfg.ProxyAPIKey,
		PreviewListenAddr: cfg.PreviewListenAddr, ActivePreviewListenAddr: cfg.PreviewListenAddr,
		Proxy: cfg.Proxy, InitTimeout: cfg.InitTimeout.String(), RequestTimeout: cfg.RequestTimeout.String(),
		WarmWorkerLimit: cfg.WarmWorkerLimit, MaxActiveWorkers: cfg.MaxActiveWorkers,
		WarmStartupConcurrency: cfg.WarmStartupConcurrency,
		PerAccountConcurrency:  cfg.PerAccountConcurrency,
		RoutingStrategy:        cfg.RoutingStrategy,
		AccountOrder:           cfg.AccountOrder,
		MaxAccountSwitches:     cfg.MaxAccountSwitches,
		UpstreamChannels:       cfg.UpstreamChannels,
		ModelMapping:           cfg.ModelMapping,
		ModelChannels:          cfg.ModelChannels,
		ModelAccounts:          cfg.ModelAccounts,
		APIKeyAccounts:         cfg.APIKeyAccounts,
		WAABackend:             cfg.WAABackend,
		MediaOutput:            cfg.MediaOutput,
		MediaBaseURL:           cfg.MediaBaseURL,
		Environment:            append([]string{}, cfg.Environment...),
		Invalid:                invalidConfigDTO(cfg.Invalid),
	}
}

// invalidConfigDTO 把加载时无效的配置项转为管理接口的表示
func invalidConfigDTO(values []config.InvalidValue) []api.InvalidConfigValue {
	result := make([]api.InvalidConfigValue, 0, len(values))
	for _, value := range values {
		result = append(result, api.InvalidConfigValue{Key: value.Key, Value: value.Value, Reason: value.Reason})
	}
	return result
}

var _ generationAdmin = (*runtimeAdmin)(nil)
