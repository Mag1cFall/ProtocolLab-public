package chromeauth

import (
	"bytes"
	"context"
	"crypto/ecdh"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/hpke"
	"crypto/rand"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math/big"
	"net/url"
	"os"
	"path/filepath"
	"slices"
	"strings"

	http "github.com/bogdanfinn/fhttp"
	tls_client "github.com/bogdanfinn/tls-client"

	"github.com/Mag1cFall/AIStudio2API/internal/aistudio"
)

// ErrCredentialsRejected 表示上游已拒绝保存的 Chrome 续签材料
var ErrCredentialsRejected = errors.New("Chrome OAuth 续签材料失效")

// multiloginStatusError 保留续签阶段和上游状态
func multiloginStatusError(phase string, statusCode int, status string) error {
	err := fmt.Errorf("OAuthMultilogin %s 阶段失败 HTTP %d status %s", phase, statusCode, status)
	if status == "INVALID_TOKENS" {
		return errors.Join(ErrCredentialsRejected, err)
	}
	return err
}

// multiloginURL 是 OAuthMultilogin 的地址
var multiloginURL = "https://accounts.google.com/oauth/multilogin?source=ChromiumAccountReconcilorDice&reuseCookies=0"

// gaiaURL 是解析 DBSC 相对刷新地址的 Gaia 地址
var gaiaURL = &url.URL{Scheme: "https", Host: "accounts.google.com", Path: "/"}

const (
	oauthClientID     = "77185425430.apps.googleusercontent.com"
	assertionAudience = "https://accounts.google.com/accountmanager"
	assertionSentinel = "DBSC_CHALLENGE_IF_REQUIRED"
)

type multiloginCookie struct {
	Name       string   `json:"name"`
	Value      string   `json:"value"`
	Domain     string   `json:"domain"`
	Host       string   `json:"host"`
	Path       string   `json:"path"`
	MaxAge     *float64 `json:"maxAge"`
	IsHTTPOnly bool     `json:"isHttpOnly"`
	IsSecure   bool     `json:"isSecure"`
	SameSite   string   `json:"sameSite"`
}

type multiloginResponse struct {
	Status         string             `json:"status"`
	Cookies        []multiloginCookie `json:"cookies"`
	Directed       json.RawMessage    `json:"token_binding_directed_response"`
	FailedAccounts []struct {
		Retry struct {
			Challenge string `json:"challenge"`
		} `json:"token_binding_retry_response"`
	} `json:"failed_accounts"`
	BoundSessions []struct {
		IsDeviceBound bool   `json:"is_device_bound"`
		Domain        string `json:"domain"`
		Payload       *struct {
			SessionID   string `json:"session_identifier"`
			RefreshURL  string `json:"refresh_url"`
			Credentials []struct {
				Name string `json:"name"`
			} `json:"credentials"`
		} `json:"register_session_payload"`
	} `json:"device_bound_session_info"`
}

// googleBoundSession 返回响应为 google.com 登记的 DBSC 会话，相对刷新地址按 Gaia 地址解析
func (response multiloginResponse) googleBoundSession() *aistudio.BoundSession {
	for _, session := range response.BoundSessions {
		if !session.IsDeviceBound || session.Domain != "GOOGLE_COM" || session.Payload == nil {
			continue
		}
		refreshURL, err := url.Parse(session.Payload.RefreshURL)
		if err != nil {
			return nil
		}
		bound := &aistudio.BoundSession{ID: session.Payload.SessionID, RefreshURL: gaiaURL.ResolveReference(refreshURL).String()}
		for _, credential := range session.Payload.Credentials {
			bound.Credentials = append(bound.Credentials, credential.Name)
		}
		return bound
	}
	return nil
}

type deviceBindingKey interface {
	PublicKey() ([]byte, error)
	SignSHA256([]byte) ([]byte, error)
	Close()
}

// multiloginHeaderOrder 是 Chrome GaiaAuthFetcher 发出 OAuthMultilogin 的请求头顺序
var multiloginHeaderOrder = []string{"content-length", "authorization", "content-type", "sec-fetch-site", "sec-fetch-mode", "sec-fetch-dest", "user-agent", "accept-encoding", "accept-language", "priority"}

// chromeIdentity 是本机 Chrome profile 发出 Gaia 请求时的 User-Agent 与 Accept-Language
type chromeIdentity struct {
	userAgent      string
	acceptLanguage string
}

// readChromeIdentity 按 User Data 的 Last Version 与 profile 的语言设置生成 Chrome 的 User-Agent 与 Accept-Language
func readChromeIdentity(chromeRoot string, profile string) (chromeIdentity, error) {
	version, err := os.ReadFile(filepath.Join(chromeRoot, "Last Version"))
	if err != nil {
		return chromeIdentity{}, fmt.Errorf("读取 Chrome 版本: %w", err)
	}
	major, _, _ := strings.Cut(strings.TrimSpace(string(version)), ".")
	return chromeIdentity{
		userAgent:      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + major + ".0.0.0 Safari/537.36",
		acceptLanguage: acceptLanguageHeader(profileLanguages(chromeRoot, profile)),
	}, nil
}

// profileLanguages 返回 profile 的 intl.accept_languages，等于默认值未写入时返回 intl.selected_languages
func profileLanguages(chromeRoot string, profile string) string {
	data, err := os.ReadFile(filepath.Join(chromeRoot, profile, "Preferences"))
	if err != nil {
		return ""
	}
	var preferences struct {
		Intl struct {
			AcceptLanguages   string `json:"accept_languages"`
			SelectedLanguages string `json:"selected_languages"`
		} `json:"intl"`
	}
	if json.Unmarshal(data, &preferences) != nil {
		return ""
	}
	if strings.TrimSpace(preferences.Intl.AcceptLanguages) != "" {
		return preferences.Intl.AcceptLanguages
	}
	return preferences.Intl.SelectedLanguages
}

// acceptLanguageHeader 按 Chromium HttpUtil 的 ExpandLanguageList 与 GenerateAcceptLanguageHeader 把语言设置展开为 Accept-Language
func acceptLanguageHeader(languages string) string {
	items := strings.Split(languages, ",")
	primary := func(language string) string {
		base, _, _ := strings.Cut(language, "-")
		return strings.TrimSpace(base)
	}
	var expanded []string
	add := func(language string) {
		if !slices.Contains(expanded, language) {
			expanded = append(expanded, language)
		}
	}
	for index, item := range items {
		language := strings.TrimSpace(item)
		add(language)
		base := primary(language)
		if base == "x" || base == "i" {
			continue
		}
		if index+1 == len(items) || primary(items[index+1]) != base {
			add(base)
		}
	}
	var header strings.Builder
	quality := 10
	for index, language := range expanded {
		if index == 0 {
			header.WriteString(language)
		} else {
			fmt.Fprintf(&header, ",%s;q=0.%d", language, quality)
		}
		if quality > 1 {
			quality--
		}
	}
	return header.String()
}

// fetchGoogleCookies 用 refresh token 经 OAuthMultilogin 取得 Google Cookie，有设备绑定密钥时走 DBSC 挑战与 HPKE 解密，并返回 google.com 的 DBSC 会话登记
func fetchGoogleCookies(ctx context.Context, identity chromeIdentity, gaiaID string, token string, wrappedKey []byte, proxyURL string) ([]multiloginCookie, *aistudio.BoundSession, error) {
	client, err := newOAuthClient(proxyURL, chromeIdle)
	if err != nil {
		return nil, nil, err
	}
	defer client.CloseIdleConnections()
	if len(wrappedKey) == 0 {
		cookies, err := fetchBearerCookies(ctx, client, identity, gaiaID, token)
		return cookies, nil, err
	}
	return fetchBoundCookies(ctx, client, identity, gaiaID, token, wrappedKey)
}

// fetchBearerCookies 为没有设备绑定的 token 请求一次 OAuthMultilogin，返回明文 Cookie
func fetchBearerCookies(ctx context.Context, client tls_client.HttpClient, identity chromeIdentity, gaiaID string, token string) ([]multiloginCookie, error) {
	status, response, err := requestMultilogin(ctx, client, identity, gaiaID, token, "")
	if err != nil {
		return nil, err
	}
	if status != http.StatusOK || response.Status != "OK" {
		return nil, multiloginStatusError("bearer", status, response.Status)
	}
	if err := checkMultiloginCookies(response.Cookies); err != nil {
		return nil, err
	}
	return response.Cookies, nil
}

// fetchBoundCookies 为设备绑定的 token 取得 DBSC challenge、以设备密钥签发 assertion，再解密服务端返回的 Cookie
func fetchBoundCookies(ctx context.Context, client tls_client.HttpClient, identity chromeIdentity, gaiaID string, token string, wrappedKey []byte) ([]multiloginCookie, *aistudio.BoundSession, error) {
	bindingKey, err := openDeviceBindingKey(wrappedKey)
	if err != nil {
		return nil, nil, err
	}
	defer bindingKey.Close()
	spki, err := bindingKey.PublicKey()
	if err != nil {
		return nil, nil, err
	}

	firstStatus, first, err := requestMultilogin(ctx, client, identity, gaiaID, token, assertionSentinel)
	if err != nil {
		return nil, nil, err
	}
	challenge := findChallenge(first)
	if first.Status != "RETRY" || challenge == "" {
		return nil, nil, multiloginStatusError("challenge", firstStatus, first.Status)
	}

	ephemeralPrivateKey, err := ecdh.X25519().GenerateKey(rand.Reader)
	if err != nil {
		return nil, nil, fmt.Errorf("生成 HPKE 临时密钥: %w", err)
	}
	assertion, err := createAssertion(bindingKey, spki, challenge, ephemeralPrivateKey.PublicKey().Bytes())
	if err != nil {
		return nil, nil, err
	}
	secondStatus, second, err := requestMultilogin(ctx, client, identity, gaiaID, token, assertion)
	if err != nil {
		return nil, nil, err
	}
	if secondStatus != http.StatusOK || second.Status != "OK" {
		return nil, nil, multiloginStatusError("assertion", secondStatus, second.Status)
	}
	if len(second.Directed) == 0 || bytes.Equal(second.Directed, []byte("null")) {
		return nil, nil, fmt.Errorf("OAuthMultilogin 响应缺少 token_binding_directed_response")
	}
	if err := checkMultiloginCookies(second.Cookies); err != nil {
		return nil, nil, err
	}
	for index := range second.Cookies {
		if second.Cookies[index].Value, err = hpkeOpen(ephemeralPrivateKey, second.Cookies[index].Value); err != nil {
			return nil, nil, err
		}
	}
	return second.Cookies, second.googleBoundSession(), nil
}

// checkMultiloginCookies 核对 OAuthMultilogin 返回的 Cookie 带有名称、值、域，并包含 SAPISID 与 __Secure-1PSID
func checkMultiloginCookies(cookies []multiloginCookie) error {
	if len(cookies) == 0 {
		return fmt.Errorf("OAuthMultilogin 响应缺少 Cookie")
	}
	names := make(map[string]struct{}, len(cookies))
	for _, cookie := range cookies {
		if cookie.Name == "" || cookie.Value == "" {
			return fmt.Errorf("OAuthMultilogin Cookie 格式异常")
		}
		if cookie.Domain == "" && (cookie.Host == "" || strings.HasPrefix(cookie.Host, ".")) {
			return fmt.Errorf("OAuthMultilogin Cookie 域格式异常")
		}
		names[cookie.Name] = struct{}{}
	}
	for _, required := range []string{"SAPISID", "__Secure-1PSID"} {
		if _, ok := names[required]; !ok {
			return fmt.Errorf("OAuthMultilogin 缺少核心 Cookie: %s", required)
		}
	}
	return nil
}

// requestMultilogin 按 Chrome 的请求头发送一次 OAuthMultilogin：带 assertion 时用 MultiOAuth 头，没有设备绑定的 token 用 MultiBearer 头
func requestMultilogin(ctx context.Context, client tls_client.HttpClient, identity chromeIdentity, gaiaID string, token string, assertion string) (int, multiloginResponse, error) {
	authorization := "MultiBearer " + token + ":" + gaiaID
	if assertion != "" {
		authorization = "MultiOAuth " + encodeMultiOAuthHeader(gaiaID, token, assertion)
	}
	request, err := http.NewRequestWithContext(ctx, http.MethodPost, multiloginURL, strings.NewReader(" "))
	if err != nil {
		return 0, multiloginResponse{}, fmt.Errorf("创建 OAuthMultilogin 请求: %w", err)
	}
	request.Header.Set("Authorization", authorization)
	request.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	request.Header.Set("Sec-Fetch-Site", "none")
	request.Header.Set("Sec-Fetch-Mode", "no-cors")
	request.Header.Set("Sec-Fetch-Dest", "empty")
	request.Header.Set("User-Agent", identity.userAgent)
	request.Header.Set("Accept-Encoding", "gzip, deflate, br, zstd")
	request.Header.Set("Accept-Language", identity.acceptLanguage)
	request.Header.Set("Priority", "u=4, i")
	request.Header[http.HeaderOrderKey] = multiloginHeaderOrder
	response, err := client.Do(request)
	if err != nil {
		return 0, multiloginResponse{}, fmt.Errorf("OAuthMultilogin 请求失败: %w", err)
	}
	defer response.Body.Close()
	body, err := io.ReadAll(io.LimitReader(response.Body, 8<<20))
	if err != nil {
		return response.StatusCode, multiloginResponse{}, fmt.Errorf("读取 OAuthMultilogin 响应: %w", err)
	}
	body = bytes.TrimSpace(body)
	if bytes.HasPrefix(body, []byte(")]}'")) {
		body = bytes.TrimSpace(body[4:])
	}
	var result multiloginResponse
	if err := json.Unmarshal(body, &result); err != nil {
		return response.StatusCode, multiloginResponse{}, fmt.Errorf("OAuthMultilogin 返回无法解析的响应 HTTP %d", response.StatusCode)
	}
	return response.StatusCode, result, nil
}

func findChallenge(response multiloginResponse) string {
	for _, account := range response.FailedAccounts {
		if account.Retry.Challenge != "" {
			return account.Retry.Challenge
		}
	}
	return ""
}

func encodeMultiOAuthHeader(gaiaID string, token string, assertion string) string {
	account := appendBytesField(nil, 1, []byte(gaiaID))
	account = appendBytesField(account, 2, []byte(token))
	account = appendBytesField(account, 3, []byte(assertion))
	return base64.RawURLEncoding.EncodeToString(appendBytesField(nil, 1, account))
}

func createTinkHPKEKeyset(publicKey []byte) []byte {
	params := appendVarintField(nil, 1, 1)
	params = appendVarintField(params, 2, 1)
	params = appendVarintField(params, 3, 1)
	hpkePublicKey := appendVarintField(nil, 1, 0)
	hpkePublicKey = appendBytesField(hpkePublicKey, 2, params)
	hpkePublicKey = appendBytesField(hpkePublicKey, 3, publicKey)
	keyData := appendBytesField(nil, 1, []byte("type.googleapis.com/google.crypto.tink.HpkePublicKey"))
	keyData = appendBytesField(keyData, 2, hpkePublicKey)
	keyData = appendVarintField(keyData, 3, 3)
	key := appendBytesField(nil, 1, keyData)
	key = appendVarintField(key, 2, 1)
	key = appendVarintField(key, 3, 1)
	key = appendVarintField(key, 4, 3)
	keyset := appendVarintField(nil, 1, 1)
	return appendBytesField(keyset, 2, key)
}

func createAssertion(bindingKey deviceBindingKey, spki []byte, challenge string, ephemeralPublicKey []byte) (string, error) {
	header := struct {
		Algorithm string `json:"alg"`
		Type      string `json:"typ"`
		Schema    string `json:"schema"`
	}{"ES256", "jwt", "DEVICE_BOUND_SESSION_CREDENTIALS_ASSERTION"}
	payload := struct {
		Subject      string `json:"sub"`
		Audience     string `json:"aud"`
		JWTID        string `json:"jti"`
		Issuer       string `json:"iss"`
		Namespace    string `json:"namespace"`
		EphemeralKey struct {
			KeyType string `json:"kty"`
			KeyInfo string `json:"TinkKeysetPublicKeyInfo"`
		} `json:"ephemeral_key"`
	}{Subject: oauthClientID, Audience: assertionAudience, JWTID: challenge, Namespace: "TokenBinding"}
	issuer := sha256.Sum256(spki)
	payload.Issuer = base64.RawURLEncoding.EncodeToString(issuer[:])
	payload.EphemeralKey.KeyType = "type.googleapis.com/google.crypto.tink.EciesAeadHkdfPublicKey"
	payload.EphemeralKey.KeyInfo = base64.RawURLEncoding.EncodeToString(createTinkHPKEKeyset(ephemeralPublicKey))
	encodedHeader, err := json.Marshal(header)
	if err != nil {
		return "", fmt.Errorf("编码 token binding header: %w", err)
	}
	encodedPayload, err := json.Marshal(payload)
	if err != nil {
		return "", fmt.Errorf("编码 token binding payload: %w", err)
	}
	signingInput := base64.RawURLEncoding.EncodeToString(encodedHeader) + "." + base64.RawURLEncoding.EncodeToString(encodedPayload)
	signature, err := bindingKey.SignSHA256([]byte(signingInput))
	if err != nil {
		return "", err
	}
	return signingInput + "." + base64.RawURLEncoding.EncodeToString(signature), nil
}

func hpkeOpen(privateKey *ecdh.PrivateKey, encodedValue string) (string, error) {
	encrypted, err := base64.RawURLEncoding.DecodeString(encodedValue)
	if err != nil {
		return "", fmt.Errorf("OAuthMultilogin Cookie 密文格式异常")
	}
	recipientKey, err := hpke.NewDHKEMPrivateKey(privateKey)
	if err != nil {
		return "", fmt.Errorf("创建 HPKE 接收密钥: %w", err)
	}
	plaintext, err := hpke.Open(recipientKey, hpke.HKDFSHA256(), hpke.AES128GCM(), nil, encrypted)
	if err != nil {
		return "", fmt.Errorf("OAuthMultilogin Cookie 解密失败")
	}
	return string(plaintext), nil
}

func appendBytesField(output []byte, number int, value []byte) []byte {
	output = appendVarint(output, uint64(number<<3|2))
	output = appendVarint(output, uint64(len(value)))
	return append(output, value...)
}

func appendVarintField(output []byte, number int, value uint64) []byte {
	output = appendVarint(output, uint64(number<<3))
	return appendVarint(output, value)
}

func appendVarint(output []byte, value uint64) []byte {
	for value >= 0x80 {
		output = append(output, byte(value)|0x80)
		value >>= 7
	}
	return append(output, byte(value))
}

func parsePublicKeyBlob(blob []byte) ([]byte, error) {
	if len(blob) != 72 || binary.LittleEndian.Uint32(blob[4:8]) != 32 {
		return nil, fmt.Errorf("NCrypt ECDSA 公钥格式异常")
	}
	spki, err := x509.MarshalPKIXPublicKey(&ecdsa.PublicKey{Curve: elliptic.P256(), X: new(big.Int).SetBytes(blob[8:40]), Y: new(big.Int).SetBytes(blob[40:72])})
	if err != nil {
		return nil, fmt.Errorf("编码 NCrypt ECDSA 公钥: %w", err)
	}
	return spki, nil
}
