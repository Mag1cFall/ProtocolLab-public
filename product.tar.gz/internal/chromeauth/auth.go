package chromeauth

import (
	"context"
	"crypto/aes"
	"crypto/cipher"
	"fmt"
	"sort"
	"strings"
	"time"

	"github.com/Mag1cFall/AIStudio2API/internal/aistudio"
	"github.com/Mag1cFall/AIStudio2API/internal/config"
)

const maxCookieAge = 400 * 24 * time.Hour

// Account 描述本机 Chrome 中可发现的 Google 账号
type Account struct {
	ID          string `json:"id"`
	GaiaID      string `json:"-"`
	Profile     string `json:"profile"`
	DisplayName string `json:"display_name"`
	Email       string `json:"email"`
	Importable  bool   `json:"importable"`
}

// ImportOptions 保存 Chrome 批量导入参数
type ImportOptions struct {
	AccountIDs []string
	ChromeRoot string
	Proxy      string
	Profiles   []string
	Emails     []string
}

// ImportResult 返回一个已验证前的账号状态
type ImportResult struct {
	Profile     string
	DisplayName string
	Email       string
	CookieCount int
	State       aistudio.StorageState
}

// Import 用本机 Chrome 的 OAuth 续签材料生成 Playwright storage state
func Import(ctx context.Context, options ImportOptions) ([]ImportResult, error) {
	if err := ensurePlatformImport(); err != nil {
		return nil, err
	}
	proxyURL := strings.TrimSpace(options.Proxy)
	if err := config.ValidateProxy(proxyURL); err != nil {
		return nil, err
	}
	accounts, err := Discover(options.ChromeRoot)
	if err != nil {
		return nil, err
	}
	selected, err := selectAccounts(accounts, options.Profiles, options.Emails, options.AccountIDs)
	if err != nil {
		return nil, err
	}
	masterKey, err := retrieveV20Key(options.ChromeRoot)
	if err != nil {
		return nil, err
	}
	results := make([]ImportResult, 0, len(selected))
	for _, account := range selected {
		result, err := importAccount(ctx, options.ChromeRoot, proxyURL, account, masterKey)
		if err != nil {
			return nil, fmt.Errorf("导入 %s: %w", account.Profile, err)
		}
		results = append(results, result)
	}
	return results, nil
}

// Refresh 以导入来源 Chrome profile 的身份使用保存的 OAuth 续签材料重新签发 Google Cookie，并返回 google.com 的 DBSC 会话登记
func Refresh(ctx context.Context, source aistudio.AuthSource, material aistudio.ChromeOAuthMaterial, proxy string) ([]aistudio.StateCookie, *aistudio.BoundSession, error) {
	identity, proxyURL, err := sourceIdentity(source, proxy)
	if err != nil {
		return nil, nil, err
	}
	cookies, bound, err := fetchGoogleCookies(ctx, identity, material.GaiaID, material.RefreshToken, material.WrappedBindingKey, proxyURL)
	if err != nil {
		return nil, nil, err
	}
	return toStorageCookies(cookies), bound, nil
}

// sourceIdentity 返回导入来源 Chrome profile 的请求身份与校验后的代理，来源未记录目录时使用稳定版 Chrome 目录
func sourceIdentity(source aistudio.AuthSource, proxy string) (chromeIdentity, string, error) {
	if err := ensurePlatformImport(); err != nil {
		return chromeIdentity{}, "", err
	}
	proxyURL := strings.TrimSpace(proxy)
	err := config.ValidateProxy(proxyURL)
	if err != nil {
		return chromeIdentity{}, "", err
	}
	root := source.Root
	if root == "" {
		if root, err = DefaultChromeRoot(); err != nil {
			return chromeIdentity{}, "", err
		}
	}
	identity, err := readChromeIdentity(root, source.Profile)
	return identity, proxyURL, err
}

func importAccount(ctx context.Context, chromeRoot string, proxy string, account Account, masterKey []byte) (ImportResult, error) {
	gaiaID, encryptedToken, wrappedKey, err := readTokenService(chromeRoot, account.Profile, account.GaiaID)
	if err != nil {
		return ImportResult{}, err
	}
	token, err := decryptV20Token(masterKey, encryptedToken)
	if err != nil {
		return ImportResult{}, err
	}
	identity, err := readChromeIdentity(chromeRoot, account.Profile)
	if err != nil {
		return ImportResult{}, err
	}
	cookies, bound, err := fetchGoogleCookies(ctx, identity, gaiaID, token, wrappedKey, proxy)
	if err != nil {
		return ImportResult{}, err
	}
	state := aistudio.StorageState{Cookies: toStorageCookies(cookies), Origins: []aistudio.StorageOrigin{}}
	state.SetAuthExtension(aistudio.AuthExtension{
		Source: aistudio.AuthSource{Browser: "chrome", Root: chromeRoot, Profile: account.Profile, Email: strings.ToLower(strings.TrimSpace(account.Email))},
		OAuth: &aistudio.ChromeOAuthMaterial{
			GaiaID: gaiaID, RefreshToken: token, WrappedBindingKey: append([]byte(nil), wrappedKey...),
		},
		Bound: bound,
	})
	return ImportResult{
		Profile: account.Profile, DisplayName: account.DisplayName,
		Email:       strings.ToLower(strings.TrimSpace(account.Email)),
		CookieCount: len(cookies), State: state,
	}, nil
}

func selectAccounts(accounts []Account, profiles []string, emails []string, ids []string) ([]Account, error) {
	requestedIDs := normalizedSet(ids)
	requestedProfiles := normalizedSet(profiles)
	requestedEmails := normalizedSet(emails)
	if len(requestedProfiles) == 0 && len(requestedEmails) == 0 && len(requestedIDs) == 0 {
		return nil, fmt.Errorf("未选择 Chrome 账号")
	}
	selected := make([]Account, 0, len(accounts))
	foundIDs := make(map[string]struct{})
	foundProfiles := make(map[string]struct{})
	foundEmails := make(map[string]struct{})
	for _, account := range accounts {
		profile := strings.ToLower(strings.TrimSpace(account.Profile))
		email := strings.ToLower(strings.TrimSpace(account.Email))
		_, profileMatch := requestedProfiles[profile]
		_, emailMatch := requestedEmails[email]
		_, idMatch := requestedIDs[strings.ToLower(account.ID)]
		if !profileMatch && !emailMatch && !idMatch {
			continue
		}
		if !account.Importable {
			return nil, fmt.Errorf("%s 缺少可导入的 OAuth 认证材料", account.Profile)
		}
		if !strings.Contains(email, "@") {
			return nil, fmt.Errorf("%s 缺少账号邮箱", account.Profile)
		}
		foundIDs[strings.ToLower(account.ID)] = struct{}{}
		foundProfiles[profile] = struct{}{}
		if _, exists := foundEmails[email]; exists {
			continue
		}
		selected = append(selected, account)
		foundEmails[email] = struct{}{}
	}
	if missing := missingValues(requestedIDs, foundIDs); len(missing) != 0 {
		return nil, fmt.Errorf("找不到选中的 Chrome 账号")
	}
	if missing := missingValues(requestedProfiles, foundProfiles); len(missing) != 0 {
		return nil, fmt.Errorf("找不到 Chrome Profile: %s", strings.Join(missing, ", "))
	}
	if missing := missingValues(requestedEmails, foundEmails); len(missing) != 0 {
		return nil, fmt.Errorf("找不到 Chrome 账号: %s", strings.Join(missing, ", "))
	}
	return selected, nil
}

func normalizedSet(values []string) map[string]struct{} {
	result := make(map[string]struct{}, len(values))
	for _, value := range values {
		value = strings.ToLower(strings.TrimSpace(value))
		if value != "" {
			result[value] = struct{}{}
		}
	}
	return result
}

func missingValues(requested map[string]struct{}, found map[string]struct{}) []string {
	missing := make([]string, 0)
	for value := range requested {
		if _, ok := found[value]; !ok {
			missing = append(missing, value)
		}
	}
	sort.Strings(missing)
	return missing
}

func decryptV20Token(masterKey []byte, encrypted []byte) (string, error) {
	if len(encrypted) < 3+12+16 || string(encrypted[:3]) != "v20" {
		return "", fmt.Errorf("refresh token 密文版本不是 v20")
	}
	block, err := aes.NewCipher(masterKey)
	if err != nil {
		return "", fmt.Errorf("创建 AES 解密器: %w", err)
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", fmt.Errorf("创建 GCM 解密器: %w", err)
	}
	plaintext, err := gcm.Open(nil, encrypted[3:15], encrypted[15:], nil)
	if err != nil {
		return "", fmt.Errorf("refresh token 解密失败")
	}
	return string(plaintext), nil
}

func toStorageCookies(cookies []multiloginCookie) []aistudio.StateCookie {
	now := time.Now()
	result := make([]aistudio.StateCookie, 0, len(cookies))
	for _, cookie := range cookies {
		domain := cookie.Domain
		if domain == "" && cookie.Host != "" && !strings.HasPrefix(cookie.Host, ".") {
			domain = cookie.Host
		}
		expires := float64(-1)
		if cookie.MaxAge != nil {
			lifetime := time.Duration(*cookie.MaxAge * float64(time.Second))
			if lifetime > maxCookieAge {
				lifetime = maxCookieAge
			}
			expires = float64(now.Add(lifetime).UnixNano()) / 1e9
		}
		path := cookie.Path
		if path == "" {
			path = "/"
		}
		sameSite := strings.ToLower(cookie.SameSite)
		if sameSite != "none" && sameSite != "lax" && sameSite != "strict" {
			sameSite = ""
		} else {
			sameSite = strings.ToUpper(sameSite[:1]) + sameSite[1:]
		}
		result = append(result, aistudio.StateCookie{
			Name: cookie.Name, Value: cookie.Value, Domain: domain, Path: path,
			Expires: expires, HTTPOnly: cookie.IsHTTPOnly, Secure: cookie.IsSecure, SameSite: sameSite,
		})
	}
	return result
}
