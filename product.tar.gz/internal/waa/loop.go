package waa

import (
	"runtime"
	"sync"
	"time"
)

// eventLoop 在一个锁定 OS 线程的 goroutine 中按到达顺序串行执行 VM 任务与计时器回调，afterTask 在每个任务结束后执行，cleanup 在循环结束时于同一线程执行
type eventLoop struct {
	mu        sync.Mutex
	queue     []func()
	wake      chan struct{}
	done      chan struct{}
	exited    chan struct{}
	closed    bool
	timers    map[*time.Timer]struct{}
	afterTask func()
	cleanup   func()
}

func newEventLoop() *eventLoop {
	loop := &eventLoop{wake: make(chan struct{}, 1), done: make(chan struct{}), exited: make(chan struct{}), timers: make(map[*time.Timer]struct{})}
	go loop.run()
	return loop
}

func (loop *eventLoop) run() {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	defer close(loop.exited)
	defer func() {
		if loop.cleanup != nil {
			loop.cleanup()
		}
	}()
	for {
		loop.mu.Lock()
		if loop.closed {
			loop.mu.Unlock()
			return
		}
		if len(loop.queue) == 0 {
			loop.mu.Unlock()
			select {
			case <-loop.wake:
			case <-loop.done:
				return
			}
			continue
		}
		job := loop.queue[0]
		loop.queue[0] = nil
		loop.queue = loop.queue[1:]
		loop.mu.Unlock()
		job()
		if loop.afterTask != nil {
			loop.afterTask()
		}
	}
}

// post 把任务追加到事件循环队列，循环已关闭时返回 false
func (loop *eventLoop) post(job func()) bool {
	loop.mu.Lock()
	if loop.closed {
		loop.mu.Unlock()
		return false
	}
	loop.queue = append(loop.queue, job)
	loop.mu.Unlock()
	select {
	case loop.wake <- struct{}{}:
	default:
	}
	return true
}

// schedule 在延迟后把任务追加到事件循环队列
func (loop *eventLoop) schedule(delay time.Duration, job func()) {
	if delay <= 0 {
		loop.post(job)
		return
	}
	loop.mu.Lock()
	defer loop.mu.Unlock()
	if loop.closed {
		return
	}
	var timer *time.Timer
	timer = time.AfterFunc(delay, func() {
		loop.mu.Lock()
		delete(loop.timers, timer)
		loop.mu.Unlock()
		loop.post(job)
	})
	loop.timers[timer] = struct{}{}
}

func (loop *eventLoop) close() {
	loop.mu.Lock()
	if loop.closed {
		loop.mu.Unlock()
		return
	}
	loop.closed = true
	for timer := range loop.timers {
		timer.Stop()
	}
	clear(loop.timers)
	loop.queue = nil
	loop.mu.Unlock()
	close(loop.done)
}
