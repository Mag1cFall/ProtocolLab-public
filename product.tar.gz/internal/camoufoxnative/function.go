package camoufoxnative

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"math/rand/v2"
	"time"
)

const (
	// functionResultInputSelector 是最后一轮函数调用块中的函数响应输入框
	functionResultInputSelector = "ms-chat-turn:last-of-type ms-function-call-chunk input"
	// functionResultSubmitSelector 是最后一轮函数调用块中提交函数响应的按钮
	functionResultSubmitSelector = "ms-chat-turn:last-of-type ms-function-call-chunk button.ms-button-primary"
)

// functionCallMarker 是 GenerateContent 响应流中函数调用 Part 的开头：十个空字段后为带函数名的 functionCall
var functionCallMarker = []byte(`[null,null,null,null,null,null,null,null,null,null,["`)

// GenerateFunctionResult 返回 GenerateContent 正文最后一个 user 轮次只有一个函数响应 Part 时，官网用户在函数调用块中输入的函数结果：响应 Struct 按字段顺序写成紧凑 JSON
func GenerateFunctionResult(body []byte) (string, bool) {
	contents, err := generateContents(body)
	if err != nil || len(contents) == 0 || contentRole(contents[len(contents)-1]) != "user" {
		return "", false
	}
	var turn []json.RawMessage
	var parts [][]json.RawMessage
	if json.Unmarshal(contents[len(contents)-1], &turn) != nil || len(turn) == 0 || json.Unmarshal(turn[0], &parts) != nil || len(parts) != 1 || len(parts[0]) < 12 {
		return "", false
	}
	var response []json.RawMessage
	if json.Unmarshal(parts[0][11], &response) != nil || len(response) < 2 {
		return "", false
	}
	var text bytes.Buffer
	if !writeStruct(&text, response[1]) {
		return "", false
	}
	return text.String(), true
}

// writeStruct 把 JSON+protobuf 编码的 google.protobuf.Struct（字段 1 为键值对数组）按字段顺序写成 JSON 对象
func writeStruct(out *bytes.Buffer, raw json.RawMessage) bool {
	var fields []json.RawMessage
	var entries [][]json.RawMessage
	if json.Unmarshal(raw, &fields) != nil {
		return false
	}
	if len(fields) > 0 && json.Unmarshal(fields[0], &entries) != nil {
		return false
	}
	out.WriteByte('{')
	for index, entry := range entries {
		if len(entry) < 2 {
			return false
		}
		if index > 0 {
			out.WriteByte(',')
		}
		out.Write(entry[0])
		out.WriteByte(':')
		if !writeValue(out, entry[1]) {
			return false
		}
	}
	out.WriteByte('}')
	return true
}

// writeValue 把 JSON+protobuf 编码的 google.protobuf.Value 写成 JSON：第 1 到 6 个元素依次为 null、数字、字符串、布尔、Struct 与 ListValue
func writeValue(out *bytes.Buffer, raw json.RawMessage) bool {
	var value []json.RawMessage
	if json.Unmarshal(raw, &value) != nil {
		return false
	}
	for index, field := range value {
		if bytes.Equal(field, []byte("null")) {
			continue
		}
		switch index {
		case 0:
			out.WriteString("null")
		case 1, 2, 3:
			out.Write(field)
		case 4:
			return writeStruct(out, field)
		case 5:
			var list []json.RawMessage
			var items []json.RawMessage
			if json.Unmarshal(field, &list) != nil || len(list) > 0 && json.Unmarshal(list[0], &items) != nil {
				return false
			}
			out.WriteByte('[')
			for position, item := range items {
				if position > 0 {
					out.WriteByte(',')
				}
				if !writeValue(out, item) {
					return false
				}
			}
			out.WriteByte(']')
		}
		return true
	}
	out.WriteString("null")
	return true
}

// ContinuesFunctionCall 判断 body 是否在某个标签页上一轮的对话后追加了模型的函数调用与 user 的函数结果，即官网用户能在该标签页最后一轮的函数调用块中提交函数结果
func (worker *Worker) ContinuesFunctionCall(body []byte) bool {
	if _, ok := GenerateFunctionResult(body); !ok {
		return false
	}
	contents, err := generateContents(body)
	if err != nil {
		return false
	}
	worker.mu.Lock()
	defer worker.mu.Unlock()
	for _, tab := range worker.chats {
		if tab.contents != nil && nextChatAction(tab.contents, contents) == chatContinue {
			return true
		}
	}
	return false
}

// submitResult 像官网用户一样在最后一轮的函数调用块中以可信指针点击函数响应输入框、以 Ctrl+V 粘贴 result，约 1.7 秒后安装一次性钩子并点击提交
func (worker *Worker) submitResult(ctx, input context.Context, tab *chatTab, action chatAction, turn GenerateTurn, requestID, result string) error {
	worker.mu.Lock()
	continued := tab.contents != nil && action == chatContinue
	worker.mu.Unlock()
	if !continued {
		return errors.New("标签页最后一轮不是本请求回应的函数调用")
	}
	if err := worker.click(input, tab.contextID, functionResultInputSelector, "", "官网函数响应输入框", pointerMoveDuration); err != nil {
		return err
	}
	if err := pasteText(input, worker.client, tab.contextID, result); err != nil {
		return fmt.Errorf("粘贴函数结果: %w", err)
	}
	if err := waitContext(ctx, 1600*time.Millisecond+rand.N(300*time.Millisecond)); err != nil {
		return err
	}
	if err := worker.arm(ctx, tab, turn, requestID); err != nil {
		return err
	}
	return worker.click(input, tab.contextID, functionResultSubmitSelector, "", "官网函数响应提交按钮", pointerMoveDuration)
}
