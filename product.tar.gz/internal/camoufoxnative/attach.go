package camoufoxnative

import (
	"context"
	crand "crypto/rand"
	"encoding/json"
	"fmt"
	"math/rand/v2"
	"mime"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"sync"
	"time"
)

// PageAttachment 是本轮最后一个 user 轮次中的附件：Name、MIME 与 Data 是交给页面文件输入框的文件，File 是 Drive 文件 ID，由页面上传时为空
type PageAttachment struct {
	Name string
	MIME string
	Data []byte
	File string
}

// PageRequestError 是页面上传附件时 GetAppFolder 或 Drive 上传返回的错误响应
type PageRequestError struct {
	Method string
	Status int
	Body   []byte
}

func (err *PageRequestError) Error() string {
	return fmt.Sprintf("页面 %s 返回 HTTP %d", err.Method, err.Status)
}

const (
	// addMediaSelector 是输入框旁插入图片、视频、音频与文件的按钮
	addMediaSelector = `button[data-test-id="add-media-button"]`
	// uploadMenuSelector 与 uploadMenuPattern 是插入菜单中图标为 upload 的 Upload files
	uploadMenuSelector = `.mat-mdc-menu-panel button.mat-mdc-menu-item`
	uploadMenuPattern  = `^upload\b`
	// uploadInputSelector 是插入按钮中的文件输入框
	uploadInputSelector = `input[data-test-upload-file-input]`
	// mediaDisclaimerSelector 是首次上传素材时确认对话框的 Acknowledge
	mediaDisclaimerSelector = `mat-dialog-container button.ms-button-primary`
	// driveUploadHost 与 driveUploadPath 是页面 gapi 上传 Drive 文件的地址
	driveUploadHost = "content.googleapis.com"
	driveUploadPath = "/upload/drive/v3/files"
)

// uploadCaptureFunction 是在页面上记录接下来 count 次 Drive 上传与其前 GetAppFolder 响应的函数声明：响应结束时经通道发出 {method, status, body}，第 count 次上传或 GetAppFolder 失败后恢复 XMLHttpRequest.prototype.open
const uploadCaptureFunction = `(count, emit) => {
  const open = XMLHttpRequest.prototype.open;
  let left = count;
  XMLHttpRequest.prototype.open = function(method, url) {
    const target = String(url).split("?")[0];
    const kind = target.endsWith("/GetAppFolder") ? "GetAppFolder" : target.endsWith("` + driveUploadPath + `") ? "DriveUpload" : "";
    if (kind === "DriveUpload" && --left === 0) {
      XMLHttpRequest.prototype.open = open;
    }
    if (kind) {
      this.addEventListener("loadend", () => {
        if (kind === "GetAppFolder" && this.status !== 200) {
          XMLHttpRequest.prototype.open = open;
        }
        emit(JSON.stringify({method: kind, status: this.status, body: this.responseText}));
      });
    }
    return open.apply(this, arguments);
  };
}`

// PageFile 是页面上传到 Drive 的附件
type PageFile struct {
	ID   string `json:"id"`
	Name string `json:"name"`
	MIME string `json:"mimeType"`
}

// UploadFiles 像官网用户一样在下一轮对话所用的标签页中经插入菜单的 Upload files 选择 files，由页面读取应用文件夹并上传到 Drive，返回页面上传的文件；history 是本轮之前各轮次的 GenerateContent 编码，标签页的对话不是 history 时先开新对话。成功后标签页留给附件为这些文件的下一次 Generate，失败时页面下一轮先开新对话
func (worker *Worker) UploadFiles(ctx context.Context, history []json.RawMessage, files []PageAttachment) ([]PageFile, error) {
	tab, err := worker.acquireChat(ctx)
	if err != nil {
		return nil, err
	}
	uploaded, err := worker.uploadFiles(ctx, tab, history, files)
	if err != nil {
		worker.mu.Lock()
		tab.contents = []json.RawMessage{}
		worker.mu.Unlock()
		worker.releaseChat(tab, false)
		return nil, err
	}
	return uploaded, nil
}

// uploadFiles 在已取得的标签页上按 history 决定是否先开新对话，再选择 files 并等页面上传完、输入框显示各附件的 token 数
func (worker *Worker) uploadFiles(ctx context.Context, tab *chatTab, history []json.RawMessage, files []PageAttachment) ([]PageFile, error) {
	client := worker.client
	requestID := crand.Text()
	channel, err := client.openChannel(requestID)
	if err != nil {
		return nil, err
	}
	defer client.closeChannel(requestID)
	unboost, err := worker.boostFrames(ctx)
	if err != nil {
		return nil, err
	}
	defer unboost()
	worker.lockInput()
	defer worker.inputMu.Unlock()
	input := context.WithoutCancel(ctx)
	if err := worker.selectChat(input, tab); err != nil {
		return nil, err
	}
	if err := client.waitFor(ctx, tab.contextID, `!`+generationRunningExpression, 15*time.Second); err != nil {
		return nil, fmt.Errorf("等待上一轮生成结束: %w", err)
	}
	if _, err := dismissKnownOverlays(input, client, tab.contextID); err != nil {
		return nil, err
	}
	worker.mu.Lock()
	action := nextChatAction(tab.contents, append(slices.Clone(history), json.RawMessage(`[[],"user"]`)))
	tab.runHovered = false
	worker.mu.Unlock()
	if action != chatContinue {
		if err := worker.newChat(input, tab); err != nil {
			return nil, err
		}
	}
	if _, err := client.callFunction(input, tab.contextID, uploadCaptureFunction, len(files), bidiChannelArgument(requestID)); err != nil {
		return nil, fmt.Errorf("记录页面附件上传: %w", err)
	}
	if err := worker.selectFiles(input, tab, files); err != nil {
		return nil, err
	}
	waiting, cancel := context.WithTimeout(ctx, time.Minute)
	defer cancel()
	uploaded := make([]PageFile, 0, len(files))
	for len(uploaded) < len(files) {
		value, err := channel.next(waiting)
		if err != nil {
			return nil, fmt.Errorf("等待页面上传附件: %w", err)
		}
		var response struct {
			Method string `json:"method"`
			Status int    `json:"status"`
			Body   string `json:"body"`
		}
		if err := json.Unmarshal([]byte(value), &response); err != nil {
			return nil, fmt.Errorf("解析页面附件上传: %w", err)
		}
		if response.Status != 200 {
			return nil, &PageRequestError{Method: response.Method, Status: response.Status, Body: []byte(response.Body)}
		}
		if response.Method == "DriveUpload" {
			var file PageFile
			if err := json.Unmarshal([]byte(response.Body), &file); err != nil || file.ID == "" {
				return nil, fmt.Errorf("解析页面 Drive 上传响应: %q", response.Body)
			}
			uploaded = append(uploaded, file)
		}
	}
	if err := client.waitFor(ctx, tab.contextID, fmt.Sprintf(attachmentsReadyExpression, len(files)), time.Minute); err != nil {
		return nil, fmt.Errorf("等待官网显示附件: %w", err)
	}
	ids := make([]string, len(uploaded))
	for index, file := range uploaded {
		ids[index] = file.ID
	}
	worker.mu.Lock()
	tab.staged = ids
	worker.mu.Unlock()
	return uploaded, nil
}

// stagedChat 返回 UploadFiles 为附件 attachments 留下的标签页，没有时为 nil
func (worker *Worker) stagedChat(attachments []PageAttachment) *chatTab {
	worker.mu.Lock()
	defer worker.mu.Unlock()
	for _, tab := range worker.chats {
		if tab.staged != nil && slices.EqualFunc(tab.staged, attachments, func(id string, attachment PageAttachment) bool { return id == attachment.File }) {
			return tab
		}
	}
	return nil
}

// ReleaseFiles 在请求结束时释放 UploadFiles 为文件 ids 留下、没有被 Generate 用到的标签页，页面下一轮先开新对话
func (worker *Worker) ReleaseFiles(ids []string) {
	worker.mu.Lock()
	var staged *chatTab
	for _, tab := range worker.chats {
		if tab.staged != nil && slices.Equal(tab.staged, ids) {
			staged = tab
			tab.staged = nil
			tab.contents = []json.RawMessage{}
		}
	}
	worker.mu.Unlock()
	if staged != nil {
		worker.releaseChat(staged, false)
	}
}

// attachmentsReadyExpression 判断输入框中有 %d 个附件且每个附件都已显示 token 数
const attachmentsReadyExpression = `(() => { const items = [...document.querySelectorAll('ms-prompt-box ms-prompt-media')]; return items.length === %d && items.every(item => /\d/.test(item.querySelector('ms-token-status')?.innerText ?? '')); })()`

// attachFiles 像官网用户一样经插入菜单的 Upload files 加入本轮复用的已上传附件，页面为附件发出的 Drive 上传在发出前被拦截，以附件的 Drive 文件回应
func (worker *Worker) attachFiles(ctx context.Context, tab *chatTab, attachments []PageAttachment) error {
	answer := &uploadAnswers{attachments: attachments}
	patterns := []map[string]any{{"type": "pattern", "protocol": "https", "hostname": driveUploadHost, "pathname": driveUploadPath}}
	stop, err := worker.client.intercept(ctx, tab.contextID, patterns, func(params map[string]any) { answer.respond(ctx, worker.client, params) })
	if err != nil {
		return fmt.Errorf("拦截界面附件上传: %w", err)
	}
	defer stop()
	if err := worker.selectFiles(ctx, tab, attachments); err != nil {
		return err
	}
	if err := worker.client.waitFor(ctx, tab.contextID, fmt.Sprintf(attachmentsReadyExpression, len(attachments)), time.Minute); err != nil {
		return fmt.Errorf("等待官网显示附件: %w", err)
	}
	return nil
}

// selectFiles 像官网用户一样点击输入框旁的插入按钮，约 3 秒后点 Upload files，把写入 profile 的同名文件交给文件输入框，出现首次上传素材确认框时点 Acknowledge
func (worker *Worker) selectFiles(ctx context.Context, tab *chatTab, attachments []PageAttachment) error {
	client := worker.client
	directory, err := os.MkdirTemp(worker.process.profile, "uploads")
	if err != nil {
		return fmt.Errorf("准备界面附件: %w", err)
	}
	defer os.RemoveAll(directory)
	paths := make([]string, len(attachments))
	for index, attachment := range attachments {
		name := filepath.Base(attachment.Name)
		if filepath.Ext(name) == "" {
			name += fileExtension(attachment.MIME)
		}
		paths[index] = filepath.Join(directory, fmt.Sprintf("%d", index), name)
		if err := os.MkdirAll(filepath.Dir(paths[index]), 0o700); err != nil {
			return fmt.Errorf("准备界面附件: %w", err)
		}
		if err := os.WriteFile(paths[index], attachment.Data, 0o600); err != nil {
			return fmt.Errorf("准备界面附件: %w", err)
		}
	}
	if err := worker.click(ctx, tab.contextID, addMediaSelector, "", "官网插入按钮", pointerMoveDuration); err != nil {
		return err
	}
	if err := waitContext(ctx, 2900*time.Millisecond+rand.N(200*time.Millisecond)); err != nil {
		return err
	}
	if err := worker.click(ctx, tab.contextID, uploadMenuSelector, uploadMenuPattern, "官网 Upload files", pointerMoveDuration); err != nil {
		return err
	}
	if err := waitContext(ctx, 1400*time.Millisecond+rand.N(300*time.Millisecond)); err != nil {
		return err
	}
	input, err := client.callFunction(ctx, tab.contextID, `() => document.querySelector('`+uploadInputSelector+`')`)
	if err != nil {
		return fmt.Errorf("查找官网文件输入框: %w", err)
	}
	element, _ := input["sharedId"].(string)
	if element == "" {
		return fmt.Errorf("官网文件输入框不存在")
	}
	if _, err := client.command(ctx, "input.setFiles", map[string]any{"context": tab.contextID, "element": map[string]any{"sharedId": element}, "files": paths}); err != nil {
		return fmt.Errorf("选择界面附件: %w", err)
	}
	if err := client.waitFor(ctx, tab.contextID, `Boolean(document.querySelector('`+mediaDisclaimerSelector+`'))`, 2*time.Second); err == nil {
		if err := waitContext(ctx, 900*time.Millisecond+rand.N(400*time.Millisecond)); err != nil {
			return err
		}
		if err := worker.click(ctx, tab.contextID, mediaDisclaimerSelector, "", "官网素材确认框 Acknowledge", pointerMoveDuration); err != nil {
			return err
		}
	}
	return nil
}

// commonExtensions 是子类型与常用扩展名不同的 MIME 子类型的常用扩展名
var commonExtensions = map[string]string{"plain": ".txt", "mpeg": ".mp3"}

// fileExtension 返回 MIME 类型的常用扩展名：与子类型同名的扩展名优先，其次为 commonExtensions，再次为系统 MIME 表中的第一个
func fileExtension(mimeType string) string {
	extensions, _ := mime.ExtensionsByType(mimeType)
	_, subtype, _ := strings.Cut(strings.ToLower(mimeType), "/")
	if slices.Contains(extensions, "."+subtype) {
		return "." + subtype
	}
	if extension, ok := commonExtensions[subtype]; ok {
		return extension
	}
	if len(extensions) > 0 {
		return extensions[0]
	}
	return ""
}

// uploadAnswers 依次以附件的 Drive 文件回应页面拦截下来的 Drive 上传
type uploadAnswers struct {
	mu          sync.Mutex
	attachments []PageAttachment
	uploaded    int
}

// respond 回应一条被拦截的请求，允许来源为请求的 Origin：CORS 预检回应官网的允许头，Drive 上传约 0.7 秒后回应下一个附件的 Drive 文件
func (answers *uploadAnswers) respond(ctx context.Context, client *bidiClient, params map[string]any) {
	request, _ := params["request"].(map[string]any)
	id, _ := request["request"].(string)
	method, _ := request["method"].(string)
	origin, requested := aiStudioOrigin, ""
	list, _ := request["headers"].([]any)
	for _, header := range list {
		fields, _ := header.(map[string]any)
		name, _ := fields["name"].(string)
		value, _ := fields["value"].(map[string]any)
		switch strings.ToLower(name) {
		case "origin":
			origin, _ = value["value"].(string)
		case "access-control-request-headers":
			requested, _ = value["value"].(string)
		}
	}
	headers := map[string]string{"access-control-allow-origin": origin, "access-control-allow-credentials": "true"}
	var status int
	var body string
	switch {
	case method == "OPTIONS":
		status = 200
		headers["access-control-allow-methods"] = "DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT"
		headers["access-control-allow-headers"] = requested
		headers["access-control-max-age"] = "3600"
		headers["content-type"] = "text/html"
	default:
		answers.mu.Lock()
		attachment := answers.attachments[min(answers.uploaded, len(answers.attachments)-1)]
		answers.uploaded++
		answers.mu.Unlock()
		_ = waitContext(ctx, 600*time.Millisecond+rand.N(200*time.Millisecond))
		file, _ := json.MarshalIndent(struct {
			Kind     string `json:"kind"`
			ID       string `json:"id"`
			Name     string `json:"name"`
			MIMEType string `json:"mimeType"`
		}{"drive#file", attachment.File, attachment.Name, attachment.MIME}, "", "  ")
		status, body = 200, string(file)+"\n"
		headers["content-type"] = "application/json; charset=UTF-8"
		headers["access-control-expose-headers"] = "Content-Length, Date, Server, Transfer-Encoding, X-GUploader-UploadID, X-Google-Trace, date, server, vary"
	}
	fields := make([]map[string]any, 0, len(headers))
	for name, value := range headers {
		fields = append(fields, map[string]any{"name": name, "value": map[string]any{"type": "string", "value": value}})
	}
	_, _ = client.command(context.WithoutCancel(ctx), "network.provideResponse", map[string]any{
		"request": id, "statusCode": status, "reasonPhrase": "OK", "headers": fields, "body": map[string]any{"type": "string", "value": body},
	})
}
