package aistudio

import (
	"bytes"
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"

	"golang.org/x/sync/singleflight"
)

const publicDiscoveryUserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:158.0) Gecko/20100101 Firefox/158.0"

var makerSuiteAPIKeyPattern = regexp.MustCompile(`"WIu0Nc":"([^"]+)"`)

// ProtocolHeaderProvider 按账户提供官方运行时发现的动态公共头
type ProtocolHeaderProvider interface {
	ProtocolHeaders(context.Context, string) (http.Header, error)
}

// ProtocolHeaderProviderFunc 将函数适配为 ProtocolHeaderProvider
type ProtocolHeaderProviderFunc func(context.Context, string) (http.Header, error)

// ProtocolHeaders 调用动态公共头函数
func (f ProtocolHeaderProviderFunc) ProtocolHeaders(ctx context.Context, accountID string) (http.Header, error) {
	return f(ctx, accountID)
}

// HTTPTransportOptions 定义普通 MakerSuite RPC 的账户与网络依赖
type HTTPTransportOptions struct {
	Pool        *AccountPool
	Signer      *Signer
	Headers     ProtocolHeaderProvider
	GlobalProxy string
}

// MakerSuiteHTTPTransport 使用账户固定出口发送普通 RPC
type MakerSuiteHTTPTransport struct {
	pool        *AccountPool
	signer      *Signer
	headers     ProtocolHeaderProvider
	globalProxy string
	now         func() time.Time
	clientsMu   sync.Mutex
	clients     map[string]*http.Client
	// driveMu 保护 driveDiscovered
	driveMu sync.Mutex
	// driveDiscovered 记录已按官网页面读取 Drive discovery 文档的账户
	driveDiscovered map[string]bool
	// driveDiscovery 按账户合并同时进行的 Drive discovery 读取
	driveDiscovery singleflight.Group
}

type accountLeaseContextKey struct{}
type accountSelectionObserverContextKey struct{}

// ContextWithAccountLease 将上层已持有的租约传给协议传输
func ContextWithAccountLease(ctx context.Context, lease *AccountLease) context.Context {
	return context.WithValue(ctx, accountLeaseContextKey{}, lease)
}

// AccountLeaseFromContext 返回当前请求唯一的账户租约
func AccountLeaseFromContext(ctx context.Context) (*AccountLease, bool) {
	lease, ok := ctx.Value(accountLeaseContextKey{}).(*AccountLease)
	return lease, ok && lease != nil && lease.Account() != nil
}

// ContextWithAccountSelectionObserver 观察请求最终选择的账户
func ContextWithAccountSelectionObserver(ctx context.Context, observer func(*Account)) context.Context {
	return context.WithValue(ctx, accountSelectionObserverContextKey{}, observer)
}

func observeAccountSelection(ctx context.Context, account *Account) {
	if observer, ok := ctx.Value(accountSelectionObserverContextKey{}).(func(*Account)); ok {
		observer(account)
	}
}

// NewMakerSuiteHTTPTransport 创建普通 MakerSuite RPC 传输
func NewMakerSuiteHTTPTransport(options HTTPTransportOptions) (*MakerSuiteHTTPTransport, error) {
	signer := options.Signer
	if signer == nil {
		signer = NewSigner()
	}
	transport := &MakerSuiteHTTPTransport{
		pool:            options.Pool,
		signer:          signer,
		headers:         options.Headers,
		globalProxy:     strings.TrimSpace(options.GlobalProxy),
		now:             time.Now,
		clients:         make(map[string]*http.Client),
		driveDiscovered: make(map[string]bool),
	}
	if _, err := transport.clientForProxy(transport.globalProxy); err != nil {
		return nil, err
	}
	return transport, nil
}

// sendHTTP 发送 HTTP 请求，请求失败时错误中的地址不含查询参数
func sendHTTP(client *http.Client, request *http.Request) (*http.Response, error) {
	response, err := client.Do(request)
	var requestErr *url.Error
	if errors.As(err, &requestErr) {
		requestErr.URL, _, _ = strings.Cut(requestErr.URL, "?")
	}
	return response, err
}

// DiscoverPublicHeaders 从 AI Studio 首页读取普通 RPC 所需的公开头
func DiscoverPublicHeaders(ctx context.Context, client *http.Client) (http.Header, error) {
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, aiStudioOrigin+"/", nil)
	if err != nil {
		return nil, err
	}
	request.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
	request.Header.Set("User-Agent", publicDiscoveryUserAgent)
	response, err := sendHTTP(client, request)
	if err != nil {
		return nil, fmt.Errorf("读取 AI Studio 首页: %w", err)
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("AI Studio 首页返回 HTTP %d", response.StatusCode)
	}
	body, err := io.ReadAll(response.Body)
	if err != nil {
		return nil, fmt.Errorf("读取 AI Studio 首页正文: %w", err)
	}
	match := makerSuiteAPIKeyPattern.FindSubmatch(body)
	if match == nil {
		return nil, fmt.Errorf("AI Studio 首页缺少 WIu0Nc")
	}
	visitID, err := newVisitID()
	if err != nil {
		return nil, err
	}
	return http.Header{
		"User-Agent":          []string{publicDiscoveryUserAgent},
		"X-Aistudio-Visit-Id": []string{visitID},
		"X-Goog-Api-Key":      []string{string(match[1])},
		"X-Goog-Authuser":     []string{"0"},
		"X-User-Agent":        []string{"grpc-web-javascript/0.1"},
	}, nil
}

func newVisitID() (string, error) {
	value := make([]byte, 16)
	if _, err := rand.Read(value); err != nil {
		return "", fmt.Errorf("生成 AI Studio visit ID: %w", err)
	}
	value[6] = value[6]&0x0f | 0x40
	value[8] = value[8]&0x3f | 0x80
	uuid := fmt.Sprintf("%08x-%04x-%04x-%04x-%012x",
		value[0:4], value[4:6], value[6:8], value[8:10], value[10:16],
	)
	return "v1_" + base64.StdEncoding.EncodeToString([]byte(uuid)), nil
}

// NewProxyHTTPClient 创建普通 HTTP、HTTPS 或 SOCKS5 固定出口客户端
func NewProxyHTTPClient(proxyURL string) (*http.Client, error) {
	roundTripper, err := newBrowserRoundTripper(proxyURL)
	if err != nil {
		return nil, err
	}
	return &http.Client{Transport: roundTripper}, nil
}

// UploadAssistantFile 以账户身份按官网对话面板的 /_/upload 可续传协议上传附件，返回上传路径
func (t *MakerSuiteHTTPTransport) UploadAssistantFile(ctx context.Context, accountID string, blob Blob) (string, error) {
	lease, owned, err := resolveAccountLease(ctx, t.pool, AccountSelection{AccountID: accountID})
	if err != nil {
		return "", err
	}
	if owned {
		defer lease.Release()
	}
	account := lease.Account()
	public, err := t.headers.ProtocolHeaders(ctx, account.ID)
	if err != nil {
		return "", fmt.Errorf("读取账户动态公共头: %w", err)
	}
	client, err := t.clientForProxy(account.EffectiveProxy(t.globalProxy))
	if err != nil {
		return "", err
	}
	digest := sha256.Sum256(blob.Data)
	hash := "sha256=" + base64.StdEncoding.EncodeToString(digest[:])
	send := func(address string, header http.Header, body []byte) (http.Header, []byte, error) {
		state, err := lease.ReloadStorageState()
		if err != nil {
			return nil, nil, fmt.Errorf("读取账户 storage state: %w", err)
		}
		cookie, err := state.CookieHeader(address, t.now())
		if err != nil {
			return nil, nil, err
		}
		header.Set("User-Agent", public.Get("User-Agent"))
		header.Set("Accept", "*/*")
		header.Set("Origin", aiStudioOrigin)
		header.Set("Referer", aiStudioOrigin+"/")
		header.Set("Sec-Fetch-Dest", "empty")
		header.Set("Sec-Fetch-Mode", "cors")
		header.Set("Sec-Fetch-Site", "same-origin")
		if account.Config.AuthUser > 0 {
			header.Set("X-Goog-Authuser", strconv.Itoa(account.Config.AuthUser))
		}
		if language := account.AcceptLanguage(); language != "" {
			header.Set("Accept-Language", language)
		}
		header.Set("Cookie", cookie)
		request, err := http.NewRequestWithContext(ctx, http.MethodPost, address, bytes.NewReader(body))
		if err != nil {
			return nil, nil, fmt.Errorf("创建写代码助手附件上传请求: %w", err)
		}
		request.Header = header
		response, err := sendHTTP(client, request)
		if err != nil {
			return nil, nil, fmt.Errorf("执行写代码助手附件上传: %w", err)
		}
		defer response.Body.Close()
		if setCookies := response.Header.Values("Set-Cookie"); len(setCookies) > 0 {
			if err := lease.MergeSetCookieHeaders(setCookies, address, t.now()); err != nil {
				return nil, nil, fmt.Errorf("合并写代码助手附件上传响应 Cookie: %w", err)
			}
		}
		raw, err := io.ReadAll(response.Body)
		if err != nil {
			return nil, nil, fmt.Errorf("读取写代码助手附件上传响应: %w", err)
		}
		if response.StatusCode != http.StatusOK {
			return nil, nil, DecodeRPCError(assistantUploadMethod, response.StatusCode, raw)
		}
		return response.Header, raw, nil
	}
	header, _, err := send(aiStudioOrigin+"/_/upload", http.Header{
		"X-Goog-Upload-Header-Content-Length": {strconv.Itoa(len(blob.Data))},
		"X-Goog-Upload-Header-Content-Type":   {blob.MIME},
		"X-Goog-Hash":                         {hash},
		"X-Goog-Upload-Protocol":              {"resumable"},
		"X-Goog-Upload-Command":               {"start"},
	}, nil)
	if err != nil {
		return "", err
	}
	address := header.Get("X-Goog-Upload-URL")
	if address == "" {
		return "", fmt.Errorf("写代码助手附件上传响应缺少 X-Goog-Upload-URL")
	}
	_, raw, err := send(address, http.Header{
		"Content-Type":          {blob.MIME},
		"X-Goog-Hash":           {hash},
		"X-Goog-Upload-Command": {"upload, finalize"},
		"X-Goog-Upload-Offset":  {"0"},
	}, blob.Data)
	if err != nil {
		return "", err
	}
	path := strings.TrimSpace(string(raw))
	if path == "" {
		return "", fmt.Errorf("写代码助手附件上传响应缺少上传路径")
	}
	return path, nil
}

// Do 发送普通 MakerSuite RPC 并让响应 body 持有租约
func (t *MakerSuiteHTTPTransport) Do(ctx context.Context, rpc RPCRequest) (*RPCResponse, error) {
	lease, owned, err := resolveAccountLease(ctx, t.pool, AccountSelection{AccountID: rpc.AccountID})
	if err != nil {
		return nil, err
	}
	releaseOnError := func(requestErr error) error {
		if !owned {
			return requestErr
		}
		return errors.Join(requestErr, lease.Release())
	}
	account := lease.Account()
	_, headers, err := prepareProtocolHeaders(ctx, lease, rpc, t.signer, t.headers, t.now(), true)
	if err != nil {
		return nil, releaseOnError(err)
	}
	request, err := http.NewRequestWithContext(ctx, http.MethodPost, rpc.URL, bytes.NewReader(rpc.Body))
	if err != nil {
		return nil, releaseOnError(fmt.Errorf("创建 MakerSuite %s 请求: %w", rpc.Method, err))
	}
	request.Header = headers
	client, err := t.clientForProxy(account.EffectiveProxy(t.globalProxy))
	if err != nil {
		return nil, releaseOnError(err)
	}
	response, err := sendHTTP(client, request)
	if err != nil {
		return nil, releaseOnError(fmt.Errorf("执行 MakerSuite %s 请求: %w", rpc.Method, err))
	}
	if setCookies := response.Header.Values("Set-Cookie"); len(setCookies) > 0 {
		if err := lease.MergeSetCookieHeaders(setCookies, rpc.URL, t.now()); err != nil {
			_ = response.Body.Close()
			return nil, releaseOnError(fmt.Errorf("合并 MakerSuite %s 响应 Cookie: %w", rpc.Method, err))
		}
	}
	body := &leaseResponseBody{
		body: response.Body,
		finish: func() error {
			if owned {
				return lease.Release()
			}
			return nil
		},
	}
	return &RPCResponse{StatusCode: response.StatusCode, Header: response.Header.Clone(), Body: body}, nil
}

// FetchStatic 经账户的固定出口以 GET 读取官网静态资源
func (t *MakerSuiteHTTPTransport) FetchStatic(ctx context.Context, accountID string, address string) ([]byte, error) {
	account, err := t.pool.Account(accountID)
	if err != nil {
		return nil, err
	}
	client, err := t.clientForProxy(account.EffectiveProxy(t.globalProxy))
	if err != nil {
		return nil, err
	}
	request, err := http.NewRequestWithContext(ctx, http.MethodGet, address, nil)
	if err != nil {
		return nil, err
	}
	request.Header.Set("User-Agent", publicDiscoveryUserAgent)
	response, err := sendHTTP(client, request)
	if err != nil {
		return nil, err
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("HTTP %d", response.StatusCode)
	}
	return io.ReadAll(response.Body)
}

// CloseIdleConnections 关闭全部固定出口的空闲连接
func (t *MakerSuiteHTTPTransport) CloseIdleConnections() {
	t.clientsMu.Lock()
	defer t.clientsMu.Unlock()
	for _, client := range t.clients {
		client.CloseIdleConnections()
	}
}

func (t *MakerSuiteHTTPTransport) clientForProxy(proxyURL string) (*http.Client, error) {
	t.clientsMu.Lock()
	defer t.clientsMu.Unlock()
	if client := t.clients[proxyURL]; client != nil {
		return client, nil
	}
	client, err := NewProxyHTTPClient(proxyURL)
	if err != nil {
		return nil, err
	}
	t.clients[proxyURL] = client
	return client, nil
}

func prepareProtocolHeaders(
	ctx context.Context,
	lease *AccountLease,
	rpc RPCRequest,
	signer *Signer,
	provider ProtocolHeaderProvider,
	now time.Time,
	includeCookie bool,
) (StorageState, http.Header, error) {
	state, err := lease.ReloadStorageState()
	if err != nil {
		return StorageState{}, nil, fmt.Errorf("读取账户 storage state: %w", err)
	}
	account := lease.Account()
	publicHeaders, err := provider.ProtocolHeaders(ctx, account.ID)
	if err != nil {
		return StorageState{}, nil, fmt.Errorf("读取账户动态公共头: %w", err)
	}
	if publicHeaders == nil {
		return StorageState{}, nil, fmt.Errorf("账户动态公共头为空")
	}
	headers := publicHeaders.Clone()
	for name, values := range rpc.Header {
		headers.Del(name)
		for _, value := range values {
			headers.Add(name, value)
		}
	}
	if account.Config.AuthUser > 0 {
		headers.Set("X-Goog-Authuser", strconv.Itoa(account.Config.AuthUser))
	}
	for _, name := range []string{"User-Agent", "X-Goog-Api-Key", "X-Goog-Authuser", "X-User-Agent"} {
		if strings.TrimSpace(headers.Get(name)) == "" {
			return StorageState{}, nil, fmt.Errorf("账户动态公共头缺少 %s", name)
		}
	}
	authorization, err := signer.Authorization(state)
	if err != nil {
		return StorageState{}, nil, err
	}
	headers.Set("Authorization", authorization)
	headers.Set("Accept", "*/*")
	headers.Set("Accept-Encoding", "gzip, deflate, br, zstd")
	headers.Set("Origin", aiStudioOrigin)
	headers.Set("Referer", aiStudioOrigin+"/")
	headers.Set("Sec-Fetch-Dest", "empty")
	headers.Set("Sec-Fetch-Mode", "cors")
	headers.Set("Sec-Fetch-Site", "same-site")
	if language := account.AcceptLanguage(); language != "" {
		headers.Set("Accept-Language", language)
	}
	if includeCookie {
		cookie, err := state.CookieHeader(rpc.URL, now)
		if err != nil {
			return StorageState{}, nil, err
		}
		headers.Set("Cookie", cookie)
	}
	return state, headers, nil
}

func resolveAccountLease(ctx context.Context, pool *AccountPool, selection AccountSelection) (*AccountLease, bool, error) {
	if lease, ok := AccountLeaseFromContext(ctx); ok {
		if err := validateLeaseSelection(lease, selection); err != nil {
			return nil, false, err
		}
		observeAccountSelection(ctx, lease.Account())
		return lease, false, nil
	}
	lease, err := pool.AcquireFor(ctx, selection)
	if err != nil {
		return nil, false, err
	}
	observeAccountSelection(ctx, lease.Account())
	return lease, true, nil
}

func validateLeaseSelection(lease *AccountLease, selection AccountSelection) error {
	lease.pool.mu.Lock()
	defer lease.pool.mu.Unlock()
	account := lease.Account()
	if lease.pool.byID[account.ID] != account {
		return fmt.Errorf("context 租约账户不存在: %s", account.ID)
	}
	if accountID := strings.TrimSpace(selection.AccountID); accountID != "" && account.ID != accountID {
		return fmt.Errorf("context 租约账户 %s 与请求账户 %s 不一致", account.ID, accountID)
	}
	if selection.AllowedAccountIDs != nil {
		allowed := false
		for _, accountID := range selection.AllowedAccountIDs {
			if strings.TrimSpace(accountID) == account.ID {
				allowed = true
				break
			}
		}
		if !allowed {
			return ErrNoEligibleAccount
		}
	}
	if resourceID := strings.TrimSpace(selection.ResourceID); resourceID != "" {
		owner, exists := lease.pool.resources[resourceID]
		if !exists {
			return ErrResourceNotFound
		}
		if owner != account.ID {
			return fmt.Errorf("%w：资源 %s 属于账户 %s，与指定的账户 %s 不同", ErrNoEligibleAccount, resourceID, owner, account.ID)
		}
	}
	if selection.Channel != "" && generationChannelSelection(selection) && lease.Channel() != selection.Channel {
		return fmt.Errorf("context 租约账户 %s 的 %s 通道不满足请求要求的 %s 通道", account.ID, lease.Channel(), selection.Channel)
	}
	modelID := strings.TrimPrefix(strings.TrimSpace(selection.ModelID), "models/")
	if lease.Channel() == ChannelBuild {
		if modelID != "" && !lease.pool.channelSupportsLocked(account, ChannelBuild, selection) {
			return fmt.Errorf("context 租约账户 %s 的 Build 通道不支持模型 %s", account.ID, modelID)
		}
		return nil
	}
	if modelID != "" && !account.SupportsModel(modelID) {
		return fmt.Errorf("context 租约账户 %s 不支持模型 %s", account.ID, modelID)
	}
	if selection.Method != "" && !account.SupportsMethod(modelID, selection.Method) {
		return fmt.Errorf("context 租约账户 %s 不支持方法 %s", account.ID, selection.Method)
	}
	capability := strings.TrimSpace(selection.Capability)
	if capability != "" {
		for _, model := range account.Models {
			if modelMatchesID(model, modelID) && model.Capabilities[capability] {
				return nil
			}
		}
		return fmt.Errorf("context 租约账户 %s 不支持能力 %s", account.ID, capability)
	}
	return nil
}

type leaseResponseBody struct {
	body      io.ReadCloser
	finish    func() error
	once      sync.Once
	finishErr error
}

func (b *leaseResponseBody) Read(destination []byte) (int, error) {
	count, err := b.body.Read(destination)
	if err == io.EOF {
		b.finalize()
		if b.finishErr != nil {
			return count, errors.Join(err, b.finishErr)
		}
	}
	return count, err
}

func (b *leaseResponseBody) Close() error {
	closeErr := b.body.Close()
	b.finalize()
	return errors.Join(closeErr, b.finishErr)
}

func (b *leaseResponseBody) finalize() {
	b.once.Do(func() {
		b.finishErr = b.finish()
	})
}
