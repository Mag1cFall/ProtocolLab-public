package aistudio

import (
	"context"
	"encoding/json"
	"sync"

	"github.com/Mag1cFall/AIStudio2API/internal/camoufoxnative"
)

// pageAttachment 是进行中请求以内联数据上传或复用的 Drive 文件，count 为登记它的请求数
type pageAttachment struct {
	file  camoufoxnative.PageAttachment
	count int
}

// pageAttachments 是进行中请求的内联附件，键为 Drive 文件 ID，Camoufox 后端界面运行时把原始字节交给页面文件输入框
var pageAttachments = struct {
	sync.Mutex
	files map[string]*pageAttachment
}{files: map[string]*pageAttachment{}}

// registerPageAttachments 登记请求的内联附件，返回撤销登记的函数
func registerPageAttachments(files []camoufoxnative.PageAttachment) func() {
	pageAttachments.Lock()
	defer pageAttachments.Unlock()
	for _, file := range files {
		entry := pageAttachments.files[file.File]
		if entry == nil {
			entry = &pageAttachment{file: file}
			pageAttachments.files[file.File] = entry
		}
		entry.count++
	}
	return func() {
		pageAttachments.Lock()
		defer pageAttachments.Unlock()
		for _, file := range files {
			if entry := pageAttachments.files[file.File]; entry != nil {
				if entry.count--; entry.count == 0 {
					delete(pageAttachments.files, file.File)
				}
			}
		}
	}
}

// pageAttachmentsOf 返回 GenerateContent 正文最后一个 user 轮次中已登记的内联附件，顺序与正文相同
func pageAttachmentsOf(body []byte) []camoufoxnative.PageAttachment {
	pageAttachments.Lock()
	defer pageAttachments.Unlock()
	var files []camoufoxnative.PageAttachment
	for _, id := range camoufoxnative.GenerateFiles(body) {
		if entry := pageAttachments.files[id]; entry != nil {
			files = append(files, entry.file)
		}
	}
	return files
}

// pageUploader 是像官网用户一样在服务上传附件前经插入菜单选择文件的账户页面
type pageUploader interface {
	// beforeUpload 点击插入按钮与 Upload files 选择文件，账户尚未确认首次上传素材提示时与官网点 Acknowledge 一样发送 UpdateUserPreferences，返回页面载入时取得、仍在有效期内的 access token，没有时为空
	beforeUpload(ctx context.Context) string
	// uploaded 在服务上传完附件后像官网输入框显示附件一样经 drive.count 统计各附件的 token，并在页面发出带这些附件的 GenerateContent 后经 drive.read 像对话中的附件一样读取文件
	uploaded(ctx context.Context, files []FileRef, drive pageDrive)
}

// pageDrive 是页面附件伴随的请求：count 发送 CountTokens 正文并返回响应正文，read 读取 Drive 文件的元数据与缩略图
type pageDrive struct {
	count func(ctx context.Context, body []byte) ([]byte, error)
	read  func(ctx context.Context, fileID string)
}

// pageFileUploader 是像官网用户一样经插入菜单选择附件、由页面自己上传的账户页面
type pageFileUploader interface {
	// uploadFiles 在下一轮对话所用的标签页中选择并上传 files，history 是本轮之前各轮次的 GenerateContent 编码
	uploadFiles(ctx context.Context, history []json.RawMessage, files []camoufoxnative.PageAttachment) ([]FileRef, error)
	// releaseFiles 在请求结束时释放 uploadFiles 为这些文件留下、没有用到的标签页
	releaseFiles(ids []string)
}

// pageWorkers 是各账户的 WAA Worker，键为账户 ID
var pageWorkers sync.Map

// pageOf 返回账户 WAA Worker 当前的页面，没有 Worker 时为 nil
func pageOf(accountID string) workerRuntime {
	worker, ok := pageWorkers.Load(accountID)
	if !ok {
		return nil
	}
	return worker.(*NativeWorker).current()
}
