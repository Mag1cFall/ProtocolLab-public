package aistudio

import (
	"fmt"
	"net/http"
	"strings"
)

// BenefitTier 表示 AI Studio 返回的账户权益等级
type BenefitTier int64

const (
	// BenefitTierFree 表示账户没有 Google AI 订阅权益
	BenefitTierFree BenefitTier = 0
	// BenefitTierPro 表示 Google AI Pro 权益
	BenefitTierPro BenefitTier = 1
	// BenefitTierUltra 表示 Google AI Ultra 权益
	BenefitTierUltra BenefitTier = 2
	// BenefitTierPlus 表示 Google AI Plus 权益
	BenefitTierPlus BenefitTier = 3
)

var tieredRPCMethods = map[string]struct{}{
	"GenerateContent":          {},
	"CountTokens":              {},
	"ProxyUnaryCall":           {},
	"CodeAssistantOffline":     {},
	"CancelInteraction":        {},
	"CreateInteraction":        {},
	"CreateDecision":           {},
	"CreateInteractionStream":  {},
	"GetInteractionStream":     {},
	"StreamExtractVideoFrames": {},
}

// String 返回账户权益的稳定显示名称
func (tier BenefitTier) String() string {
	switch tier {
	case BenefitTierPro:
		return "Pro"
	case BenefitTierUltra:
		return "Ultra"
	case BenefitTierPlus:
		return "Plus"
	default:
		return "Free"
	}
}

// HeaderValue 返回官网 RPC 使用的权益请求头值
func (tier BenefitTier) HeaderValue() string {
	switch tier {
	case BenefitTierPro:
		return "TIER1"
	case BenefitTierUltra:
		return "TIER2"
	case BenefitTierPlus:
		return "TIER0"
	default:
		return ""
	}
}

// setBenefitTier 记录账户的权益等级
func (c *Client) setBenefitTier(accountID string, tier BenefitTier) {
	c.tierMu.Lock()
	c.tiers[accountID] = tier
	c.tierMu.Unlock()
}

func decodeBenefitTier(raw []byte) (BenefitTier, error) {
	value, err := decodeJSONValue(raw)
	if err != nil {
		return BenefitTierFree, withMethod(err, "GetAiStudioBenefitTier")
	}
	root, err := rawArray(value, "$", value)
	if err != nil {
		return BenefitTierFree, withMethod(err, "GetAiStudioBenefitTier")
	}
	if len(root) == 0 || isJSONNull(root[0]) {
		return BenefitTierFree, nil
	}
	wire, err := rawInt64(root[0], "$[0]", raw)
	if err != nil {
		return BenefitTierFree, withMethod(err, "GetAiStudioBenefitTier")
	}
	tier := BenefitTier(wire)
	if tier < BenefitTierFree || tier > BenefitTierPlus {
		return BenefitTierFree, &ProtocolEvidenceError{
			Method: "GetAiStudioBenefitTier",
			Path:   "$[0]",
			Detail: fmt.Sprintf("未识别的账户权益枚举 %d", wire),
			Raw:    append([]byte(nil), raw...),
		}
	}
	return tier, nil
}

func (c *Client) applyBenefitTier(method string, accountID string, header http.Header) {
	if _, ok := tieredRPCMethods[method]; !ok {
		return
	}
	c.tierMu.RLock()
	tier := c.tiers[strings.TrimSpace(accountID)]
	c.tierMu.RUnlock()
	if value := tier.HeaderValue(); value != "" {
		header.Set("X-AIStudio-G1-Tier", value)
	}
}

// ModelAccessError 表示模型只对启用账户都不具备的权益开放
type ModelAccessError struct {
	Model       string
	AccessModes []int64
}

func (e *ModelAccessError) Error() string {
	names := make([]string, 0, len(e.AccessModes))
	for _, mode := range e.AccessModes {
		switch mode {
		case 1:
			names = append(names, "付费 API key")
		case 3:
			names = append(names, "Google AI Pro 或 Ultra 订阅")
		case 4:
			names = append(names, "Google AI Ultra 订阅")
		default:
			names = append(names, fmt.Sprintf("访问方式 %d", mode))
		}
	}
	return fmt.Sprintf("模型 %s 需要 %s，启用的账户都不具备", e.Model, strings.Join(names, " 或 "))
}

// HTTPStatus 返回权益不足对应的状态码
func (e *ModelAccessError) HTTPStatus() int {
	return http.StatusForbidden
}

// ErrorCode 返回 OpenAI 兼容的错误代码
func (e *ModelAccessError) ErrorCode() string {
	return "account_required"
}

func modelAllowedByTier(model Model, tier BenefitTier) bool {
	if len(model.AccessModes) == 0 {
		return true
	}
	for _, mode := range model.AccessModes {
		switch mode {
		case 3:
			if tier == BenefitTierPro || tier == BenefitTierUltra {
				return true
			}
		case 4:
			if tier == BenefitTierUltra {
				return true
			}
		}
	}
	return false
}
