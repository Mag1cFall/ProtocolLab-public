package aistudio

import (
	"bytes"
	"encoding/json"
	"io"
	"math/rand/v2"
	"slices"
	"time"

	"github.com/Mag1cFall/AIStudio2API/internal/camoufoxnative"
)

// 官网运行设置与模型面板中界面元素的 VE 编号
const (
	// vePanelCategory 是模型面板的分类按钮，也是新对话页分类网格的卡片
	vePanelCategory = 274388
	// vePanelModel 是模型面板中一行模型的选择按钮
	vePanelModel = 274387
	// vePanelStar 是模型行的收藏按钮
	vePanelStar = 358946
	// vePanelCopy 是模型行的复制模型 ID 按钮
	vePanelCopy = 274385
	// vePanelDocs 是模型行的开发者文档链接
	vePanelDocs = 274386
	// vePanelAgent 是智能体模型行的模型标记
	vePanelAgent = 341307
	// veThoughts 是回答中的思考面板
	veThoughts = 334158
	// veScrollbar 是对话区的滚动条
	veScrollbar = 273488
	// veChunkOptions 是对话中每段内容的更多选项按钮
	veChunkOptions = 228332
)

// systemPanelElements 是系统指令面板打开时曝光并跟踪可见性的元素，最后一个是系统指令输入框
var systemPanelElements = []int{324606, 324609, 324610, 324611}

// panelCategory 是模型面板的一个分类：id 为目录 field 75 的分类编号，All 为 0
type panelCategory struct {
	id   int
	name string
}

// panelCategories 是官网前端模型面板分类按钮的顺序与名称（收藏分类在账户没有收藏模型时不显示），All 总是显示，其余在有模型属于该分类时显示
var panelCategories = []panelCategory{{0, "All"}, {10, "Featured"}, {5, "Confidential"}, {17, "Gemini"}, {18, "Live"}, {15, "Images"}, {14, "Video"}, {13, "Audio"}, {16, "Music"}, {19, "Agents"}, {3, "Gemma"}}

// featuredCategory 是模型面板打开时选中的 Featured 分类
const featuredCategory = 10

// gridCategories 是页面模型没有入门卡片时新对话页分类网格的顺序
var gridCategories = []int{10, 17, 15, 14, 13, 18}

// panelModel 是页面 ListModels 中一个模型在模型面板中用到的字段
type panelModel struct {
	name string
	// categories 是目录 field 75 的模型分类
	categories []int
	// agent 表示能力码含 65，面板中该行带智能体模型标记
	agent bool
	// docs 表示目录给出了开发者文档链接
	docs bool
	// level 是默认思考档位的目录编号，没有思考档位时为 0
	level int64
}

// parsePanelModels 按目录顺序从 ListModels 响应读出模型面板用到的字段
func parsePanelModels(body []byte) []panelModel {
	raw, err := io.ReadAll(newSparseJSONReader(bytes.NewReader(body)))
	if err != nil {
		return nil
	}
	var root []json.RawMessage
	var rows [][]json.RawMessage
	if json.Unmarshal(raw, &root) != nil || len(root) == 0 || json.Unmarshal(root[0], &rows) != nil {
		return nil
	}
	models := make([]panelModel, 0, len(rows))
	for _, row := range rows {
		var model panelModel
		if len(row) == 0 || json.Unmarshal(row[0], &model.name) != nil {
			continue
		}
		if len(row) > 74 {
			_ = json.Unmarshal(row[74], &model.categories)
		}
		var capabilities []int
		if len(row) > 64 && json.Unmarshal(row[64], &capabilities) == nil {
			model.agent = slices.Contains(capabilities, 65)
		}
		var info []json.RawMessage
		var docs string
		if len(row) > 38 && json.Unmarshal(row[38], &info) == nil && len(info) > 15 && json.Unmarshal(info[15], &docs) == nil {
			model.docs = docs != ""
		}
		var thinking []json.RawMessage
		if len(row) > 71 && json.Unmarshal(row[71], &thinking) == nil && len(thinking) > 5 {
			_ = json.Unmarshal(thinking[5], &model.level)
		}
		models = append(models, model)
	}
	return models
}

// pause 等待 base 加上不超过 spread 的随机时长，模拟官网用户操作之间与页面渲染的间隔
func pause(base, spread time.Duration) {
	time.Sleep(base + rand.N(spread+1))
}

// rowWindow 返回在面板中滚到第 target 行时进入视口的行的范围：目标行之上一行与之下三行，靠近两端时保持五行
func rowWindow(target, count int) (int, int) {
	from := max(target-1, 0)
	to := min(from+5, count)
	return max(to-5, 0), to
}

// apply 像官网用户一样在点击 Run 之前把页面运行设置改成 settings 并记录界面元素事件：换模型、改思考档位、改系统指令、加入附件（上传前已经插入菜单选择时不再操作），各项与页面当前状态相同时不操作；请求模型不在页面模型面板中时不换模型
func (log *pageElements) apply(settings camoufoxnative.PageSettings) {
	log.mu.Lock()
	model, level, system, closed := log.model, log.level, log.system, log.closed
	log.mu.Unlock()
	if closed {
		return
	}
	if settings.Model != "" && settings.Model != model && log.switchModel(settings.Model) {
		log.mu.Lock()
		level = log.level
		log.mu.Unlock()
	}
	if settings.Level != 0 && level != 0 && settings.Level != level {
		log.changeLevel(settings.Level)
	}
	if settings.System != system {
		log.editSystem(settings.System)
	}
	log.mu.Lock()
	attached := log.attached
	log.attached = false
	log.mu.Unlock()
	if settings.Attachments > 0 && !attached {
		log.attach()
	}
}

// locked 在 mu 内以当前时刻执行 action，日志关闭后不执行
func (log *pageElements) locked(action func(at time.Time)) {
	log.mu.Lock()
	defer log.mu.Unlock()
	if !log.closed {
		action(time.Now())
	}
}

// panelElement 是模型面板中曝光的一个元素：tracked 为跟踪可见性的元素，滚入视口时记录可见
type panelElement struct {
	seq, ve int
	tracked bool
}

// switchModel 在模型面板中换成 target：点击模型选择卡片，面板曝光分类按钮与 Featured 分类的模型行，目标不在 Featured 中时先点 All，All 渲染时已在视口中的行（页面模型所在行之上三行到之下一行，再上一行的选择按钮）直接曝光；滚到目标行后记录分类按钮与视口中各行可见，点击目标行，页面按新模型曝光入门卡片（没有入门卡片时为分类网格）、Run 按钮与思考档位。target 不在面板中时返回 false
func (log *pageElements) switchModel(target string) bool {
	log.mu.Lock()
	models, current := log.panel, log.model
	log.mu.Unlock()
	all := slices.IndexFunc(models, func(model panelModel) bool { return model.name == target })
	if all < 0 {
		return false
	}
	var featured []panelModel
	for _, model := range models {
		if slices.Contains(model.categories, featuredCategory) {
			featured = append(featured, model)
		}
	}
	row := slices.IndexFunc(featured, func(model panelModel) bool { return model.name == target })
	var chips []panelElement
	var rows [][]panelElement
	log.locked(func(at time.Time) { log.clicked(log.exposed[veSelector], veSelector, nil, at) })
	pause(890*time.Millisecond, 50*time.Millisecond)
	log.locked(func(at time.Time) {
		chips = log.showCategories(models, at)
		rows = log.showRows(featured, "10", at, -1)
	})
	key, list := "10", featured
	if row >= 0 {
		pause(1960*time.Millisecond, 60*time.Millisecond)
		log.locked(func(time.Time) { log.visibleRows(chips, rows, row) })
		pause(80*time.Millisecond, 10*time.Millisecond)
	} else {
		pause(2040*time.Millisecond, 60*time.Millisecond)
		log.locked(func(at time.Time) {
			log.clicked(chips[0].seq, vePanelCategory, veData{detail: categoryDetail("All")}, at)
		})
		pause(900*time.Millisecond, 40*time.Millisecond)
		key, list, row = "All", models, all
		shown := slices.IndexFunc(models, func(model panelModel) bool { return model.name == current })
		log.locked(func(at time.Time) { rows = log.showRows(models, "All", at, shown) })
		pause(10*time.Millisecond, 5*time.Millisecond)
		log.locked(func(time.Time) { log.visibleRows(chips, nil, 0) })
		pause(970*time.Millisecond, 40*time.Millisecond)
		log.locked(func(time.Time) { log.visibleRows(nil, rows, row) })
		pause(1060*time.Millisecond, 40*time.Millisecond)
	}
	log.locked(func(at time.Time) {
		log.clicked(rows[row][0].seq, vePanelModel, veData{detail: rowDetail(key, target)}, at)
	})
	pause(920*time.Millisecond, 30*time.Millisecond)
	log.locked(func(at time.Time) {
		log.model = target
		log.level = list[row].level
		log.series = modelSeries(log.allSeries, target)
		log.cards = false
		if log.series != nil {
			log.showCards(at)
		} else {
			log.cards = true
			for _, id := range gridCategories {
				if slices.ContainsFunc(models, func(model panelModel) bool { return slices.Contains(model.categories, id) }) {
					log.shown(vePanelCategory, at, categoryDetail(categoryName(id)), false)
				}
			}
		}
		log.shown(veRun, at, modelDetail(target), false)
		if log.level != 0 {
			log.shown(veLevel, at, levelDetail(log.level), false)
		}
	})
	return true
}

// categoryName 返回分类编号的按钮名称
func categoryName(id int) string {
	for _, category := range panelCategories {
		if category.id == id {
			return category.name
		}
	}
	return ""
}

// categoryDetail 返回分类按钮的元素参数
func categoryDetail(name string) []any {
	return []any{nil, []any{nil, nil, name}}
}

// rowDetail 返回模型行选择、复制与文档按钮的元素参数，key 为所在分类（Featured 为 10）
func rowDetail(key, model string) []any {
	return []any{nil, []any{nil, nil, key, model}}
}

// showCategories 曝光模型面板中显示的分类按钮；调用方持有 mu
func (log *pageElements) showCategories(models []panelModel, at time.Time) []panelElement {
	var chips []panelElement
	for _, category := range panelCategories {
		if category.id != 0 && !slices.ContainsFunc(models, func(model panelModel) bool { return slices.Contains(model.categories, category.id) }) {
			continue
		}
		chips = append(chips, panelElement{log.shown(vePanelCategory, at, categoryDetail(category.name), true), vePanelCategory, true})
	}
	return chips
}

// showRows 曝光分类 key 下各模型行的选择、收藏、复制与文档按钮，智能体模型行的选择按钮与模型标记在同一事件中曝光；shown 不小于 0 时面板已打开，第 shown-3 到 shown+1 行已在视口中、直接曝光，第 shown-4 行只有选择按钮已在视口中；调用方持有 mu
func (log *pageElements) showRows(models []panelModel, key string, at time.Time, shown int) [][]panelElement {
	rows := make([][]panelElement, 0, len(models))
	for index, model := range models {
		inView := shown >= 0 && index >= shown-3 && index <= shown+1
		detail := rowDetail(key, model.name)
		show := func(ve int, detail any, tracked bool) panelElement {
			return panelElement{log.shown(ve, at, detail, tracked), ve, tracked}
		}
		var row []panelElement
		if model.agent {
			agent := veData{shown: at.UnixMilli(), detail: append(make([]any, 22), []any{2, model.name})}
			row = append(row, panelElement{log.record(func(seq int) []any {
				elements := []any{
					[]any{vePanelModel, nil, nil, []any{1}, nil, 1, veData{shown: at.UnixMilli(), detail: detail}},
					[]any{vePanelAgent, nil, nil, nil, nil, 1, agent},
				}
				return []any{log.ref(seq), elements, nil, nil, nil, nil, nil, nil, []any{log.ref(seq)}}
			}), vePanelModel, true})
		} else {
			row = append(row, show(vePanelModel, detail, !inView && !(shown >= 0 && index == shown-4)))
		}
		row = append(row, show(vePanelStar, []any{nil, []any{nil, nil, key, model.name, nil, 1}}, !inView), show(vePanelCopy, detail, !inView))
		if model.docs {
			row = append(row, show(vePanelDocs, detail, !inView))
		}
		rows = append(rows, row)
	}
	return rows
}

// visibleRows 记录分类按钮与滚到第 target 行时视口中各行跟踪元素的可见；调用方持有 mu
func (log *pageElements) visibleRows(chips []panelElement, rows [][]panelElement, target int) {
	at := time.Now()
	from, to := rowWindow(target, len(rows))
	elements := slices.Clone(chips)
	for _, row := range rows[from:to] {
		elements = append(elements, row...)
	}
	for _, element := range elements {
		if element.tracked {
			log.visible(element.seq, element.ve, at)
		}
	}
}

// changeLevel 点击思考档位下拉框，再点 level 对应的选项，记录下拉框的改变事件，下一次回答占位时下拉框以新值重新曝光
func (log *pageElements) changeLevel(level int64) {
	pause(1960*time.Millisecond, 60*time.Millisecond)
	log.locked(func(at time.Time) {
		log.changed(veLevel, levelDetail(level), at)
		log.level = level
		log.levelChanged = true
	})
}

// editSystem 点击系统指令卡片打开面板，曝光面板元素，点击系统指令输入框，粘贴系统指令后记录面板元素可见，再关闭面板
func (log *pageElements) editSystem(text string) {
	var panel []int
	log.locked(func(at time.Time) { log.clicked(log.exposed[veSystem], veSystem, veData{detail: systemDetail}, at) })
	pause(900*time.Millisecond, 40*time.Millisecond)
	log.locked(func(at time.Time) {
		for _, ve := range systemPanelElements {
			panel = append(panel, log.shown(ve, at, nil, true))
		}
	})
	pause(2040*time.Millisecond, 60*time.Millisecond)
	log.locked(func(at time.Time) { log.clicked(panel[len(panel)-1], systemPanelElements[len(panel)-1], nil, at) })
	pause(900*time.Millisecond, 40*time.Millisecond)
	log.locked(func(at time.Time) {
		for index, seq := range panel {
			log.visible(seq, systemPanelElements[index], at)
		}
		log.system = text
	})
	pause(500*time.Millisecond, 100*time.Millisecond)
}

// stageAttach 在服务上传附件前像官网用户一样经插入菜单选择文件，本轮 apply 不再重复操作
func (log *pageElements) stageAttach() {
	log.attach()
	log.mu.Lock()
	log.attached = true
	log.mu.Unlock()
}

// pageModel 返回页面当前的模型
func (log *pageElements) pageModel() string {
	log.mu.Lock()
	defer log.mu.Unlock()
	return log.model
}

// attach 点击输入框旁的插入按钮打开菜单，再点 Upload files，菜单经插入按钮中的文件输入框打开文件选择，两次点击都记为插入按钮的点击
func (log *pageElements) attach() {
	log.locked(func(at time.Time) { log.clicked(log.exposed[veInsert], veInsert, nil, at) })
	pause(2960*time.Millisecond, 60*time.Millisecond)
	log.locked(func(at time.Time) { log.clicked(log.exposed[veInsert], veInsert, nil, at) })
	pause(1500*time.Millisecond, 200*time.Millisecond)
}
