package aistudio

import (
	"context"
	"encoding/base64"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"reflect"
	"slices"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/Mag1cFall/AIStudio2API/internal/camoufoxnative"
)

// PooledService 在账户租约内调用协议客户端
type PooledService struct {
	pool   *AccountPool
	client *Client
	// BuildNativeNonstream 让非流式请求优先使用具备资格的 Build 通道
	BuildNativeNonstream bool
	// YouTubeLinks 把 user 文本中的 YouTube 链接作为视频外部媒体发送
	YouTubeLinks bool
	// DiscoverHiddenModels 让同步账户目录时探测官网前端已配置、ListModels 尚未列出的模型
	DiscoverHiddenModels bool
	// StripThoughtSignatures 发送前去掉对话历史中的思考签名
	StripThoughtSignatures bool
	// ContinuationRewrite 改写不接受以 model 轮结尾请求的模型的末尾 assistant 轮
	ContinuationRewrite bool
	// ContinuationPrompt 是改写末尾 assistant 轮时写入系统指令的续写提示词，为空时末尾 assistant 正文作为最后一轮 user
	ContinuationPrompt string
	// omniVideos 记录本进程中尚无结果文件的 Omni 视频任务：值为 nil 时仍在生成，为 error 时生成失败
	omniVideos sync.Map
	// inlineMediaMu 保护 inlineMediaUses
	inlineMediaMu sync.Mutex
	// inlineMediaUses 是本进程进行中的请求引用的内联附件文件 ID 与引用数
	inlineMediaUses map[string]int
}

// PoolRequestContextProvider 从租约账户读取协议上下文
type PoolRequestContextProvider struct {
	pool *AccountPool
}

// ProtectedPreparer 为一次请求写入 fresh WAA proof 并以账户固定指纹发送
type ProtectedPreparer interface {
	Prepare(context.Context, ProtectedRequest) (PreparedProtectedRequest, error)
	BrowserStorageState(context.Context) (StorageState, error)
	SendProtected(context.Context, ProtectedRequest) (*RPCResponse, error)
}

// ProtectedPreparerProvider 按账户返回 lazy WAA preparer
type ProtectedPreparerProvider interface {
	Worker(context.Context, string, string) (ProtectedPreparer, error)
}

// WorkerProtectedTransportOptions 定义受保护请求的 proof 与 HTTP 依赖
type WorkerProtectedTransportOptions struct {
	Transport    *MakerSuiteHTTPTransport
	Workers      ProtectedPreparerProvider
	SetupTimeout time.Duration
}

// WorkerProtectedTransport 将 fresh proof 交给同租约 HTTP 传输
type WorkerProtectedTransport struct {
	transport    *MakerSuiteHTTPTransport
	workers      ProtectedPreparerProvider
	setupTimeout time.Duration
	runs         *pageRuns
}

var _ Service = (*PooledService)(nil)
var _ RequestContextProvider = (*PoolRequestContextProvider)(nil)
var _ ProtectedTransport = (*WorkerProtectedTransport)(nil)
var _ TitleProtectedTransport = (*WorkerProtectedTransport)(nil)

// NewPooledService 创建多账户协议服务
func NewPooledService(pool *AccountPool, client *Client) *PooledService {
	for accountID, tier := range pool.cachedBenefitTiers() {
		client.setBenefitTier(accountID, tier)
	}
	for accountID, catalog := range pool.takeCachedCatalogs() {
		client.setModelCatalog(accountID, catalog)
	}
	return &PooledService{pool: pool, client: client}
}

// NewPoolRequestContextProvider 创建账户协议上下文提供者
func NewPoolRequestContextProvider(pool *AccountPool) *PoolRequestContextProvider {
	return &PoolRequestContextProvider{pool: pool}
}

// NewWorkerProtectedTransport 创建基于 lazy WAA preparer 的受保护传输
func NewWorkerProtectedTransport(options WorkerProtectedTransportOptions) *WorkerProtectedTransport {
	return &WorkerProtectedTransport{
		transport: options.Transport, workers: options.Workers, setupTimeout: options.SetupTimeout, runs: newPageRuns(),
	}
}

// DoProtected 写入 fresh proof 后经账户的 WAA 运行时发送 GenerateContent、Build 代理或写代码助手请求，binding 与写入页面输入框的提示词取自关联函数结果后的 contents，页面提示词为最后一个轮次的文本；账户页面再次运行同一对话的 GenerateContent 按官网 Rerun 不写入提示词
func (t *WorkerProtectedTransport) DoProtected(ctx context.Context, request GenerateRequest, rpc RPCRequest) (*RPCResponse, error) {
	contents, err := linkedContents(request.Contents)
	if err != nil {
		return nil, err
	}
	var prompt string
	proofField := 5
	switch rpc.Method {
	case buildProxyStreamedMethod, buildProxyUnaryMethod:
		prompt, err = buildBindingPrompt(rpc.Body)
		proofField = buildProofField
	case assistantOfflineMethod:
		proofField = assistantProofField
		fallthrough
	default:
		prompt, err = bindingPrompt(GenerateRequest{Contents: contents})
	}
	if err != nil {
		return nil, err
	}
	page := contentsText(contents[max(len(contents)-1, 0):])
	if lease, ok := AccountLeaseFromContext(ctx); ok && rpc.Method == "GenerateContent" && t.runs.rerun(lease.Account().ID, request.Contents) {
		page = ""
		rounds := 0
		for _, content := range request.Contents {
			if content.Role == RoleUser {
				rounds++
			}
		}
		ctx = context.WithValue(ctx, pageRerunKey{}, rounds)
	}
	modelID := strings.TrimPrefix(strings.TrimSpace(request.Model), "models/")
	return t.doPrepared(ctx, prompt, page, proofField, request.continuationProof, AccountSelection{
		ModelID: modelID, Method: "generateContent", AccountID: strings.TrimSpace(request.AccountID),
	}, rpc)
}

// doPrepared 为请求写入 proof 后经账户的 WAA 运行时发送，并写回运行时导出的 Cookie；proof 非空时写入该 proof
func (t *WorkerProtectedTransport) doPrepared(
	ctx context.Context,
	prompt string,
	page string,
	proofField int,
	proof string,
	selection AccountSelection,
	rpc RPCRequest,
) (*RPCResponse, error) {
	lease, worker, rpc, proof, err := t.prepareProtectedRequest(ctx, prompt, page, proofField, proof, selection, rpc)
	if err != nil {
		return nil, err
	}
	browserState, err := worker.BrowserStorageState(ctx)
	if err != nil {
		return nil, fmt.Errorf("读取浏览器 Cookie: %w", err)
	}
	authorization, err := t.transport.signer.Authorization(browserState)
	if err != nil {
		return nil, err
	}
	headers := rpc.Header.Clone()
	headers.Set("Authorization", authorization)
	if lease.CoolingDown(selectionAccessScope(selection)) {
		return nil, ErrAccountCoolingDown
	}
	reportRequestPhase(ctx, RequestPhaseSendingUpstream)
	response, err := worker.SendProtected(ctx, ProtectedRequest{
		URL: rpc.URL, Headers: headers, Body: rpc.Body, Prompt: prompt, PagePrompt: page, ProofField: proofField, Proof: proof,
	})
	if err != nil {
		return nil, err
	}
	saving := &cookieSavingBody{ReadCloser: response.Body, done: make(chan struct{})}
	go func() {
		defer close(saving.done)
		browserState, err := worker.BrowserStorageState(ctx)
		if err != nil {
			saving.err = fmt.Errorf("导出浏览器 Cookie: %w", err)
			return
		}
		if err := lease.ReplaceCookies(browserState.Cookies); err != nil {
			saving.err = fmt.Errorf("保存浏览器 Cookie: %w", err)
		}
	}()
	response.Body = saving
	reportRequestPhase(ctx, RequestPhaseStreaming)
	return response, nil
}

// cookieSavingBody 是在后台写回响应 Cookie 的上游正文，关闭时等待写回完成并返回其错误
type cookieSavingBody struct {
	io.ReadCloser
	done chan struct{}
	err  error
}

// Close 关闭上游正文并返回 Cookie 写回的结果
func (body *cookieSavingBody) Close() error {
	closeErr := body.ReadCloser.Close()
	<-body.done
	return errors.Join(closeErr, body.err)
}

func (t *WorkerProtectedTransport) prepareProtectedRequest(
	ctx context.Context,
	prompt string,
	page string,
	proofField int,
	proof string,
	selection AccountSelection,
	rpc RPCRequest,
) (*AccountLease, ProtectedPreparer, RPCRequest, string, error) {
	lease, ok := AccountLeaseFromContext(ctx)
	if !ok {
		return nil, nil, RPCRequest{}, "", fmt.Errorf("受保护请求缺少账户租约")
	}
	if err := validateLeaseSelection(lease, selection); err != nil {
		return nil, nil, RPCRequest{}, "", err
	}
	worker, err := t.workers.Worker(ctx, lease.Account().ID, selection.ModelID)
	if err != nil {
		return nil, nil, RPCRequest{}, "", fmt.Errorf("获取账户 WAA preparer: %w", err)
	}
	reportRequestPhase(ctx, RequestPhasePreparingWAA)
	prepared, err := worker.Prepare(ctx, ProtectedRequest{
		URL: rpc.URL, Headers: rpc.Header.Clone(), Body: rpc.Body,
		Prompt: prompt, PagePrompt: page, ProofField: proofField, Proof: proof,
	})
	if err != nil {
		return nil, nil, RPCRequest{}, "", fmt.Errorf("准备 fresh WAA proof: %w", err)
	}
	if prepared.Headers == nil || len(prepared.Body) == 0 {
		return nil, nil, RPCRequest{}, "", fmt.Errorf("WAA preparer 返回空请求")
	}
	requestHeaders := rpc.Header
	rpc.AccountID = lease.Account().ID
	rpc.Body = prepared.Body
	rpc.Header = prepared.Headers.Clone()
	for name, values := range requestHeaders {
		rpc.Header.Del(name)
		for _, value := range values {
			rpc.Header.Add(name, value)
		}
	}
	rpc.Header.Set("Content-Type", JSONProtobufContentType)
	return lease, worker, rpc, prepared.Proof, nil
}

// DoProtectedTitle 写入 GenerateTitle fresh proof 后经 Worker 页面发送请求，binding 为提示词与回答以空格连接，页面输入框为空
func (t *WorkerProtectedTransport) DoProtectedTitle(ctx context.Context, request TitleRequest, rpc RPCRequest) (*RPCResponse, error) {
	return t.doPrepared(ctx, request.Prompt+" "+request.Answer, "", 3, "", AccountSelection{ModelID: request.Model}, rpc)
}

func bindingPrompt(request GenerateRequest) (string, error) {
	if len(request.Contents) == 0 {
		return "", fmt.Errorf("GenerateContent contents 不能为空")
	}
	values := make([]string, 0)
	for _, content := range request.Contents {
		for _, part := range content.Parts {
			switch {
			case part.Text != "":
				values = append(values, part.Text)
			case part.InlineData != nil:
				values = append(values, base64.StdEncoding.EncodeToString(part.InlineData.Data))
			case part.File != nil:
				values = append(values, part.File.ID)
			default:
				values = append(values, "")
			}
		}
	}
	return strings.Join(values, " "), nil
}

// contentsText 返回各 Part 的文本以空格连接，作为写入页面输入框的提示词
func contentsText(contents []Content) string {
	values := make([]string, 0)
	for _, content := range contents {
		for _, part := range content.Parts {
			if part.Text != "" {
				values = append(values, part.Text)
			}
		}
	}
	return strings.Join(values, " ")
}

// RequestContext 返回账户时区
func (p *PoolRequestContextProvider) RequestContext(_ context.Context, accountID string) (RequestContext, error) {
	p.pool.mu.Lock()
	defer p.pool.mu.Unlock()
	account := p.pool.byID[accountID]
	if account == nil {
		return RequestContext{}, fmt.Errorf("账户不存在: %s", accountID)
	}
	return RequestContext{Timezone: account.Config.Timezone}, nil
}

// Models 刷新可用账户并返回实时模型并集
func (s *PooledService) Models(ctx context.Context) ([]Model, error) {
	if lease, ok := AccountLeaseFromContext(ctx); ok {
		return s.modelsForLease(ctx, lease, false)
	}
	statuses := s.pool.Status()
	targets := make([]AccountStatus, 0, len(statuses))
	for _, status := range statuses {
		if status.Enabled && (status.State == AccountReady || status.State == AccountBusy) {
			targets = append(targets, status)
		}
	}
	models := make([]Model, 0)
	available := 0
	var failures GroupedErrors
	for _, result := range s.refreshModelCatalogs(ctx, targets) {
		models = mergeModels(models, result.models)
		if result.available {
			available++
		}
		if result.err != nil {
			failures.Add(result.accountID, result.err)
		}
	}
	if ctx.Err() != nil {
		failures.Add("", ctx.Err())
	}
	if available == 0 {
		if len(failures) > 0 {
			return nil, failures.Join(AccountError)
		}
		return nil, ErrNoEligibleAccount
	}
	return models, nil
}

// RefreshAccountModels 占用指定账户的一个普通槽位刷新其权益与模型目录，不受账户启用、调度状态与冷却限制；reload 为 true 时重新载入账户页面
func (s *PooledService) RefreshAccountModels(ctx context.Context, accountID string, reload bool) ([]Model, error) {
	accountID = strings.TrimSpace(accountID)
	lease, err := s.pool.AcquireFor(ctx, AccountSelection{AccountID: accountID, anyState: true})
	if err != nil {
		return nil, err
	}
	models, requestErr := s.modelsForLease(ContextWithAccountLease(ctx, lease), lease, reload)
	releaseErr := lease.Release()
	if requestErr != nil {
		return nil, fmt.Errorf("刷新模型目录: %w", errors.Join(requestErr, releaseErr))
	}
	if releaseErr != nil {
		return models, fmt.Errorf("释放模型目录租约: %w", releaseErr)
	}
	return models, nil
}

// AccountRefresh 为一次账户状态刷新前后的权益与模型数，ModelsChanged 表示该账户的目录条目有变化
type AccountRefresh struct {
	PreviousTier   BenefitTier
	Tier           BenefitTier
	PreviousModels int
	Models         int
	ModelsChanged  bool
	Skipped        bool
}

// RefreshAccountState 重新载入账户页面读取权益与模型目录，登录失效时标记账户需要登录，因上游要求验证而受限的账户再发一次生成请求核对验证状态；wait 为 true 时等待该账户的一个普通槽位且不受调度状态限制，否则只用就绪账户的空闲槽位
func (s *PooledService) RefreshAccountState(ctx context.Context, accountID string, wait bool) (AccountRefresh, error) {
	accountID = strings.TrimSpace(accountID)
	var lease *AccountLease
	var err error
	if wait {
		lease, err = s.pool.AcquireFor(ctx, AccountSelection{AccountID: accountID, anyState: true})
	} else {
		lease, _, err = s.pool.TryAcquireFor(ctx, AccountSelection{AccountID: accountID})
	}
	if lease == nil {
		return AccountRefresh{Skipped: err == nil}, err
	}
	account := lease.Account()
	s.pool.mu.Lock()
	refresh := AccountRefresh{PreviousTier: account.BenefitTier, PreviousModels: len(account.Models)}
	previous := slices.Clone(account.Models)
	s.pool.mu.Unlock()
	models, err := s.modelsForLease(ContextWithAccountLease(ctx, lease), lease, true)
	if err == nil && s.pool.verificationRestricted(accountID) {
		err = s.checkAccountVerification(ctx, lease)
	}
	if err != nil {
		return refresh, errors.Join(err, lease.Release())
	}
	s.pool.mu.Lock()
	refresh.Tier = account.BenefitTier
	refresh.ModelsChanged = !reflect.DeepEqual(previous, account.Models)
	s.pool.mu.Unlock()
	refresh.Models = len(models)
	return refresh, lease.Release()
}

// checkAccountVerification 以账户的页面初始化模型在租约内发一次最小生成请求：上游仍拒绝账户时按其原因保持服务受限，给出其他结果时解除受限
func (s *PooledService) checkAccountVerification(ctx context.Context, lease *AccountLease) error {
	accountID := lease.Account().ID
	model, err := s.pool.BootstrapModel(accountID)
	if err != nil {
		return err
	}
	events, err := s.Generate(ContextWithAccountLease(ctx, lease), GenerateRequest{
		Model: model, AccountID: accountID, Contents: []Content{{Role: RoleUser, Parts: []Part{{Text: "Hi"}}}},
	})
	if err == nil {
		for event := range events {
			if event.Kind == EventError {
				err = event.Err
			}
		}
	}
	if denial := RestrictionDenial(err); denial != nil {
		return s.pool.MarkRestricted(accountID, denial)
	}
	var rpcError *RPCError
	if err != nil && !errors.As(err, &rpcError) {
		return err
	}
	return s.pool.clearRestriction(accountID)
}

// CachedModels 返回启用账户最近同步目录的并集
func (s *PooledService) CachedModels() []Model {
	s.pool.mu.Lock()
	defer s.pool.mu.Unlock()
	models := make([]Model, 0)
	for _, account := range s.pool.accounts {
		if account != nil && account.Config.Enabled {
			models = mergeModels(models, account.Models)
		}
	}
	return mergeModels(models, s.pool.buildOnlyModelsLocked())
}

type accountModelsResult struct {
	accountID string
	models    []Model
	available bool
	err       error
}

func (s *PooledService) refreshModelCatalogs(ctx context.Context, statuses []AccountStatus) []accountModelsResult {
	results := make(chan accountModelsResult, len(statuses))
	var refreshes sync.WaitGroup
	for _, status := range statuses {
		refreshes.Add(1)
		go func(status AccountStatus) {
			defer refreshes.Done()
			results <- s.modelsForStatus(ctx, status)
		}(status)
	}
	go func() {
		refreshes.Wait()
		close(results)
	}()
	collected := make([]accountModelsResult, 0, len(statuses))
	for result := range results {
		collected = append(collected, result)
	}
	return collected
}

func (s *PooledService) modelsForStatus(ctx context.Context, status AccountStatus) accountModelsResult {
	cached := s.cachedModels(status.ID)
	if status.State == AccountBusy {
		if len(cached) > 0 {
			return accountModelsResult{models: cached, available: true}
		}
		return accountModelsResult{accountID: status.ID, err: errors.New("正在使用且没有缓存模型目录")}
	}
	lease, err := s.pool.AcquireFor(ctx, AccountSelection{AccountID: status.ID})
	if err != nil {
		return accountModelsResult{
			accountID: status.ID, models: cached, available: len(cached) > 0,
			err: fmt.Errorf("获取模型目录租约: %w", err),
		}
	}
	accountModels, requestErr := s.modelsForLease(ContextWithAccountLease(ctx, lease), lease, false)
	releaseErr := lease.Release()
	if requestErr != nil {
		failure := fmt.Errorf("刷新模型目录: %w", errors.Join(requestErr, releaseErr))
		return accountModelsResult{accountID: status.ID, models: cached, available: len(cached) > 0, err: failure}
	}
	if releaseErr != nil {
		return accountModelsResult{
			accountID: status.ID, models: accountModels, available: true,
			err: fmt.Errorf("释放模型目录租约: %w", releaseErr),
		}
	}
	return accountModelsResult{models: accountModels, available: true}
}

func (s *PooledService) cachedModels(accountID string) []Model {
	s.pool.mu.Lock()
	defer s.pool.mu.Unlock()
	account := s.pool.byID[accountID]
	if account == nil {
		return nil
	}
	return cloneModels(account.Models)
}

// DefinitiveAuthenticationFailure 判断上游是否明确要求重新认证
func DefinitiveAuthenticationFailure(err error) bool {
	if errors.Is(err, camoufoxnative.ErrAuthenticationRequired) {
		return true
	}
	var rpcError *RPCError
	return errors.As(err, &rpcError) && !driveAuthorizationMissing(err) &&
		(rpcError.StatusCode == http.StatusUnauthorized || rpcError.Code == 16)
}

// DefinitiveWAARuntimeFailure 判断上游是否明确拒绝当前 WAA 运行态
func DefinitiveWAARuntimeFailure(err error) bool {
	var rpcError *RPCError
	return errors.As(err, &rpcError) && modelBoundRPCMethod(rpcError.Method) &&
		rpcError.StatusCode == http.StatusNotFound && rpcError.Code == 5 &&
		strings.Contains(rpcError.Message, "Ambiguous request for service ''")
}

func modelBoundRPCMethod(method string) bool {
	switch strings.ToLower(strings.TrimSpace(method)) {
	case "generatecontent", "generatevideo", "bidigeneratecontent":
		return true
	default:
		return false
	}
}

// markRetryableFailure 记录可换号的失败：认证失败时确认账户会话，其余失败以收到失败的时刻为检查时刻按额度或 30 秒冷却该账户
func (s *PooledService) markRetryableFailure(ctx context.Context, lease *AccountLease, modelAccessScope string, err error) error {
	accountID := lease.Account().ID
	if DefinitiveAuthenticationFailure(err) {
		return lease.ConfirmAuthenticationFailure(ctx, err)
	}
	if errors.Is(err, ErrAccountCoolingDown) {
		return nil
	}
	now := time.Now()
	cooldown, ok := QuotaCooldownForError(err, now)
	if !ok {
		cooldown = QuotaCooldown{Until: now.Add(30 * time.Second), Reason: err.Error()}
	}
	if cooldown.Global {
		modelAccessScope = ""
	}
	_, _, markErr := s.pool.MarkQuotaCooldownIfGeneration(accountID, modelAccessScope, lease.ModelAccessGeneration(), now, cooldown)
	return markErr
}

// modelsForLease 以账户会话页面载入时的响应更新权益与模型目录，reload 为 true 时重新载入页面
func (s *PooledService) modelsForLease(ctx context.Context, lease *AccountLease, reload bool) ([]Model, error) {
	account := lease.Account()
	leaseCtx := ContextWithAccountLease(ctx, lease)
	tier, models, err := s.client.loadPageCatalog(leaseCtx, account.ID, reload)
	if err != nil {
		return nil, s.catalogFailure(leaseCtx, lease, err)
	}
	var hidden map[string]string
	if s.DiscoverHiddenModels {
		if hidden, err = s.client.DiscoverHiddenModels(leaseCtx, account.ID); err != nil {
			slog.Warn("探测官网隐藏模型失败", "account", account.ID, "error", err)
		}
		models = s.client.accountModels(account.ID)
	}
	if err := s.pool.SetHiddenModels(account.ID, hidden, s.DiscoverHiddenModels && err == nil); err != nil {
		return nil, err
	}
	buildEnabled := s.pool.BuildEnabled()
	var buildModels []Model
	var buildErr error
	if buildEnabled {
		buildModels, buildErr = s.client.BuildModelsForAccount(leaseCtx, account.ID)
	}
	if err := errors.Join(
		lease.MarkAuthenticationValid(),
		s.pool.ClearCooldownIfGeneration(
			account.ID, "", lease.ModelAccessGeneration(), lease.CheckedAt(),
		),
	); err != nil {
		return nil, err
	}
	if err := s.pool.SetCatalog(account.ID, tier, models); err != nil {
		return nil, err
	}
	if buildEnabled && buildErr == nil {
		if err := s.pool.SetBuildCatalog(account.ID, buildModels); err != nil {
			return models, err
		}
	}
	if err := s.pool.SaveCatalogCache(account.ID, s.client.modelCatalogSource(account.ID)); err != nil {
		slog.Warn("账户模型目录缓存保存失败", "account", account.ID, "error", err)
	}
	if buildEnabled && buildErr != nil {
		return models, fmt.Errorf("读取 Build 模型目录: %w", buildErr)
	}
	return models, nil
}

// catalogFailure 认证失败时确认账户会话并把已失效的账户标为需要登录，Google 拒绝该账户时标为服务受限，其余失败记为该账户最近一次目录读取错误
func (s *PooledService) catalogFailure(ctx context.Context, lease *AccountLease, err error) error {
	if DefinitiveAuthenticationFailure(err) {
		return errors.Join(err, lease.ConfirmAuthenticationFailure(ctx, err))
	}
	if denial := RestrictionDenial(err); denial != nil {
		return errors.Join(err, s.pool.MarkRestricted(lease.Account().ID, denial))
	}
	s.pool.recordCatalogFailure(lease.Account().ID, err)
	return err
}

// CountTokens 使用支持目标模型的独占账户按客户端给出的对话计数，只有系统指令时以 user 轮计数后还原为系统指令明细
func (s *PooledService) CountTokens(ctx context.Context, request TokenCountRequest) (TokenCount, error) {
	modelID := strings.TrimPrefix(strings.TrimSpace(request.Model), "models/")
	if modelID == "" {
		return TokenCount{}, fmt.Errorf("%w: CountTokens model 不能为空", ErrInvalidArgument)
	}
	request.System = clientSystem(request.System)
	if s.YouTubeLinks {
		request.Contents = attachYouTubeLinks(request.Contents)
	}
	if s.StripThoughtSignatures {
		request.Contents = stripThoughtSignatures(request.Contents)
	}
	systemOnly := len(request.Contents) == 0
	if systemOnly {
		if strings.TrimSpace(SystemText(request.System)) == "" {
			return TokenCount{}, fmt.Errorf("%w: 请求没有系统提示或对话内容", ErrInvalidArgument)
		}
		request.System, request.Contents = nil, []Content{{Role: RoleUser, Parts: []Part{{Text: SystemText(request.System)}}}}
	}
	modelAccessScope := ModelAccessKey("count-tokens", modelID)
	selection := AccountSelection{ModelID: modelID, ModelAccessScope: modelAccessScope, Method: "countTokens"}
	if mixedMediaResolution(request.MediaResolution, request.Contents) {
		selection.Channel = ChannelBuild
	}
	var count TokenCount
	var requestErr error
	for attempt := 0; attempt < accountAttemptLimit(s.pool, false); attempt++ {
		lease, owned, err := resolveAccountLease(ctx, s.pool, selection)
		if err != nil {
			if requestErr != nil && errors.Is(err, ErrNoEligibleAccount) {
				return count, requestErr
			}
			return TokenCount{}, err
		}
		accountID := lease.Account().ID
		count, requestErr = s.client.CountTokensForAccount(ContextWithAccountLease(ctx, lease), accountID, request)
		var stateErr error
		retryable := retryableAccountError(requestErr)
		if requestErr == nil {
			if systemOnly && len(count.Contents) == 1 {
				count = systemOnlyCount(count)
			}
			stateErr = errors.Join(
				lease.MarkAuthenticationValid(),
				s.pool.ClearCooldownIfGeneration(
					accountID, modelAccessScope, lease.ModelAccessGeneration(), lease.CheckedAt(),
				),
			)
		} else if DefinitiveAuthenticationFailure(requestErr) {
			stateErr = lease.ConfirmAuthenticationFailure(ctx, requestErr)
		} else if retryable {
			stateErr = s.markRetryableFailure(ctx, lease, modelAccessScope, requestErr)
		}
		var releaseErr error
		if owned {
			releaseErr = lease.Release()
		}
		if requestErr == nil || !retryable {
			return count, errors.Join(requestErr, stateErr, releaseErr)
		}
		requestErr = errors.Join(requestErr, stateErr, releaseErr)
		if stateErr != nil || releaseErr != nil {
			return count, requestErr
		}
	}
	return count, requestErr
}

// systemOnlyCount 把只有系统指令的请求以 user 轮计数的结果还原为系统指令明细，与系统指令一样不计角色 token
func systemOnlyCount(count TokenCount) TokenCount {
	role := count.Contents[0].RoleTokens
	count.InputTokens -= role
	count.PromptTokensDetails = subtractTextTokens(count.PromptTokensDetails, role)
	count.System, count.Contents = &ContentTokens{PartTokens: count.Contents[0].PartTokens}, nil
	return count
}

// ValidateGenerateRequest 在选择账户前校验与上游通道无关的生成参数
func (s *PooledService) ValidateGenerateRequest(request GenerateRequest) error {
	modelID := strings.TrimPrefix(strings.TrimSpace(request.Model), "models/")
	if modelID == "" {
		return fmt.Errorf("%w: GenerateContent model 不能为空", ErrInvalidArgument)
	}
	request.System, request.Contents = normalizeTurns(request.System, request.Contents, s.rewritesAssistantTail(modelID), s.ContinuationPrompt)
	if len(request.Contents) == 0 {
		return fmt.Errorf("%w: 请求没有系统提示或对话内容", ErrInvalidArgument)
	}
	request, _, err := prepareToolRequest(request)
	if err != nil {
		return fmt.Errorf("%w: %v", ErrInvalidArgument, err)
	}
	return s.client.validateGenerateRequest(request)
}

// generateTurns 返回 Generate 发往上游前改写的系统指令与对话轮
func (s *PooledService) generateTurns(request GenerateRequest) ([]string, []Content) {
	modelID := strings.TrimPrefix(strings.TrimSpace(request.Model), "models/")
	system, contents := normalizeTurns(request.System, request.Contents, s.rewritesAssistantTail(modelID), s.ContinuationPrompt)
	if s.YouTubeLinks {
		contents = attachYouTubeLinks(contents)
	}
	if s.StripThoughtSignatures {
		contents = stripThoughtSignatures(contents)
	}
	return system, contents
}

// Generate 使用支持目标模型的独占账户生成事件流
func (s *PooledService) Generate(ctx context.Context, request GenerateRequest) (<-chan Event, error) {
	modelID := strings.TrimPrefix(strings.TrimSpace(request.Model), "models/")
	if modelID == "" {
		return nil, fmt.Errorf("%w: GenerateContent model 不能为空", ErrInvalidArgument)
	}
	request.System, request.Contents = s.generateTurns(request)
	if len(request.Contents) == 0 {
		return nil, fmt.Errorf("%w: 请求没有系统提示或对话内容", ErrInvalidArgument)
	}
	request.restoreModelTurns = !s.StripThoughtSignatures
	resourceID, err := s.pool.ResourceIDForContents(ctx, request.Contents)
	if err != nil {
		return nil, err
	}
	selection := AccountSelection{
		ModelID:    modelID,
		Method:     "generateContent",
		AccountID:  strings.TrimSpace(request.AccountID),
		ResourceID: resourceID,
	}
	if RequestNeedsBuild(request) || request.Unary && s.BuildNativeNonstream {
		selection.PreferredChannel = ChannelBuild
	}
	pinned := selection.AccountID != "" || selection.ResourceID != ""
	if _, ok := AccountLeaseFromContext(ctx); ok {
		pinned = true
	}
	var requestErr error
	for attempt := 0; attempt < accountAttemptLimit(s.pool, pinned); attempt++ {
		lease, owned, err := resolveAccountLease(ctx, s.pool, selection)
		if err != nil {
			if requestErr != nil && errors.Is(err, ErrNoEligibleAccount) {
				return nil, requestErr
			}
			return nil, err
		}
		accountID := lease.Account().ID
		request.AccountID = accountID
		events, err := s.client.Generate(ContextWithAccountLease(ctx, lease), request)
		if err == nil {
			if !owned {
				return events, nil
			}
			forwarded := make(chan Event, 8)
			go forwardEventsWithLease(ctx, events, forwarded, lease, s.pool, modelID)
			return forwarded, nil
		}
		requestErr = err
		retryable := retryableAccountError(err)
		var stateErr error
		if owned && retryable {
			stateErr = s.markRetryableFailure(ctx, lease, lease.CooldownScope(modelID), err)
		}
		if owned {
			requestErr = errors.Join(requestErr, stateErr, lease.Release())
		}
		if !retryable || !owned || stateErr != nil {
			return nil, requestErr
		}
	}
	return nil, requestErr
}

func accountAttemptLimit(pool *AccountPool, pinned bool) int {
	if pinned {
		return 1
	}
	eligible := 0
	for _, status := range pool.Status() {
		if status.Enabled && (status.State == AccountReady || status.State == AccountBusy) {
			eligible++
		}
	}
	return max(eligible, 1)
}

func retryableAccountError(err error) bool {
	if driveAuthorizationMissing(err) {
		return false
	}
	if errors.Is(err, ErrAccountCoolingDown) {
		return true
	}
	var rpcError *RPCError
	if !errors.As(err, &rpcError) {
		return false
	}
	return rpcError.StatusCode == http.StatusUnauthorized || rpcError.StatusCode == http.StatusForbidden ||
		rpcError.StatusCode == http.StatusTooManyRequests || rpcError.StatusCode >= http.StatusInternalServerError
}

// forwardEventsWithLease 转发事件并在结束或取消时释放账户租约
func forwardEventsWithLease(
	ctx context.Context,
	source <-chan Event,
	destination chan<- Event,
	lease *AccountLease,
	pool *AccountPool,
	modelID string,
) {
	defer close(destination)
	defer func() {
		if err := lease.Release(); err != nil {
			select {
			case destination <- Event{Kind: EventError, Err: err}:
			case <-ctx.Done():
			}
		}
	}()
	terminal := false
	accountID := lease.Account().ID
	accessGeneration := lease.ModelAccessGeneration()
	checkedAt := lease.CheckedAt()
	for {
		var event Event
		select {
		case next, ok := <-source:
			if !ok {
				return
			}
			event = next
		case <-ctx.Done():
			return
		}
		if terminal {
			continue
		}
		if event.Kind == EventError {
			terminal = true
			if DefinitiveAuthenticationFailure(event.Err) {
				if err := lease.ConfirmAuthenticationFailure(ctx, event.Err); err != nil {
					event.Err = errors.Join(event.Err, err)
				}
			} else if cooldown, ok := QuotaCooldownForError(event.Err, time.Now()); ok {
				scope := lease.CooldownScope(modelID)
				if cooldown.Global {
					scope = ""
				}
				if _, _, err := pool.MarkQuotaCooldownIfGeneration(accountID, scope, accessGeneration, time.Now(), cooldown); err != nil {
					event.Err = errors.Join(event.Err, err)
				}
			}
		}
		select {
		case destination <- event:
		case <-ctx.Done():
			return
		}
		if event.Kind == EventFinish {
			terminal = true
			if err := lease.MarkAuthenticationValid(); err != nil {
				slog.Error("账户认证状态保存失败", "account", accountID, "error", err)
			}
			go func() {
				if _, err := pool.MarkModelAccessVerifiedIfGeneration(
					accountID, lease.CooldownScope(modelID), accessGeneration, checkedAt,
				); err != nil {
					slog.Error("账户模型资格保存失败", "account", accountID, "model", modelID, "error", err)
				}
			}()
		}
	}
}

func mergeModels(base []Model, additions []Model) []Model {
	merged := make(map[string]Model, len(base)+len(additions))
	for _, model := range append(cloneModels(base), cloneModels(additions)...) {
		current, exists := merged[model.ID]
		if !exists {
			merged[model.ID] = model
			continue
		}
		current.Methods = unionOrdered(current.Methods, model.Methods)
		if current.Name == "" {
			current.Name = model.Name
		}
		if current.Description == "" {
			current.Description = model.Description
		}
		current.InputTokenLimit = minimumPositive(current.InputTokenLimit, model.InputTokenLimit)
		current.OutputTokenLimit = minimumPositive(current.OutputTokenLimit, model.OutputTokenLimit)
		if current.Capabilities == nil && len(model.Capabilities) > 0 {
			current.Capabilities = make(map[string]bool, len(model.Capabilities))
		}
		for name, enabled := range model.Capabilities {
			current.Capabilities[name] = current.Capabilities[name] || enabled
		}
		if current.CapabilityOptions == nil && len(model.CapabilityOptions) > 0 {
			current.CapabilityOptions = make(map[string][]string, len(model.CapabilityOptions))
		}
		for name, values := range model.CapabilityOptions {
			current.CapabilityOptions[name] = unionOrdered(current.CapabilityOptions[name], values)
		}
		if len(current.VoiceDetails) == 0 {
			current.VoiceDetails = model.VoiceDetails
		}
		if len(current.Languages) == 0 {
			current.Languages = model.Languages
		}
		current.AccessModes = unionInt64(current.AccessModes, model.AccessModes)
		current.Paid = current.Paid || model.Paid
		merged[model.ID] = current
	}
	result := make([]Model, 0, len(merged))
	for _, id := range upstreamModelOrder(base, additions) {
		model := merged[id]
		model.Methods = unionOrdered(nil, model.Methods)
		result = append(result, model)
	}
	return result
}

// upstreamModelOrder 按各目录的上游顺序合并模型 ID
func upstreamModelOrder(lists ...[]Model) []string {
	var order []string
	for _, models := range lists {
		previous := len(order) - 1
		if index := slices.IndexFunc(models, func(model Model) bool { return slices.Contains(order, model.ID) }); index >= 0 {
			previous = slices.Index(order, models[index].ID) - 1
		}
		for _, model := range models {
			if index := slices.Index(order, model.ID); index >= 0 {
				previous = index
				continue
			}
			previous++
			order = slices.Insert(order, previous, model.ID)
		}
	}
	return order
}

func unionInt64(left []int64, right []int64) []int64 {
	values := make(map[int64]struct{}, len(left)+len(right))
	for _, value := range left {
		values[value] = struct{}{}
	}
	for _, value := range right {
		values[value] = struct{}{}
	}
	result := make([]int64, 0, len(values))
	for value := range values {
		result = append(result, value)
	}
	sort.Slice(result, func(left int, right int) bool { return result[left] < result[right] })
	return result
}

// unionOrdered 按首次出现的顺序合并两组取值并去重
func unionOrdered(left []string, right []string) []string {
	result := slices.Clone(left)
	for _, value := range right {
		if !slices.Contains(result, value) {
			result = append(result, value)
		}
	}
	return result
}

func minimumPositive(left int64, right int64) int64 {
	if left <= 0 {
		return right
	}
	if right <= 0 || left < right {
		return left
	}
	return right
}
