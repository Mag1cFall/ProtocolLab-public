package aistudio

import (
	"context"
	"maps"
	"slices"
	"sort"
	"strings"
	"time"
)

// Channel 表示生成请求的上游额度来源
type Channel string

const (
	// ChannelPlayground 表示官网 Playground 的 GenerateContent
	ChannelPlayground Channel = "playground"
	// ChannelBuild 表示官网 Build 应用代理的 Gemini API 调用
	ChannelBuild Channel = "build"
	// ChannelAssistant 表示官网 Build 写代码助手，只服务 -build 模型
	ChannelAssistant Channel = "assistant"
)

// ChannelCooldownScope 返回通道在作用域上的冷却键，Build 使用 build:<作用域>
func ChannelCooldownScope(channel Channel, scope string) string {
	scope = strings.TrimSpace(scope)
	if channel == ChannelBuild && scope != "" {
		return ModelAccessKey(string(ChannelBuild), scope)
	}
	return scope
}

// channelCandidate 表示一个账户与通道组合
type channelCandidate struct {
	index   int
	channel Channel
}

// SetUpstreamChannels 设置生成请求按顺序启用的上游通道
func (p *AccountPool) SetUpstreamChannels(channels []Channel) {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.channels = append([]Channel(nil), channels...)
	p.notifyLocked()
}

// SetModelChannels 设置模型限定使用的上游通道，键为模型 ID
func (p *AccountPool) SetModelChannels(channels map[string]Channel) {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.modelChannels = maps.Clone(channels)
	p.notifyLocked()
}

// SetModelAccounts 设置模型可用的账户 ID，未列出的模型可用全部账户
func (p *AccountPool) SetModelAccounts(accounts map[string][]string) {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.modelAccounts = maps.Clone(accounts)
	p.notifyLocked()
}

// SetAccountOrder 设置 fill-first 依次使用的账户 ID
func (p *AccountPool) SetAccountOrder(accountIDs []string) {
	order := make(map[string]int, len(accountIDs))
	for rank, accountID := range accountIDs {
		order[accountID] = rank
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	p.accountOrder = order
	p.notifyLocked()
}

// apiKeyContextKey 是请求上下文中所用 API key 的键
type apiKeyContextKey struct{}

// ContextWithAPIKey 返回带有请求所用 API key 的上下文，账户池只在该 key 绑定的账户中选号
func ContextWithAPIKey(ctx context.Context, key string) context.Context {
	return context.WithValue(ctx, apiKeyContextKey{}, key)
}

// accountContextKey 是请求上下文中指定账户的键
type accountContextKey struct{}

// ContextWithAccount 返回带有请求指定账户的上下文，账户池只用该账户
func ContextWithAccount(ctx context.Context, accountID string) context.Context {
	return context.WithValue(ctx, accountContextKey{}, accountID)
}

// contextAccount 返回请求上下文中指定的账户 ID，没有指定时为空
func contextAccount(ctx context.Context) string {
	accountID, _ := ctx.Value(accountContextKey{}).(string)
	return accountID
}

// ContextWithSelectionScope 返回带有 source 中所用 API key 与指定账户的 ctx，供跨请求的操作沿用发起请求的选号范围
func ContextWithSelectionScope(ctx, source context.Context) context.Context {
	if key, ok := source.Value(apiKeyContextKey{}).(string); ok {
		ctx = ContextWithAPIKey(ctx, key)
	}
	if accountID := contextAccount(source); accountID != "" {
		ctx = ContextWithAccount(ctx, accountID)
	}
	return ctx
}

// SetAPIKeyAccounts 设置各 API key 可用的账户 ID，未列出的 key 可用全部账户
func (p *AccountPool) SetAPIKeyAccounts(accounts map[string][]string) {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.apiKeyAccounts = maps.Clone(accounts)
	p.notifyLocked()
}

// scopedSelection 把请求指定的账户、所用 API key 与模型绑定的账户并入选择，指定账户与绑定资源的选择不受模型绑定限制
func (p *AccountPool) scopedSelection(ctx context.Context, selection AccountSelection) AccountSelection {
	if selection.AccountID == "" {
		selection.AccountID = contextAccount(ctx)
	}
	key, _ := ctx.Value(apiKeyContextKey{}).(string)
	p.mu.Lock()
	keyScope, keyBound := p.apiKeyAccounts[key]
	modelScope, modelBound := p.modelAccounts[strings.TrimPrefix(strings.TrimSpace(selection.ModelID), "models/")]
	p.mu.Unlock()
	if keyBound {
		selection.AllowedAccountIDs = narrowedAccounts(selection.AllowedAccountIDs, keyScope)
	}
	if modelBound && selection.AccountID == "" && selection.ResourceID == "" {
		selection.AllowedAccountIDs = narrowedAccounts(selection.AllowedAccountIDs, modelScope)
	}
	return selection
}

// narrowedAccounts 返回 allowed 中属于 scope 的账户，allowed 为 nil 时返回 scope
func narrowedAccounts(allowed []string, scope []string) []string {
	if allowed == nil {
		return scope
	}
	return slices.DeleteFunc(slices.Clone(allowed), func(id string) bool { return !slices.Contains(scope, id) })
}

// SetBuildCatalog 保存账户 Build 代理返回的 Gemini API 模型目录
func (p *AccountPool) SetBuildCatalog(accountID string, models []Model) error {
	p.mu.Lock()
	defer p.mu.Unlock()
	account := p.byID[accountID]
	if account == nil {
		return ErrAccountNotFound
	}
	account.buildModels = cloneModels(models)
	p.notifyLocked()
	return nil
}

// BuildEnabled 返回 Build 通道是否启用
func (p *AccountPool) BuildEnabled() bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.channelEnabledLocked(ChannelBuild)
}

// PlaygroundEnabled 返回 Playground 通道是否启用
func (p *AccountPool) PlaygroundEnabled() bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.channelEnabledLocked(ChannelPlayground)
}

// Channel 返回租约本次使用的上游通道
func (l *AccountLease) Channel() Channel {
	if l == nil || l.channel == "" {
		return ChannelPlayground
	}
	return l.channel
}

// CooldownScope 返回租约通道在模型作用域上的冷却键
func (l *AccountLease) CooldownScope(scope string) string {
	return ChannelCooldownScope(l.Channel(), scope)
}

func (p *AccountPool) channelEnabledLocked(channel Channel) bool {
	if channel == ChannelAssistant {
		return true
	}
	if len(p.channels) == 0 {
		return channel == ChannelPlayground
	}
	return slices.Contains(p.channels, channel)
}

func (p *AccountPool) enabledChannelsLocked() []Channel {
	if len(p.channels) == 0 {
		return []Channel{ChannelPlayground}
	}
	return p.channels
}

// generationChannelSelection 判断选择是否属于按通道调度的生成请求
func generationChannelSelection(selection AccountSelection) bool {
	return strings.TrimSpace(selection.ModelID) != "" && selection.Method == "generateContent" &&
		strings.TrimSpace(selection.ModelAccessScope) == "" && strings.TrimSpace(selection.ResourceID) == "" &&
		strings.TrimSpace(selection.Capability) == "" && !selection.PlaygroundOnly
}

// buildMethods 表示经 Build 代理调用、只服务 Playground 目录没有的模型的上游方法
var buildMethods = []string{"embedContent", "bidiGenerateContent", "bidiGenerateMusic", "countTokens"}

// buildMethodSelection 判断选择是否为 embedding、实时或计数方法，这类选择的 Build 组合只服务 Build 独有模型
func buildMethodSelection(selection AccountSelection) bool {
	return strings.TrimSpace(selection.ModelID) != "" && slices.Contains(buildMethods, selection.Method) &&
		strings.TrimSpace(selection.Capability) == "" && !selection.PlaygroundOnly
}

// selectionChannelsLocked 返回选择可使用的通道顺序，优先通道排在首位，限定通道的模型只使用该通道
func (p *AccountPool) selectionChannelsLocked(selection AccountSelection) []Channel {
	if p.assistantModelLocked(selection.ModelID) {
		return []Channel{ChannelAssistant}
	}
	if !generationChannelSelection(selection) {
		if buildMethodSelection(selection) && p.channelEnabledLocked(ChannelBuild) {
			if selection.Method == "embedContent" || selection.Channel == ChannelBuild {
				return []Channel{ChannelBuild}
			}
			return []Channel{ChannelPlayground, ChannelBuild}
		}
		return []Channel{ChannelPlayground}
	}
	limited, restricted := p.modelChannels[strings.TrimPrefix(strings.TrimSpace(selection.ModelID), "models/")]
	if selection.Channel != "" {
		if p.channelEnabledLocked(selection.Channel) && (!restricted || limited == selection.Channel) {
			return []Channel{selection.Channel}
		}
		return nil
	}
	channels := p.enabledChannelsLocked()
	if restricted {
		if slices.Contains(channels, limited) {
			return []Channel{limited}
		}
		return nil
	}
	if selection.PreferredChannel == "" || !slices.Contains(channels, selection.PreferredChannel) {
		return channels
	}
	ordered := []Channel{selection.PreferredChannel}
	for _, channel := range channels {
		if channel != selection.PreferredChannel {
			ordered = append(ordered, channel)
		}
	}
	return ordered
}

// preferredChannelOpenLocked 判断账户的优先通道支持选择且未冷却
func (p *AccountPool) preferredChannelOpenLocked(account *Account, selection AccountSelection, now time.Time) bool {
	preferred := selection.PreferredChannel
	if preferred == "" || !slices.Contains(p.selectionChannelsLocked(selection), preferred) ||
		!p.channelSupportsLocked(account, preferred, selection) {
		return false
	}
	_, cooling := selectionCooldown(account, ChannelCooldownScope(preferred, selectionAccessScope(selection)), selection, now)
	return !cooling
}

// channelSupportsLocked 判断账户的通道目录是否支持选择
func (p *AccountPool) channelSupportsLocked(account *Account, channel Channel, selection AccountSelection) bool {
	if strings.TrimSpace(selection.ModelID) == "" {
		return channel == ChannelPlayground
	}
	switch channel {
	case ChannelPlayground:
		if generationChannelSelection(selection) && !p.channelEnabledLocked(ChannelPlayground) {
			return false
		}
		return accountSupportsSelection(account, selection)
	case ChannelBuild:
		if buildMethodSelection(selection) {
			return p.channelEnabledLocked(ChannelBuild) && (p.buildSupportsMethodLocked(account, selection.ModelID, selection.Method) ||
				selection.Channel == ChannelBuild && buildCatalogHasMethod(account, selection.ModelID, selection.Method))
		}
		return generationChannelSelection(selection) && p.channelEnabledLocked(ChannelBuild) &&
			p.buildSupportsModelLocked(account, selection.ModelID, selection.anyTier)
	case ChannelAssistant:
		return accountSupportsSelection(account, selection)
	default:
		return false
	}
}

// accountSupportsAnyChannelLocked 判断账户至少有一个通道支持选择
func (p *AccountPool) accountSupportsAnyChannelLocked(account *Account, selection AccountSelection) bool {
	for _, channel := range p.selectionChannelsLocked(selection) {
		if p.channelSupportsLocked(account, channel, selection) {
			return true
		}
	}
	return false
}

// accountChannelCooldownLocked 返回账户全部支持通道都冷却时最早恢复的冷却
func (p *AccountPool) accountChannelCooldownLocked(account *Account, selection AccountSelection, now time.Time) (CooldownState, bool) {
	scope := selectionAccessScope(selection)
	var earliest CooldownState
	for _, channel := range p.selectionChannelsLocked(selection) {
		if !p.channelSupportsLocked(account, channel, selection) {
			continue
		}
		cooldown, active := selectionCooldown(account, ChannelCooldownScope(channel, scope), selection, now)
		if !active {
			return CooldownState{}, false
		}
		if earliest.Until.IsZero() || cooldown.Until.Before(earliest.Until) {
			earliest = cooldown
		}
	}
	return earliest, !earliest.Until.IsZero()
}

// channelCandidatesLocked 按 indices 的账户顺序与通道顺序展开候选，轮询策略改按账户 ID 排序并从上次选中组合之后开始
func (p *AccountPool) channelCandidatesLocked(indices []int, selection AccountSelection) []channelCandidate {
	channels := p.selectionChannelsLocked(selection)
	candidates := make([]channelCandidate, 0, len(indices)*len(channels))
	for _, index := range indices {
		for _, channel := range channels {
			candidates = append(candidates, channelCandidate{index: index, channel: channel})
		}
	}
	if p.routingStrategy != "round-robin" || len(indices) <= 1 && len(channels) <= 1 {
		return candidates
	}
	rank := func(channel Channel) int { return slices.Index(channels, channel) }
	sort.SliceStable(candidates, func(left, right int) bool {
		leftID, rightID := p.accounts[candidates[left].index].ID, p.accounts[candidates[right].index].ID
		if leftID != rightID {
			return leftID < rightID
		}
		return rank(candidates[left].channel) < rank(candidates[right].channel)
	})
	key := selectionAccessScope(selection)
	lastAccount := p.lastPicked[key]
	lastChannel := p.lastPickedChannel[key]
	start := sort.Search(len(candidates), func(position int) bool {
		account := p.accounts[candidates[position].index].ID
		if account != lastAccount {
			return account > lastAccount
		}
		return lastChannel != "" && rank(candidates[position].channel) > rank(lastChannel)
	})
	return append(candidates[start:], candidates[:start]...)
}

// AssistantModel 判断模型是否为经 Build 写代码助手生成的 -build 模型
func (p *AccountPool) AssistantModel(modelID string) bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.assistantModelLocked(modelID)
}

// assistantModelLocked 判断模型是否带 assistant_route 能力，调用方持有 p.mu
func (p *AccountPool) assistantModelLocked(modelID string) bool {
	return p.modelCapabilityLocked(modelID, "assistant_route")
}

// assistantBusyLocked 判断账户正在为 -build 选择运行另一个写代码助手生成，同一账户同时只运行一个
func (p *AccountPool) assistantBusyLocked(account *Account, selection AccountSelection) bool {
	return account.assistantBusy && p.assistantModelLocked(selection.ModelID)
}

// InteractionAgentModel 判断模型是否为经 CreateInteraction 后台任务生成的 agent，如 Deep Research 与 Antigravity
func (p *AccountPool) InteractionAgentModel(modelID string) bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.modelCapabilityLocked(modelID, "interaction_task")
}

// modelCapabilityLocked 返回目录中首个同 ID 模型的能力标记
func (p *AccountPool) modelCapabilityLocked(modelID string, capability string) bool {
	modelID = strings.TrimPrefix(strings.TrimSpace(modelID), "models/")
	if modelID == "" {
		return false
	}
	for _, account := range p.accounts {
		for _, model := range account.Models {
			if model.ID == modelID {
				return model.Capabilities[capability]
			}
		}
	}
	return false
}

// buildSupportsModelLocked 判断账户 Build 目录可经生成请求调用模型，anyTier 为 true 时不检查账户权益
func (p *AccountPool) buildSupportsModelLocked(account *Account, modelID string, anyTier bool) bool {
	modelID = strings.TrimPrefix(strings.TrimSpace(modelID), "models/")
	found := false
	for _, model := range account.buildModels {
		if model.ID == modelID && hasMethod(model, "generateContent") {
			found = true
			break
		}
	}
	if !found {
		return false
	}
	for _, candidate := range p.accounts {
		for _, model := range candidate.Models {
			if modelMatchesID(model, modelID) {
				return !buildExcludedPlaygroundModel(model) && (anyTier || modelAllowedByTier(model, account.BenefitTier))
			}
		}
	}
	return !buildRequiresSpecialTool(modelID)
}

// buildExcludedPlaygroundModel 判断 Playground 目录模型是否使用 Build 未接入的专用路由
func buildExcludedPlaygroundModel(model Model) bool {
	return model.Capabilities["interactions_api"] || model.Capabilities["transcription_output"]
}

// buildRequiresSpecialTool 判断 Build 独有模型是否只能配合 Computer Use 等专用工具调用
func buildRequiresSpecialTool(modelID string) bool {
	return strings.Contains(modelID, "computer-use")
}

// buildCatalogHasMethod 判断账户 Build 目录的模型提供方法
func buildCatalogHasMethod(account *Account, modelID string, method string) bool {
	modelID = strings.TrimPrefix(strings.TrimSpace(modelID), "models/")
	return slices.ContainsFunc(account.buildModels, func(model Model) bool { return model.ID == modelID && hasMethod(model, method) })
}

// buildSupportsMethodLocked 判断账户 Build 目录可经 embedding 或实时方法调用 Playground 目录没有的模型
func (p *AccountPool) buildSupportsMethodLocked(account *Account, modelID string, method string) bool {
	modelID = strings.TrimPrefix(strings.TrimSpace(modelID), "models/")
	if p.hasPlaygroundModelLocked(modelID) {
		return false
	}
	for _, model := range account.buildModels {
		if model.ID == modelID && hasMethod(model, method) {
			return true
		}
	}
	return false
}

// buildPublicMethods 返回 Build 独有 embedding 与实时模型在公开目录中可调用的方法
func buildPublicMethods(model Model) []string {
	var methods []string
	for _, method := range model.Methods {
		if !slices.Contains(buildMethods, method) {
			continue
		}
		if method == "embedContent" {
			methods = append(methods, "batchEmbedContents")
		}
		methods = append(methods, method)
	}
	return methods
}

// buildOnlyModelsLocked 返回启用账户 Build 目录中 Playground 目录没有的可生成、embedding 与实时模型
func (p *AccountPool) buildOnlyModelsLocked() []Model {
	if !p.channelEnabledLocked(ChannelBuild) {
		return nil
	}
	var models []Model
	seen := make(map[string]struct{})
	for _, account := range p.accounts {
		if !account.Config.Enabled {
			continue
		}
		for _, model := range account.buildModels {
			if _, exists := seen[model.ID]; exists || p.hasPlaygroundModelLocked(model.ID) {
				continue
			}
			listed := cloneModels([]Model{model})[0]
			if !hasMethod(model, "generateContent") {
				listed.Methods = buildPublicMethods(model)
			} else if !p.buildSupportsModelLocked(account, model.ID, false) {
				continue
			}
			if len(listed.Methods) == 0 {
				continue
			}
			seen[model.ID] = struct{}{}
			models = append(models, listed)
		}
	}
	return models
}

func (p *AccountPool) hasPlaygroundModelLocked(modelID string) bool {
	for _, account := range p.accounts {
		for _, model := range account.Models {
			if modelMatchesID(model, modelID) {
				return true
			}
		}
	}
	return false
}

// BidiMethod 返回模型的实时方法：Build 目录以 bidiGenerateMusic 提供的模型为实时音乐，其余为 bidiGenerateContent
func (p *AccountPool) BidiMethod(modelID string) string {
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.hasBuildModelLocked(strings.TrimPrefix(strings.TrimSpace(modelID), "models/"), "bidiGenerateMusic") {
		return "bidiGenerateMusic"
	}
	return "bidiGenerateContent"
}

// OutputContinuationRounds 返回请求按官网自动续写需要的轮数，不需要续写时为 1
func (p *AccountPool) OutputContinuationRounds(modelID string, maxOutputTokens *int64) int {
	if maxOutputTokens != nil && *maxOutputTokens <= continuationRoundTokens {
		return 1
	}
	modelID = strings.TrimPrefix(strings.TrimSpace(modelID), "models/")
	p.mu.Lock()
	defer p.mu.Unlock()
	for _, account := range p.accounts {
		for _, model := range account.Models {
			if modelMatchesID(model, modelID) && model.Capabilities["output_continuation"] {
				total := max(model.InputTokenLimit, continuationRoundTokens)
				if maxOutputTokens != nil {
					total = min(*maxOutputTokens, total)
				}
				return max(1, int((total+continuationRoundTokens-1)/continuationRoundTokens))
			}
		}
	}
	return 1
}

func (p *AccountPool) hasBuildModelLocked(modelID string, method string) bool {
	if !p.channelEnabledLocked(ChannelBuild) {
		return false
	}
	for _, account := range p.accounts {
		for _, model := range account.buildModels {
			if model.ID != modelID || method != "" && !hasMethod(model, method) {
				continue
			}
			if hasMethod(model, "generateContent") && p.buildSupportsModelLocked(account, modelID, false) {
				return true
			}
			for _, served := range buildMethods {
				if (method == "" || method == served) && p.buildSupportsMethodLocked(account, modelID, served) {
					return true
				}
			}
		}
	}
	return false
}

// modelChannelsLocked 返回至少一个启用账户可以调用模型的通道，anyTier 为 true 时不检查账户权益
func (p *AccountPool) modelChannelsLocked(model Model, anyTier bool) []string {
	selection := AccountSelection{ModelID: model.ID, anyTier: anyTier}
	if hasMethod(model, "generateContent") {
		selection.Method = "generateContent"
	} else if index := slices.IndexFunc(buildMethods, func(method string) bool { return hasMethod(model, method) }); index >= 0 {
		selection.Method = buildMethods[index]
	}
	var channels []string
	for _, channel := range p.selectionChannelsLocked(selection) {
		for _, account := range p.accounts {
			if account.Config.Enabled && p.channelSupportsLocked(account, channel, selection) {
				channels = append(channels, string(channel))
				break
			}
		}
	}
	return channels
}

// AccountChannelAvailable 返回账户是否还有支持选择且未冷却的通道
func (p *AccountPool) AccountChannelAvailable(accountID string, selection AccountSelection) bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	account := p.byID[accountID]
	if account == nil || !account.Config.Enabled || !p.accountSupportsAnyChannelLocked(account, selection) {
		return false
	}
	_, cooling := p.accountChannelCooldownLocked(account, selection, time.Now())
	return !cooling
}
