package api

import (
	"cmp"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"mime"
	"net/http"
	"strconv"
	"strings"

	"github.com/Mag1cFall/AIStudio2API/internal/aistudio"
)

type geminiVideoRequest struct {
	Instances []struct {
		Prompt               string                      `json:"prompt"`
		Image                *geminiVideoImageInput      `json:"image"`
		LastFrame            *geminiVideoImageInput      `json:"lastFrame"`
		LastFrameSnake       *geminiVideoImageInput      `json:"last_frame"`
		ReferenceImages      []geminiVideoReferenceImage `json:"referenceImages"`
		ReferenceImagesSnake []geminiVideoReferenceImage `json:"reference_images"`
	} `json:"instances"`
	Parameters struct {
		NumberOfVideos      int             `json:"numberOfVideos"`
		SampleCount         int             `json:"sampleCount"`
		AspectRatio         string          `json:"aspectRatio"`
		Duration            json.RawMessage `json:"durationSeconds"`
		Resolution          string          `json:"resolution"`
		NegativePrompt      string          `json:"negativePrompt"`
		NegativePromptSnake string          `json:"negative_prompt"`
	} `json:"parameters"`
}

// geminiVideoImageInput 是视频帧图片，接受 Gemini API 的 bytesBase64Encoded 与 Part 形式的 inlineData、fileData
type geminiVideoImageInput struct {
	Bytes           string                 `json:"bytesBase64Encoded"`
	BytesSnake      string                 `json:"bytes_base64_encoded"`
	MIMEType        string                 `json:"mimeType"`
	MIMETypeSnake   string                 `json:"mime_type"`
	InlineData      *geminiVideoInlineData `json:"inlineData"`
	InlineDataSnake *geminiVideoInlineData `json:"inline_data"`
	FileData        *geminiVideoFileData   `json:"fileData"`
	FileDataSnake   *geminiVideoFileData   `json:"file_data"`
}

// geminiVideoReferenceImage 是视频参考图
type geminiVideoReferenceImage struct {
	Image *geminiVideoImageInput `json:"image"`
}

type geminiVideoInlineData struct {
	MIMEType      string `json:"mimeType"`
	MIMETypeSnake string `json:"mime_type"`
	Data          string `json:"data"`
}

type geminiVideoFileData struct {
	MIMEType      string `json:"mimeType"`
	MIMETypeSnake string `json:"mime_type"`
	FileURI       string `json:"fileUri"`
	FileURISnake  string `json:"file_uri"`
}

type openAIVideoRequest struct {
	Model          string `json:"model"`
	Prompt         string `json:"prompt"`
	Seconds        string `json:"seconds"`
	Size           string `json:"size"`
	InputReference string `json:"input_reference"`
}

func (s *server) handleGeminiVideoCreate(w http.ResponseWriter, r *http.Request, model string) {
	service, ok := s.service.(aistudio.VideoService)
	if !ok {
		writeGeminiError(w, http.StatusBadRequest, "INVALID_ARGUMENT", "video generation is unavailable")
		return
	}
	var request geminiVideoRequest
	if err := decodeJSON(r, &request); err != nil {
		writeGeminiError(w, http.StatusBadRequest, "INVALID_ARGUMENT", err.Error())
		return
	}
	videoRequests, count, err := request.toVideoRequests(model)
	if err != nil {
		writeGeminiError(w, http.StatusBadRequest, "INVALID_ARGUMENT", err.Error())
		return
	}
	ids := make([]string, 0, count*len(videoRequests))
create:
	for _, videoRequest := range videoRequests {
		videoRequest = normalizeVideoDefaults(videoRequest)
		for range count {
			operation, createErr := service.GenerateVideo(r.Context(), videoRequest)
			if createErr != nil {
				err = createErr
				break create
			}
			ids = append(ids, operation.ID)
		}
	}
	if len(ids) == 0 {
		if shouldWriteRequestError(r, err) {
			writeGeminiRequestError(w, err)
		}
		return
	}
	writeJSON(w, http.StatusOK, officialOrder("gemini", map[string]any{"name": "operations/" + strings.Join(ids, videoOperationSeparator)}))
}

// maxVideoCount 是 Gemini numberOfVideos 与 sampleCount 的上限
const maxVideoCount = 4

// videoOperationSeparator 连接同一 Gemini 操作内各上游视频任务的 ID
const videoOperationSeparator = "~"

// toVideoRequests 返回每个 instance 的上游视频任务请求与每个 instance 要创建的任务数
func (request geminiVideoRequest) toVideoRequests(model string) ([]aistudio.VideoRequest, int, error) {
	if len(request.Instances) == 0 {
		return nil, 0, fmt.Errorf("instances is required")
	}
	count := request.Parameters.NumberOfVideos
	if count == 0 {
		count = request.Parameters.SampleCount
	}
	if count == 0 {
		count = 1
	}
	if count < 1 || count > maxVideoCount {
		return nil, 0, fmt.Errorf("numberOfVideos must be between 1 and %d", maxVideoCount)
	}
	duration, err := videoDuration(request.Parameters.Duration)
	if err != nil {
		return nil, 0, err
	}
	negative := request.Parameters.NegativePrompt
	if negative == "" {
		negative = request.Parameters.NegativePromptSnake
	}
	results := make([]aistudio.VideoRequest, 0, len(request.Instances))
	for index, instance := range request.Instances {
		result := aistudio.VideoRequest{
			Model: model, Prompt: instance.Prompt, NegativePrompt: negative,
			AspectRatio: request.Parameters.AspectRatio, DurationSeconds: duration, Resolution: request.Parameters.Resolution,
		}
		if instance.Image != nil {
			if result.StartImage, err = geminiVideoImage(instance.Image); err != nil {
				return nil, 0, fmt.Errorf("instances[%d].image: %w", index, err)
			}
		}
		last := instance.LastFrame
		if last == nil {
			last = instance.LastFrameSnake
		}
		if last != nil {
			if result.LastImage, err = geminiVideoImage(last); err != nil {
				return nil, 0, fmt.Errorf("instances[%d].lastFrame: %w", index, err)
			}
		}
		references := instance.ReferenceImages
		if references == nil {
			references = instance.ReferenceImagesSnake
		}
		for reference, item := range references {
			if item.Image == nil {
				return nil, 0, fmt.Errorf("instances[%d].referenceImages[%d].image is required", index, reference)
			}
			image, err := geminiVideoImage(item.Image)
			if err != nil {
				return nil, 0, fmt.Errorf("instances[%d].referenceImages[%d].image: %w", index, reference, err)
			}
			result.ReferenceImages = append(result.ReferenceImages, image)
		}
		if strings.TrimSpace(result.Prompt) == "" && result.StartImage == nil && result.LastImage == nil && len(result.ReferenceImages) == 0 {
			return nil, 0, fmt.Errorf("instances[%d] must contain a prompt or an image", index)
		}
		results = append(results, result)
	}
	return results, count, nil
}

func geminiVideoImage(input *geminiVideoImageInput) (*aistudio.VideoImage, error) {
	inline := input.InlineData
	if inline == nil {
		inline = input.InlineDataSnake
	}
	if bytes := cmp.Or(input.Bytes, input.BytesSnake); bytes != "" {
		if inline != nil {
			return nil, fmt.Errorf("image must contain exactly one of bytesBase64Encoded, inlineData or fileData")
		}
		inline = &geminiVideoInlineData{MIMEType: cmp.Or(input.MIMEType, input.MIMETypeSnake), Data: bytes}
	}
	file := input.FileData
	if file == nil {
		file = input.FileDataSnake
	}
	if inline != nil && file != nil {
		return nil, fmt.Errorf("image must contain exactly one of bytesBase64Encoded, inlineData or fileData")
	}
	if inline != nil {
		mimeType := cmp.Or(inline.MIMEType, inline.MIMETypeSnake)
		if mimeType == "" || inline.Data == "" {
			return nil, fmt.Errorf("image requires mimeType and data")
		}
		data, err := decodeBase64Flexible(inline.Data)
		if err != nil {
			return nil, fmt.Errorf("image.inlineData.data: %w", err)
		}
		mimeType, data = normalizeImagePayload(mimeType, data)
		return &aistudio.VideoImage{InlineData: &aistudio.Blob{MIME: mimeType, Data: data}}, nil
	}
	if file != nil {
		return &aistudio.VideoImage{File: &aistudio.FileRef{ID: cmp.Or(file.FileURI, file.FileURISnake), MIME: cmp.Or(file.MIMEType, file.MIMETypeSnake)}}, nil
	}
	return nil, fmt.Errorf("image requires bytesBase64Encoded, inlineData or fileData")
}

func videoDuration(raw json.RawMessage) (int, error) {
	if !rawJSONConfigured(raw) {
		return 0, nil
	}
	var value string
	if err := json.Unmarshal(raw, &value); err == nil {
		duration, err := strconv.Atoi(value)
		if err != nil {
			return 0, fmt.Errorf("durationSeconds must be an integer")
		}
		return duration, nil
	}
	var duration int
	if err := json.Unmarshal(raw, &duration); err != nil {
		return 0, fmt.Errorf("durationSeconds must be an integer")
	}
	return duration, nil
}

func (s *server) handleGeminiVideoOperation(w http.ResponseWriter, r *http.Request) {
	service, ok := s.service.(aistudio.VideoService)
	if !ok {
		writeGeminiError(w, http.StatusBadRequest, "INVALID_ARGUMENT", "video generation is unavailable")
		return
	}
	operationID := cleanOperationID(r.PathValue("operation"))
	done := true
	samples := []any{}
	var failure error
	missing := ""
	for _, id := range strings.Split(operationID, videoOperationSeparator) {
		operation, err := service.GetGenerateVideoOperation(r.Context(), id)
		if errors.Is(err, aistudio.ErrResourceNotFound) {
			writeGeminiError(w, http.StatusNotFound, "NOT_FOUND", "Requested entity was not found.")
			return
		}
		if err != nil {
			if shouldWriteRequestError(r, err) {
				writeGeminiRequestError(w, err)
			}
			return
		}
		done = done && operation.Done
		failure = cmp.Or(failure, operation.Failure)
		missing = cmp.Or(missing, operation.Missing)
		if operation.Done && operation.File != nil {
			samples = append(samples, map[string]any{"video": map[string]any{
				"uri": geminiVideoURI(r, operation.File.ID), "mimeType": "video/mp4",
			}})
		}
	}
	response := map[string]any{"name": "operations/" + operationID, "done": done}
	if done && failure != nil {
		status := geminiErrorStatus(failure)
		response["error"] = map[string]any{"code": rpcCodes[status], "message": failure.Error(), "status": status}
	} else if done && missing != "" {
		response["error"] = map[string]any{"code": rpcCodes["NOT_FOUND"], "message": missing, "status": "NOT_FOUND"}
	} else if done {
		response["response"] = map[string]any{
			"@type":                 "type.googleapis.com/google.ai.generativelanguage.v1beta.PredictLongRunningResponse",
			"generateVideoResponse": map[string]any{"generatedSamples": samples},
		}
	}
	writeJSON(w, http.StatusOK, officialOrder("gemini", response))
}

func (s *server) handleOpenAIVideoCreate(w http.ResponseWriter, r *http.Request) {
	service, ok := s.service.(aistudio.VideoService)
	if !ok {
		writeOpenAIError(w, http.StatusBadRequest, "invalid_request", "video generation is unavailable")
		return
	}
	request, image, err := parseOpenAIVideoRequest(r)
	if err != nil {
		writeOpenAIError(w, http.StatusBadRequest, "invalid_request", err.Error())
		return
	}
	if strings.TrimSpace(request.Model) == "" {
		models, err := s.service.Models(r.Context())
		if err != nil {
			if shouldWriteRequestError(r, err) {
				writeOpenAIRequestError(w, err)
			}
			return
		}
		request.Model = defaultCatalogModel(models, aistudio.IsVideoModel)
	}
	videoRequest, err := request.toVideoRequest(image)
	if err != nil {
		writeOpenAIError(w, http.StatusBadRequest, "invalid_request", err.Error())
		return
	}
	videoRequest = normalizeVideoDefaults(videoRequest)
	operation, err := service.GenerateVideo(r.Context(), videoRequest)
	if err != nil {
		if shouldWriteRequestError(r, err) {
			writeOpenAIRequestError(w, err)
		}
		return
	}
	writeJSON(w, http.StatusOK, officialOrder("openai", openAIVideoObject(operation)))
}

func parseOpenAIVideoRequest(r *http.Request) (openAIVideoRequest, *aistudio.VideoImage, error) {
	mediaType, _, err := mime.ParseMediaType(r.Header.Get("Content-Type"))
	if err != nil {
		return openAIVideoRequest{}, nil, fmt.Errorf("invalid Content-Type")
	}
	var request openAIVideoRequest
	var image *aistudio.VideoImage
	switch mediaType {
	case "application/json":
		if err := decodeJSON(r, &request); err != nil {
			return request, nil, err
		}
		if request.InputReference != "" {
			part, err := fileOrInlinePart(request.InputReference, "")
			if err != nil {
				return request, nil, err
			}
			image = &aistudio.VideoImage{InlineData: part.InlineData, File: part.File}
		}
	case "multipart/form-data":
		if err := r.ParseMultipartForm(32 << 20); err != nil {
			return request, nil, err
		}
		defer r.MultipartForm.RemoveAll()
		request.Model = r.FormValue("model")
		request.Prompt = r.FormValue("prompt")
		request.Seconds = r.FormValue("seconds")
		request.Size = r.FormValue("size")
		file, header, err := r.FormFile("input_reference")
		if err == nil {
			defer file.Close()
			data, readErr := io.ReadAll(file)
			if readErr != nil {
				return request, nil, readErr
			}
			mimeType := declaredMediaType(header.Header.Get("Content-Type"))
			if mimeType == "" {
				mimeType = http.DetectContentType(data)
			}
			mimeType, data = normalizeImagePayload(mimeType, data)
			image = &aistudio.VideoImage{InlineData: &aistudio.Blob{MIME: mimeType, Data: data}}
		} else if err != http.ErrMissingFile {
			return request, nil, err
		}
	default:
		return request, nil, fmt.Errorf("Content-Type must be application/json or multipart/form-data")
	}
	return request, image, nil
}

func (request openAIVideoRequest) toVideoRequest(image *aistudio.VideoImage) (aistudio.VideoRequest, error) {
	if strings.TrimSpace(request.Prompt) == "" && image == nil {
		return aistudio.VideoRequest{}, fmt.Errorf("prompt or input_reference is required")
	}
	if strings.TrimSpace(request.Model) == "" {
		return aistudio.VideoRequest{}, fmt.Errorf("model is required")
	}
	duration := 0
	if request.Seconds != "" {
		var err error
		duration, err = strconv.Atoi(request.Seconds)
		if err != nil {
			return aistudio.VideoRequest{}, fmt.Errorf("seconds must be an integer")
		}
	}
	aspectRatio, resolution, err := openAIVideoSize(request.Size)
	if err != nil {
		return aistudio.VideoRequest{}, err
	}
	return aistudio.VideoRequest{
		Model: request.Model, Prompt: request.Prompt, DurationSeconds: duration,
		AspectRatio: aspectRatio, Resolution: resolution, StartImage: image,
	}, nil
}

func openAIVideoSize(size string) (string, string, error) {
	switch strings.ToLower(strings.TrimSpace(size)) {
	case "", "720x1280":
		return "9:16", "720p", nil
	case "1280x720":
		return "16:9", "720p", nil
	case "1792x1024", "1920x1080":
		return "16:9", "1080p", nil
	case "1024x1792", "1080x1920":
		return "9:16", "1080p", nil
	case "3840x2160":
		return "16:9", "4k", nil
	case "2160x3840":
		return "9:16", "4k", nil
	default:
		return "", "", fmt.Errorf("unsupported size %q", size)
	}
}

func (s *server) handleOpenAIVideoGet(w http.ResponseWriter, r *http.Request) {
	service, ok := s.service.(aistudio.VideoService)
	if !ok {
		writeOpenAIError(w, http.StatusBadRequest, "invalid_request", "video generation is unavailable")
		return
	}
	operationID := cleanOperationID(r.PathValue("video"))
	operation, err := service.GetGenerateVideoOperation(r.Context(), operationID)
	if err != nil {
		writeOpenAIVideoError(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, officialOrder("openai", openAIVideoObject(operation)))
}

// handleOpenAIVideoList 按 after、limit 与 order 分页列出视频，页内各对象经上游轮询返回当前状态
func (s *server) handleOpenAIVideoList(w http.ResponseWriter, r *http.Request) {
	service, ok := s.service.(aistudio.VideoService)
	if !ok {
		writeOpenAIError(w, http.StatusBadRequest, "invalid_request", "video listing is unavailable")
		return
	}
	operations, err := service.ListVideos(r.Context())
	if err != nil {
		writeOpenAIVideoError(w, r, err)
		return
	}
	page, hasMore, err := openAIListPage(r.URL.Query(), operations, func(operation aistudio.VideoOperation) string { return operation.ID }, listLimits{fallback: 20, min: 0, max: 100})
	if err != nil {
		writeOpenAIError(w, http.StatusBadRequest, "invalid_request", err.Error())
		return
	}
	data := make([]map[string]any, 0, len(page))
	for _, operation := range page {
		polled, err := service.GetGenerateVideoOperation(r.Context(), operation.ID)
		if err != nil {
			writeOpenAIVideoError(w, r, err)
			return
		}
		data = append(data, openAIVideoObject(polled))
	}
	body := map[string]any{"object": "list", "data": data, "first_id": nil, "last_id": nil, "has_more": hasMore}
	if len(page) > 0 {
		body["first_id"], body["last_id"] = page[0].ID, page[len(page)-1].ID
	}
	writeJSON(w, http.StatusOK, officialOrder("openai", body))
}

// handleOpenAIVideoDelete 删除已结束的视频任务及其结果文件
func (s *server) handleOpenAIVideoDelete(w http.ResponseWriter, r *http.Request) {
	service, ok := s.service.(aistudio.VideoService)
	if !ok {
		writeOpenAIError(w, http.StatusBadRequest, "invalid_request", "video deletion is unavailable")
		return
	}
	operationID := cleanOperationID(r.PathValue("video"))
	if err := service.DeleteVideo(r.Context(), operationID); err != nil {
		writeOpenAIVideoError(w, r, err)
		return
	}
	writeJSON(w, http.StatusOK, officialOrder("openai", map[string]any{"id": operationID, "object": "video.deleted", "deleted": true}))
}

// writeOpenAIVideoError 写入视频接口错误，视频任务不存在时返回 404
func writeOpenAIVideoError(w http.ResponseWriter, r *http.Request, err error) {
	if !shouldWriteRequestError(r, err) {
		return
	}
	if errors.Is(err, aistudio.ErrResourceNotFound) {
		writeOpenAIError(w, http.StatusNotFound, "video_not_found", "video not found")
		return
	}
	writeOpenAIRequestError(w, err)
}

func openAIVideoObject(operation aistudio.VideoOperation) map[string]any {
	status := "queued"
	progress := 0
	if operation.Done {
		progress = 100
		if operation.File != nil {
			status = "completed"
		} else {
			status = "failed"
		}
	}
	object := map[string]any{
		"id": operation.ID, "object": "video", "model": operation.Model,
		"status": status, "progress": progress, "created_at": operation.CreatedAt.Unix(),
		"size": operation.Size, "seconds": operation.Seconds, "prompt": nil,
		"completed_at": nil, "expires_at": nil, "error": nil, "remixed_from_video_id": nil,
	}
	if operation.Prompt != "" {
		object["prompt"] = operation.Prompt
	}
	if operation.CompletedAt != 0 {
		object["completed_at"] = operation.CompletedAt
	}
	if operation.ExpiresAt != 0 {
		object["expires_at"] = operation.ExpiresAt
	}
	if operation.Missing != "" {
		object["error"] = map[string]any{"code": "video_not_found", "message": operation.Missing}
	}
	if operation.Failure != nil {
		object["error"] = map[string]any{"code": "video_generation_failed", "message": operation.Failure.Error()}
	}
	return object
}

func (s *server) handleOpenAIVideoContent(w http.ResponseWriter, r *http.Request) {
	service, ok := s.service.(aistudio.VideoService)
	if !ok {
		writeOpenAIError(w, http.StatusBadRequest, "invalid_request", "video generation is unavailable")
		return
	}
	if variant := r.URL.Query().Get("variant"); variant != "" && variant != "video" {
		writeOpenAIError(w, http.StatusBadRequest, "invalid_request", "only the video variant is available")
		return
	}
	operationID := cleanOperationID(r.PathValue("video"))
	operation, err := service.GetGenerateVideoOperation(r.Context(), operationID)
	if err != nil {
		writeOpenAIVideoError(w, r, err)
		return
	}
	if !operation.Done || operation.File == nil {
		writeOpenAIError(w, http.StatusConflict, "video_not_ready", "video is not ready")
		return
	}
	media, err := service.DownloadFile(r.Context(), operation.File.ID)
	if err != nil {
		writeOpenAIVideoError(w, r, err)
		return
	}
	w.Header().Set("Content-Type", cmp.Or(media.MIME, "video/mp4"))
	w.Header().Set("Content-Disposition", `attachment; filename="video.mp4"`)
	writeMediaStream(w, r, media.Body, media.Size)
}

// rpcCodes 是 google.rpc.Code 名称对应的数值，用于长任务 Operation.error.code
var rpcCodes = map[string]int{
	"OK": 0, "CANCELLED": 1, "UNKNOWN": 2, "INVALID_ARGUMENT": 3, "DEADLINE_EXCEEDED": 4, "NOT_FOUND": 5,
	"ALREADY_EXISTS": 6, "PERMISSION_DENIED": 7, "RESOURCE_EXHAUSTED": 8, "FAILED_PRECONDITION": 9, "ABORTED": 10,
	"OUT_OF_RANGE": 11, "UNIMPLEMENTED": 12, "INTERNAL": 13, "UNAVAILABLE": 14, "DATA_LOSS": 15, "UNAUTHENTICATED": 16,
}

func cleanOperationID(value string) string {
	return strings.TrimPrefix(strings.TrimSpace(value), "operations/")
}

// geminiVideoURI 返回视频结果的 Files API 下载地址
func geminiVideoURI(r *http.Request, driveID string) string {
	return requestOrigin(r) + "/v1beta/files/" + geminiFileID(driveID) + ":download?alt=media"
}

func normalizeVideoDefaults(request aistudio.VideoRequest) aistudio.VideoRequest {
	if request.DurationSeconds == 0 {
		request.DurationSeconds = 4
	}
	if request.AspectRatio == "" {
		request.AspectRatio = "16:9"
	}
	if request.Resolution == "" {
		request.Resolution = "720p"
	}
	return request
}
