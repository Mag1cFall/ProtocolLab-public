package api

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"net/http"
	"slices"
	"strconv"
	"strings"
	"time"

	"github.com/Mag1cFall/AIStudio2API/internal/aistudio"
)

type httpStatusError interface {
	HTTPStatus() int
}

type errorCodeProvider interface {
	ErrorCode() string
}

// decodeJSON 把请求正文解码为一个 JSON 值；读取或解码失败时以同一正文与读取错误逐段解码，返回其错误
func decodeJSON(r *http.Request, target any) error {
	body, readErr := io.ReadAll(r.Body)
	if readErr == nil && json.Unmarshal(body, target) == nil {
		return nil
	}
	reader := io.Reader(bytes.NewReader(body))
	if readErr != nil {
		reader = io.MultiReader(reader, errorReader{readErr})
	}
	decoder := json.NewDecoder(reader)
	if err := decoder.Decode(target); err != nil {
		return err
	}
	var trailing any
	if err := decoder.Decode(&trailing); !errors.Is(err, io.EOF) {
		return fmt.Errorf("request body must contain one JSON value")
	}
	return nil
}

// errorReader 每次读取都返回同一个错误
type errorReader struct{ err error }

func (reader errorReader) Read([]byte) (int, error) { return 0, reader.err }

func writeJSON(w http.ResponseWriter, status int, payload any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(payload)
}

// streamHeaders 写入并刷新流式响应头
func streamHeaders(w http.ResponseWriter) error {
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-cache")
	w.Header().Set("Connection", "keep-alive")
	w.Header().Set("X-Accel-Buffering", "no")
	w.WriteHeader(http.StatusOK)
	return http.NewResponseController(w).Flush()
}

// writeSSE 写入具名事件并传播缓冲刷新错误
func writeSSE(w http.ResponseWriter, event string, payload any) error {
	data, err := json.Marshal(payload)
	if err != nil {
		return err
	}
	frame := make([]byte, 0, len(event)+len(data)+16)
	if event != "" {
		frame = append(append(append(frame, "event: "...), event...), '\n')
	}
	frame = append(append(append(frame, "data: "...), data...), "\n\n"...)
	if _, err := w.Write(frame); err != nil {
		return err
	}
	return http.NewResponseController(w).Flush()
}

// writeSSEText 写入文本事件并刷新网络缓冲
func writeSSEText(w http.ResponseWriter, data string) error {
	if _, err := fmt.Fprintf(w, "data: %s\n\n", data); err != nil {
		return err
	}
	return http.NewResponseController(w).Flush()
}

func statusFromError(err error) int {
	if errors.Is(err, context.Canceled) {
		return http.StatusServiceUnavailable
	}
	if errors.Is(err, context.DeadlineExceeded) {
		return http.StatusGatewayTimeout
	}
	var notReady *aistudio.AccountsNotReadyError
	if errors.As(err, &notReady) {
		return http.StatusServiceUnavailable
	}
	if errors.Is(err, aistudio.ErrNoEligibleAccount) || errors.Is(err, aistudio.ErrInvalidArgument) {
		return http.StatusBadRequest
	}
	if errors.Is(err, aistudio.ErrModelNotFound) {
		return http.StatusNotFound
	}
	if isUnverifiedProtocolError(err) {
		return http.StatusBadRequest
	}
	var rpcError *aistudio.RPCError
	if errors.As(err, &rpcError) && rpcError.StatusCode == http.StatusNotFound {
		return http.StatusBadGateway
	}
	var statusErr httpStatusError
	if errors.As(err, &statusErr) {
		return validHTTPStatus(statusErr.HTTPStatus())
	}
	return http.StatusBadGateway
}

// shouldWriteRequestError 判断仍在线的客户端是否需要收到结构化错误
func shouldWriteRequestError(r *http.Request, err error) bool {
	return err != nil && (!errors.Is(err, context.Canceled) || r.Context().Err() == nil)
}

func isUnverifiedProtocolError(err error) bool {
	var unverified *aistudio.UnverifiedProtocolError
	return errors.As(err, &unverified)
}

func validHTTPStatus(status int) int {
	if status >= 400 && status <= 599 {
		return status
	}
	return http.StatusBadGateway
}

func codeFromError(err error, defaultCode string) string {
	var codeErr errorCodeProvider
	if errors.As(err, &codeErr) && codeErr.ErrorCode() != "" {
		return codeErr.ErrorCode()
	}
	return defaultCode
}

// requestProtocol 返回请求路径与请求头所属的公开协议：gemini、anthropic 或 openai
func requestProtocol(r *http.Request) string {
	switch {
	case strings.HasPrefix(r.URL.Path, "/v1beta/"), strings.HasPrefix(r.URL.Path, "/upload/"), interactionsPath(r.URL.Path):
		return "gemini"
	case strings.HasPrefix(r.URL.Path, "/v1/messages"), r.Header.Get("Anthropic-Version") != "":
		return "anthropic"
	}
	return "openai"
}

// writeAuthError 按请求所属协议写入 API key 错误，OpenAI 与 Anthropic 为 401
func writeAuthError(w http.ResponseWriter, r *http.Request) {
	switch requestProtocol(r) {
	case "gemini":
		writeGeminiAuthError(w, r)
	case "anthropic":
		writeAnthropicError(w, http.StatusUnauthorized, "authentication_error", "Invalid API Key")
	default:
		writeOpenAIError(w, http.StatusUnauthorized, "invalid_api_key", "Invalid API Key")
	}
}

// writeRouteNotFound 以请求所属协议的错误体返回 404，消息含请求的方法与路径
func writeRouteNotFound(w http.ResponseWriter, r *http.Request) {
	message := fmt.Sprintf("Invalid URL (%s %s)", r.Method, r.URL.Path)
	switch requestProtocol(r) {
	case "gemini":
		writeGeminiError(w, http.StatusNotFound, "NOT_FOUND", message)
	case "anthropic":
		writeAnthropicError(w, http.StatusNotFound, "not_found_error", message)
	default:
		writeOpenAIError(w, http.StatusNotFound, "not_found", message)
	}
}

// geminiInvalidKeyMessage 是 Gemini API 对无效 API key 的错误信息
const geminiInvalidKeyMessage = "API key not valid. Please pass a valid API key."

// geminiAuthFailure 是 Gemini API 认证错误的 error 对象
type geminiAuthFailure struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	Status  string `json:"status"`
	Details []any  `json:"details,omitempty"`
}

// geminiErrorInfo 是 Gemini 错误 details 中的 google.rpc.ErrorInfo
type geminiErrorInfo struct {
	Type     string            `json:"@type"`
	Reason   string            `json:"reason"`
	Domain   string            `json:"domain"`
	Metadata map[string]string `json:"metadata"`
}

// geminiLocalizedMessage 是 Gemini 错误 details 中的 google.rpc.LocalizedMessage
type geminiLocalizedMessage struct {
	Type    string `json:"@type"`
	Locale  string `json:"locale"`
	Message string `json:"message"`
}

// writeGeminiAuthError 按 Gemini API 写入 API key 错误：给出的 key 无效时为 400 INVALID_ARGUMENT 带 ErrorInfo 与 LocalizedMessage，没有 key 时为 403 PERMISSION_DENIED；Interactions 与非 SSE 的 streamGenerateContent 外层为数组
func writeGeminiAuthError(w http.ResponseWriter, r *http.Request) {
	failure := geminiAuthFailure{
		Code: http.StatusForbidden, Status: "PERMISSION_DENIED",
		Message: "Method doesn't allow unregistered callers (callers without established identity). Please use API Key or other form of API consumer identity to call this API.",
	}
	if slices.ContainsFunc(apiKeyCandidates(r), func(key string) bool { return key != "" }) {
		failure = geminiAuthFailure{Code: http.StatusBadRequest, Message: geminiInvalidKeyMessage, Status: "INVALID_ARGUMENT", Details: []any{
			geminiErrorInfo{Type: "type.googleapis.com/google.rpc.ErrorInfo", Reason: "API_KEY_INVALID", Domain: "googleapis.com", Metadata: map[string]string{"service": "generativelanguage.googleapis.com"}},
			geminiLocalizedMessage{Type: "type.googleapis.com/google.rpc.LocalizedMessage", Locale: "en-US", Message: geminiInvalidKeyMessage},
		}}
	}
	setAccessLogResponseError(w, failure.Message)
	var payload any = map[string]geminiAuthFailure{"error": failure}
	if interactionsPath(r.URL.Path) || strings.HasSuffix(r.URL.Path, ":streamGenerateContent") && r.URL.Query().Get("alt") != "sse" {
		payload = []any{payload}
	}
	writeJSON(w, failure.Code, payload)
}

// interactionsPath 判断路径是否为 v1 或 v1beta 的 Interactions 资源
func interactionsPath(path string) bool {
	for _, prefix := range []string{"/v1/interactions", "/v1beta/interactions"} {
		if path == prefix || strings.HasPrefix(path, prefix+"/") {
			return true
		}
	}
	return false
}

// serverErrorPrefix 返回 5xx 状态对应的官方英文错误开头，其余状态返回空
func serverErrorPrefix(status int) string {
	switch {
	case status == http.StatusServiceUnavailable:
		return "Service unavailable"
	case status == http.StatusGatewayTimeout:
		return "Request timed out"
	case status == 529:
		return "Overloaded"
	case status >= 500:
		return "Internal server error"
	}
	return ""
}

// publicErrorMessage 在 5xx 错误原因前加官方英文开头
func publicErrorMessage(status int, message string) string {
	if prefix := serverErrorPrefix(status); prefix != "" && !strings.HasPrefix(message, prefix) {
		return prefix + ": " + message
	}
	return message
}

func writeOpenAIError(w http.ResponseWriter, status int, code string, message string) {
	message = publicErrorMessage(status, message)
	setAccessLogResponseError(w, message)
	writeJSON(w, status, map[string]any{"error": openAIErrorBody{Message: message, Type: openAIErrorType(status, code), Code: code}})
}

// openAIErrorBody 是 OpenAI 错误对象，字段顺序与官方相同
type openAIErrorBody struct {
	Message string  `json:"message"`
	Type    string  `json:"type"`
	Param   *string `json:"param"`
	Code    string  `json:"code"`
}

func openAIErrorType(status int, code string) string {
	if status == http.StatusBadRequest || status == http.StatusUnauthorized || status == http.StatusForbidden || status == http.StatusNotFound {
		return "invalid_request_error"
	}
	if code == "rate_limit_exceeded" {
		return "requests"
	}
	return "server_error"
}

func writeAnthropicError(w http.ResponseWriter, status int, errorType string, message string) {
	message = publicErrorMessage(status, message)
	setAccessLogResponseError(w, message)
	writeJSON(w, status, anthropicErrorResponse{Type: "error", Error: anthropicErrorBody{Type: errorType, Message: message}})
}

// anthropicErrorResponse 是 Anthropic 错误响应，字段顺序与官方相同
type anthropicErrorResponse struct {
	Type  string             `json:"type"`
	Error anthropicErrorBody `json:"error"`
}

// anthropicErrorBody 是 Anthropic 错误对象
type anthropicErrorBody struct {
	Type    string `json:"type"`
	Message string `json:"message"`
}

func writeGeminiError(w http.ResponseWriter, status int, statusName string, message string) {
	setAccessLogResponseError(w, message)
	writeJSON(w, status, officialOrder("gemini", map[string]any{"error": map[string]any{
		"code":    status,
		"message": message,
		"status":  statusName,
	}}))
}

// writeOpenAIRequestError 以 OpenAI 错误体写出请求失败，可重试时带 Retry-After 并在消息末尾写明重试时间
func writeOpenAIRequestError(w http.ResponseWriter, err error) {
	seconds := setRetryAfter(w, err)
	writeOpenAIError(w, statusFromError(err), openAIErrorCode(err), retryMessage(err.Error(), seconds))
}

// writeOpenAISSEError 在已开始的 OpenAI 事件流中以 error 数据帧写出请求失败，可重试时在消息末尾写明重试时间
func writeOpenAISSEError(w http.ResponseWriter, err error) {
	status := statusFromError(err)
	code := openAIErrorCode(err)
	_ = writeSSE(w, "", map[string]any{"error": openAIErrorBody{
		Message: retryMessage(publicErrorMessage(status, err.Error()), retryAfterSeconds(err)), Type: openAIErrorType(status, code), Code: code,
	}})
}

// writeAnthropicRequestError 以 Anthropic 错误体写出请求失败，可重试时带 Retry-After 并在消息末尾写明重试时间
func writeAnthropicRequestError(w http.ResponseWriter, err error) {
	seconds := setRetryAfter(w, err)
	writeAnthropicError(w, statusFromError(err), anthropicErrorType(err), retryMessage(anthropicErrorMessage(err), seconds))
}

// retryMessage 在 seconds 大于 0 时于消息末尾按 OpenAI 限流消息的写法另起一句 Please try again in <seconds>s.
func retryMessage(message string, seconds int64) string {
	if seconds <= 0 {
		return message
	}
	if !strings.HasSuffix(message, ".") {
		message += "."
	}
	return message + " Please try again in " + strconv.FormatInt(seconds, 10) + "s."
}

// contextOverflow 判断错误是否为上游的上下文超限
func contextOverflow(err error) bool {
	var rpc *aistudio.RPCError
	return errors.As(err, &rpc) && rpc.ContextOverflow()
}

// anthropicErrorMessage 返回 Anthropic 错误消息，上下文超限时以 prompt is too long 开头
func anthropicErrorMessage(err error) string {
	if contextOverflow(err) {
		return "prompt is too long: " + err.Error()
	}
	return err.Error()
}

// writeGeminiRequestError 以 Gemini 错误体写出请求失败，可重试时带 Retry-After 与 RetryInfo
func writeGeminiRequestError(w http.ResponseWriter, err error) {
	payload := geminiErrorPayload(err, setRetryAfter(w, err))
	setAccessLogResponseError(w, err.Error())
	writeJSON(w, statusFromError(err), officialOrder("gemini", map[string]any{"error": payload}))
}

// geminiErrorPayload 返回 Gemini 错误对象，seconds 大于 0 时 details 带该时长的 RetryInfo
func geminiErrorPayload(err error, seconds int64) map[string]any {
	payload := map[string]any{"code": statusFromError(err), "message": err.Error(), "status": geminiErrorStatus(err)}
	if seconds > 0 {
		payload["details"] = []any{map[string]any{"@type": "type.googleapis.com/google.rpc.RetryInfo", "retryDelay": strconv.FormatInt(seconds, 10) + "s"}}
	}
	return payload
}

// setRetryAfter 在错误给出可重试时刻时写入 Retry-After 秒数并返回它，否则返回 0
func setRetryAfter(w http.ResponseWriter, err error) int64 {
	seconds := retryAfterSeconds(err)
	if seconds > 0 {
		w.Header().Set("Retry-After", strconv.FormatInt(seconds, 10))
	}
	return seconds
}

// retryAfterSeconds 返回错误给出的可重试时刻距现在的秒数，没有可重试时刻时返回 0
func retryAfterSeconds(err error) int64 {
	var retry interface{ RetryAt(time.Time) time.Time }
	if !errors.As(err, &retry) {
		return 0
	}
	now := time.Now()
	at := retry.RetryAt(now)
	if !at.After(now) {
		return 0
	}
	return int64(math.Ceil(at.Sub(now).Seconds()))
}

func writeAdminError(w http.ResponseWriter, status int, code string, message string) {
	writeJSON(w, status, map[string]any{"error": map[string]string{
		"code":    code,
		"message": message,
	}})
}

func openAIErrorCode(err error) string {
	if errors.Is(err, context.Canceled) {
		return "request_canceled"
	}
	if errors.Is(err, aistudio.ErrModelNotFound) {
		return "model_not_found"
	}
	var notReady *aistudio.AccountsNotReadyError
	if errors.As(err, &notReady) {
		return "account_unavailable"
	}
	if errors.Is(err, aistudio.ErrNoEligibleAccount) {
		return "account_required"
	}
	var feedback *aistudio.PromptFeedbackError
	if errors.As(err, &feedback) {
		return "invalid_prompt"
	}
	if errors.Is(err, aistudio.ErrInvalidArgument) || isUnverifiedProtocolError(err) {
		return "invalid_request"
	}
	if contextOverflow(err) {
		return "context_length_exceeded"
	}
	switch statusFromError(err) {
	case http.StatusNotFound:
		return codeFromError(err, "model_not_found")
	case http.StatusTooManyRequests:
		return "rate_limit_exceeded"
	default:
		return codeFromError(err, "upstream_error")
	}
}

func anthropicErrorType(err error) string {
	if isUnverifiedProtocolError(err) {
		return "invalid_request_error"
	}
	return anthropicStatusErrorType(statusFromError(err))
}

// anthropicStatusErrorType 返回 HTTP 状态对应的 Anthropic 错误类型
func anthropicStatusErrorType(status int) string {
	switch status {
	case http.StatusBadRequest:
		return "invalid_request_error"
	case http.StatusUnauthorized:
		return "authentication_error"
	case http.StatusForbidden:
		return "permission_error"
	case http.StatusNotFound:
		return "not_found_error"
	case http.StatusRequestEntityTooLarge:
		return "request_too_large"
	case http.StatusTooManyRequests:
		return "rate_limit_error"
	case http.StatusGatewayTimeout:
		return "timeout_error"
	case 529:
		return "overloaded_error"
	default:
		return "api_error"
	}
}

func geminiErrorStatus(err error) string {
	switch statusFromError(err) {
	case http.StatusBadRequest:
		return "INVALID_ARGUMENT"
	case http.StatusUnauthorized:
		return "UNAUTHENTICATED"
	case http.StatusForbidden:
		return "PERMISSION_DENIED"
	case http.StatusNotFound:
		return "NOT_FOUND"
	case http.StatusConflict:
		return "ALREADY_EXISTS"
	case http.StatusTooManyRequests:
		return "RESOURCE_EXHAUSTED"
	case http.StatusServiceUnavailable:
		return "UNAVAILABLE"
	case http.StatusGatewayTimeout:
		return "DEADLINE_EXCEEDED"
	default:
		return "INTERNAL"
	}
}
