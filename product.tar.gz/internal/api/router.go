package api

import (
	"context"
	"fmt"
	"log/slog"
	"net/http"
	"sync"
	"sync/atomic"
	"time"

	"github.com/Mag1cFall/AIStudio2API/internal/aistudio"
)

// Config 定义公开 API 服务配置
type Config struct {
	APIKey           string
	Admin            AdminService
	AdminAuthEnabled bool
	AdminUsername    string
	AdminPassword    string
	// AdminSessionPath 是记住我的管理会话文件
	AdminSessionPath string
	Ledger           RequestLedger
	Prompts          PromptStore
	Updates          UpdateService
	// MediaDir 是媒体 URL 模式下生成媒体的保存目录
	MediaDir string
	// MediaLimit 是媒体目录的总字节上限，超过时删除最久未使用的文件
	MediaLimit int64
	// MediaLinks 返回媒体输出是否使用 URL 与设置的服务地址
	MediaLinks func() (enabled bool, base string)
	// ResponseModes 返回非流式保活与假流式设置
	ResponseModes func() ResponseModes
	// SearchSettings 返回当前生成服务的搜索型号与全模型搜索设置
	SearchSettings func() (modelAliases, googleSearch bool)
	// WaitLaunch 在生成服务启动期间等到启动结束，公开 API 请求经它等待后再处理
	WaitLaunch func(context.Context)
	// EgressProxy 返回服务连接外部 MCP 服务器所用的出口代理，空串为直连
	EgressProxy func() string
	// States 持久保存 Responses、Interactions 与 Chat 音频回复的续接节点，为空时只保存在内存中
	States StateStore
}

// ResponseModes 是生成请求的响应方式设置
type ResponseModes struct {
	// NonstreamKeepalive 让非流式请求在等待结果期间定时写出换行
	NonstreamKeepalive bool
	// FakeStream 让流式请求收齐完整结果后再按流式输出
	FakeStream bool
}

type server struct {
	service           aistudio.Service
	config            Config
	responseStates    *responseStateStore
	uploads           *geminiUploads
	caches            *geminiCaches
	thoughtSignatures *thoughtSignatureStore
	pairing           *pairingTokens
	loginViews        *loginViews
	accountTasks      *accountTasks
	// background 按响应 ID 保存进行中的 Responses 后台响应
	background sync.Map
	// media 是媒体 URL 模式的生成媒体目录
	media *mediaStore
}

var idSequence atomic.Uint64

// NewHandler 创建公开 API 路由
func NewHandler(service aistudio.Service, config Config) http.Handler {
	s := &server{
		service: service, config: config, responseStates: newResponseStateStore(config.States), uploads: newGeminiUploads(), caches: newGeminiCaches(),
		thoughtSignatures: newThoughtSignatureStore(), pairing: &pairingTokens{}, loginViews: &loginViews{}, accountTasks: &accountTasks{},
		media: &mediaStore{dir: config.MediaDir, limit: config.MediaLimit},
	}
	if config.MediaDir != "" {
		if err := s.media.trim(); err != nil {
			slog.Warn("媒体目录回收失败", "dir", config.MediaDir, "error", err)
		}
	}
	public := http.NewServeMux()
	public.HandleFunc("GET /v1/models", s.handleOpenAIModels)
	public.HandleFunc("GET /v1/models/{model...}", s.handleOpenAIModel)
	public.HandleFunc("POST /v1/chat/completions", s.handleChatCompletions)
	public.HandleFunc("POST /v1/embeddings", s.handleOpenAIEmbeddings)
	public.HandleFunc("POST /v1/responses", s.handleResponses)
	public.HandleFunc("POST /v1/responses/input_tokens", s.handleResponsesInputTokens)
	public.HandleFunc("POST /v1/responses/compact", s.handleResponsesCompact)
	public.HandleFunc("GET /v1/responses/{response}", s.handleResponseGet)
	public.HandleFunc("DELETE /v1/responses/{response}", s.handleResponseDelete)
	public.HandleFunc("GET /v1/responses/{response}/input_items", s.handleResponseInputItems)
	public.HandleFunc("POST /v1/responses/{response}/cancel", s.handleResponseCancel)
	public.HandleFunc("POST /v1/interactions", s.handleInteraction)
	public.HandleFunc("POST /v1beta/interactions", s.handleInteraction)
	public.HandleFunc("GET /v1/interactions/{id}", s.handleInteractionGet)
	public.HandleFunc("GET /v1beta/interactions/{id}", s.handleInteractionGet)
	public.HandleFunc("DELETE /v1/interactions/{id}", s.handleInteractionDelete)
	public.HandleFunc("DELETE /v1beta/interactions/{id}", s.handleInteractionDelete)
	public.HandleFunc("POST /v1/interactions/{id}/cancel", s.handleInteractionCancel)
	public.HandleFunc("POST /v1beta/interactions/{id}/cancel", s.handleInteractionCancel)
	public.HandleFunc("POST /v1/files", s.handleFileUpload)
	public.HandleFunc("GET /v1/files", s.handleFileList)
	public.HandleFunc("GET /v1/files/{file}", s.handleFileGet)
	public.HandleFunc("GET /v1/files/{file}/content", s.handleFileContent)
	public.HandleFunc("DELETE /v1/files/{file}", s.handleFileDelete)
	public.HandleFunc("POST /v1/images/generations", s.handleOpenAIImages)
	public.HandleFunc("POST /v1/images/edits", s.handleOpenAIImageEdits)
	public.HandleFunc("POST /v1/audio/speech", s.handleOpenAISpeech)
	public.HandleFunc("POST /v1/audio/transcriptions", s.handleOpenAITranscription)
	public.HandleFunc("POST /v1/audio/translations", s.handleOpenAITranslation)
	public.HandleFunc("GET /v1/live", s.handleGeminiLive)
	public.HandleFunc("GET /v1/robotics/stream", s.handleRoboticsStream)
	public.HandleFunc("POST /v1/videos", s.handleOpenAIVideoCreate)
	public.HandleFunc("GET /v1/videos", s.handleOpenAIVideoList)
	public.HandleFunc("GET /v1/videos/{video}", s.handleOpenAIVideoGet)
	public.HandleFunc("DELETE /v1/videos/{video}", s.handleOpenAIVideoDelete)
	public.HandleFunc("GET /v1/videos/{video}/content", s.handleOpenAIVideoContent)
	public.HandleFunc("POST /v1/messages", s.handleAnthropicMessages)
	public.HandleFunc("POST /v1/messages/count_tokens", s.handleAnthropicCountTokens)
	public.HandleFunc("GET /v1beta/models", s.handleGeminiModels)
	public.HandleFunc("GET /v1beta/models/{model...}", s.handleGeminiModel)
	public.HandleFunc("POST /v1beta/models/{action}", s.handleGeminiAction)
	public.HandleFunc("GET /v1beta/operations/{operation}", s.handleGeminiVideoOperation)
	public.HandleFunc("POST /v1beta/decisions", s.handleDecision)
	public.HandleFunc("POST /upload/v1beta/files", s.handleGeminiFileUpload)
	public.HandleFunc("GET /v1beta/files", s.handleGeminiFileList)
	public.HandleFunc("GET /v1beta/files/{file}", s.handleGeminiFileGet)
	public.HandleFunc("GET /v1beta/files/{uri...}", s.handleGeminiFileURIGet)
	public.HandleFunc("DELETE /v1beta/files/{file}", s.handleGeminiFileDelete)
	public.HandleFunc("POST /v1beta/cachedContents", s.handleGeminiCacheCreate)
	public.HandleFunc("GET /v1beta/cachedContents", s.handleGeminiCacheList)
	public.HandleFunc("GET /v1beta/cachedContents/{cache}", s.handleGeminiCacheGet)
	public.HandleFunc("PATCH /v1beta/cachedContents/{cache}", s.handleGeminiCacheUpdate)
	public.HandleFunc("DELETE /v1beta/cachedContents/{cache}", s.handleGeminiCacheDelete)
	public.HandleFunc("/", writeRouteNotFound)

	control := http.NewServeMux()
	control.HandleFunc("GET /api/status", s.handleStatus)
	control.HandleFunc("GET /api/models", s.handleAdminModels)
	s.registerAdmin(control)
	s.registerLedger(control)
	s.registerPrompts(control)
	s.registerUpdates(control)

	root := http.NewServeMux()
	root.Handle("GET /health", corsMiddleware(http.HandlerFunc(s.handleHealth)))
	publicHandler := bodyLimitMiddleware(browserOriginMiddleware(config.APIKey, authMiddleware(config.APIKey, apiKeyContextMiddleware(config.APIKey, accountContextMiddleware(requestBodyMiddleware(config.Ledger, waitLaunchMiddleware(config.WaitLaunch, public)))))))
	loggedHandler := requestLoggingMiddleware(config.Admin, corsMiddleware(publicHandler))
	root.Handle("/v1/", loggedHandler)
	root.Handle("/v1beta/", loggedHandler)
	root.Handle("/upload/", requestLoggingMiddleware(config.Admin, corsMiddleware(s.geminiUploadHandler(publicHandler))))
	root.Handle("/api/", newAdminAuth(config).handler(control))
	if config.MediaDir != "" {
		root.Handle("GET /media/{file}", corsMiddleware(http.HandlerFunc(s.handleMedia)))
	}
	root.HandleFunc("POST /api/pairing/accounts", s.handlePairingAccount)
	root.HandleFunc("PUT /api/pairing/accounts/{account}/cookies", s.handlePairingRenewal)
	return root
}

// waitLaunchMiddleware 让请求在生成服务启动期间等到启动结束再处理，wait 为空时直接处理
func waitLaunchMiddleware(wait func(context.Context), next http.Handler) http.Handler {
	if wait == nil {
		return next
	}
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		wait(r.Context())
		next.ServeHTTP(w, r)
	})
}

func newID(prefix string) string {
	return fmt.Sprintf("%s_%d_%d", prefix, time.Now().UnixNano(), idSequence.Add(1))
}
