<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useI18n, type TranslationKey } from '@/i18n'
import DisclosureChevron from '@/components/DisclosureChevron.vue'
import UiCollapse from '@/components/UiCollapse.vue'
import UiIcon from '@/playground/ui/UiIcon.vue'
import UiSelect from '@/playground/ui/UiSelect.vue'
import UiSlider from '@/playground/ui/UiSlider.vue'
import UiSwitch from '@/playground/ui/UiSwitch.vue'
import EnvironmentSettings from './EnvironmentSettings.vue'
import GetCodeDialog from './GetCodeDialog.vue'
import JsonEditorDialog from './JsonEditorDialog.vue'
import ModelCard from './ModelCard.vue'
import RunSettingsFrame from './RunSettingsFrame.vue'
import SafetyDialog from './SafetyDialog.vue'
import SystemInstructions from './SystemInstructions.vue'
import ThinkingBudgetSetting from './ThinkingBudgetSetting.vue'
import {
  Capability,
  hasCode,
  isAgent,
  isOmniModel,
  thinkingLevelLabels,
  thinkingLevelTooltips,
} from './catalog'
import { protocolOptions, protocolsFor, protocolSupports, type ProtocolSetting } from './protocols'
import { defaultSettings, outputLimit, useCompare, usePlayground } from './session'
import { useTools } from './tools'
import type { ImageOutput, ImageQuality, MediaResolution } from './types'
import type { Model } from '@/types'
import type { IconName } from '@/playground/ui/icons'

defineProps<{ open: boolean; narrow: boolean; title?: string | undefined }>()
const emit = defineEmits<{ close: [] }>()
const { t } = useI18n()
const route = useRoute()
const router = useRouter()
const playground = usePlayground()
const { session, currentModel } = playground
const { panes, comparing, syncInstructions, setSync } = useCompare()
// paneIndex 是本运行设置所属窗格的序号
const paneIndex = computed(() => panes.findIndex((pane) => pane.session === session))
const { tools, setTool } = useTools()

const toolsOpen = ref(true)
const advancedOpen = ref(false)
const systemOpen = ref(false)
const safetyOpen = ref(false)
const schemaOpen = ref(false)
const functionsOpen = ref(false)
const codeOpen = ref(false)
const stopDraft = ref('')
const samplingPreset = ref('custom')

const settings = computed(() => session.settings)
const model = computed(() => currentModel.value)
const can = (code: number) => hasCode(model.value, code)
// agent 表示所选模型是 agent：请求以 agent_config 代替生成参数，不显示采样设置
const agent = computed(() => isAgent(model.value))
// sampling 表示显示采样预设、温度、Top K 与 Top P，agent 与 Omni 模型不显示
const sampling = computed(() => !agent.value && !isOmniModel(model.value))
// researchSettings 是 Deep Research 的思考摘要、可视化与协作规划开关，与官网一样按各自的能力码显示
const researchSettings = computed(() =>
  (
    [
      {
        key: 'thinkingSummaries',
        code: Capability.ThinkingSummaries,
        label: 'pg.thinkingSummaries',
        tooltip: 'pg.thinkingSummariesTip',
      },
      {
        key: 'visualization',
        code: Capability.Visualization,
        label: 'pg.visualization',
        tooltip: 'pg.visualizationTip',
      },
      {
        key: 'collaborativePlanning',
        code: Capability.CollaborativePlanning,
        label: 'pg.collaborativePlanning',
        tooltip: 'pg.collaborativePlanningTip',
      },
    ] as const
  ).filter((item) => can(item.code)),
)
// samplingPresets 是一次设定温度、Top P 与 Top K 的采样组合
const samplingPresets = [
  { value: 'code', label: 'pg.samplingCode', temperature: 0.1, topP: 0.1, topK: 4 },
  { value: 'balanced', label: 'pg.samplingBalanced', temperature: 1, topP: 0.95, topK: 64 },
  { value: 'creative', label: 'pg.samplingCreative', temperature: 1.1, topP: 0.95, topK: 64 },
] as const

// applySamplingPreset 设置采样组合，温度不超过模型上限，自定义保留当前值
function applySamplingPreset(value: string): void {
  const preset = samplingPresets.find((item) => item.value === value)
  if (preset) {
    settings.value.temperature = Math.min(preset.temperature, model.value?.max_temperature ?? 1)
    settings.value.topP = preset.topP
    settings.value.topK = preset.topK
  }
  samplingPreset.value = value
}

watch(
  [
    settings,
    () => settings.value.model,
    () => settings.value.temperature,
    () => settings.value.topP,
    () => settings.value.topK,
  ],
  () => {
    samplingPreset.value = 'custom'
  },
  { flush: 'sync' },
)
// supports 判断所选协议能否表达某项设置
const supports = (setting: ProtocolSetting) => protocolSupports(settings.value.protocol, setting)
// protocolTip 是所选协议不支持某项设置时的说明
const protocolTip = computed(() =>
  t('pg.protocolUnsupported').replace(
    '{protocol}',
    protocolOptions.find((item) => item.value === settings.value.protocol)?.label ?? '',
  ),
)
// settingTip 返回设置项的说明，所选协议不支持时说明原因
const settingTip = (setting: ProtocolSetting, tip: string) =>
  supports(setting) ? tip : protocolTip.value
const mediaResolutions: { value: MediaResolution; label: string }[] = [
  { value: '', label: 'pg.default' },
  { value: 'MEDIA_RESOLUTION_LOW', label: 'pg.low' },
  { value: 'MEDIA_RESOLUTION_MEDIUM', label: 'pg.medium' },
  { value: 'MEDIA_RESOLUTION_HIGH', label: 'pg.high' },
]
// imageModel 表示所选模型输出图片
const imageModel = computed(() => can(Capability.ImageRoute))
// videoOptions 是 Omni 模型目录中的视频输出选项，没有视频任务的模型为 undefined
const videoOptions = computed(() => {
  const options = model.value?.capability_options
  if (!options?.video_tasks) return undefined
  const range = Object.fromEntries(
    (options.video_duration_range ?? []).map((item) => {
      const [name = '', value = ''] = item.split('=')
      return [name, Number(value)]
    }),
  )
  const { min = 0, max = 0, step = 1 } = range
  const initial = range.default ?? max
  return {
    aspectRatios: options.video_aspect_ratios ?? [],
    resolutions: options.video_output_resolutions ?? [],
    frameRates: options.video_frame_rates ?? [],
    tasks: Object.keys(videoTaskLabels).filter((task) => options.video_tasks?.includes(task)),
    duration: { min, max, step, initial },
  }
})
// videoTaskLabels 是视频任务在官网下拉框中的名称
const videoTaskLabels: Record<string, TranslationKey> = {
  text_to_video: 'pg.videoTaskText',
  image_to_video: 'pg.videoTaskImage',
  reference_to_video: 'pg.videoTaskReference',
  edit: 'pg.videoTaskEdit',
  extend: 'pg.videoTaskExtend',
}

// selectModel 切换对话模型，新对话与官网一样把模型写入地址
function selectModel(model: Model): void {
  playground.selectModel(model.id)
  if (route.params.id === undefined)
    void router.push({ query: { ...route.query, model: model.id } })
}

// setVideoDuration 设置视频时长，与默认值相同时不发送
function setVideoDuration(value: number): void {
  const { min, max, initial } = videoOptions.value!.duration
  const seconds = Math.min(max, Math.max(min, Math.round(value)))
  settings.value.videoDuration = seconds === initial ? null : seconds
}
// imagesProtocol 表示以 OpenAI Images 协议发送，只显示该协议的图片参数
const imagesProtocol = computed(() => settings.value.protocol === 'openai-images')
// imageOutputs 是官网输出格式切换组的选项
const imageOutputs: { value: ImageOutput; label: string; icon: IconName }[] = [
  { value: 'IMAGE_TEXT', label: 'pg.imagesAndText', icon: 'imagesAndText' },
  { value: 'IMAGE', label: 'pg.imagesOnly', icon: 'modeImage' },
]
// aspectRatioOrder 是官网宽高比下拉的顺序
const aspectRatioOrder = [
  '1:1',
  '9:16',
  '16:9',
  '3:4',
  '4:3',
  '3:2',
  '2:3',
  '5:4',
  '4:5',
  '21:9',
  '4:1',
  '1:4',
  '8:1',
  '1:8',
]
// aspectRatios 是模型支持的宽高比，按官网顺序排列
const aspectRatios = computed(() => {
  const ratios = model.value?.capability_options?.image_aspect_ratios ?? []
  const rank = (ratio: string) => {
    const index = aspectRatioOrder.indexOf(ratio)
    return index === -1 ? aspectRatioOrder.length : index
  }
  return [...ratios].sort((first, second) => rank(first) - rank(second))
})
// imageSizes 是模型支持的分辨率，按像素从小到大排列
const imageSizes = computed(() =>
  [...(model.value?.capability_options?.image_output_resolutions ?? [])].sort(
    (first, second) =>
      Number.parseFloat(first) * (first.endsWith('K') ? 1024 : 1) -
      Number.parseFloat(second) * (second.endsWith('K') ? 1024 : 1),
  ),
)
// openAISizes 是 OpenAI Images 协议常用的图片尺寸
const openAISizes = ['auto', '1024x1024', '1536x1024', '1024x1536', '1792x1024', '1024x1792']
// imageQualities 是 OpenAI Images 协议的质量选项
const imageQualities: { value: ImageQuality; label: string }[] = [
  { value: 'auto', label: 'playground.auto' },
  { value: 'low', label: 'pg.low' },
  { value: 'medium', label: 'pg.medium' },
  { value: 'high', label: 'pg.high' },
]

// systemSubtitle 是系统指令卡片的副标题
const systemSubtitle = computed(
  () => settings.value.systemInstruction.trim().split('\n')[0] || t('pg.systemHint'),
)
// temperatureTooltip 是温度滑块的说明
const temperatureTooltip = computed(() => {
  if (can(Capability.FixedTemperature)) return t('pg.temperatureFixed')
  return /gemini-3/.test(model.value?.id ?? '')
    ? t('pg.temperatureGemini3')
    : t('pg.temperatureTip')
})

// numberInput 把数值输入框内容换成设置值，空值时为 null
function numberInput(event: Event): number | null {
  const value = (event.target as HTMLInputElement).value
  return value === '' ? null : Number(value)
}

// setOutputLength 按官网规则把输出长度限制为 1 到模型上限之间的整数，清空时恢复模型默认值
function setOutputLength(event: Event): void {
  const input = event.target as HTMLInputElement
  const value = numberInput(event)
  const limit = outputLimit(model.value) ?? Number.MAX_SAFE_INTEGER
  settings.value.maxOutputTokens =
    value === null || !Number.isFinite(value)
      ? (model.value?.output_token_limit ?? null)
      : Math.min(Math.max(Math.round(value), 1), limit)
  input.value = String(settings.value.maxOutputTokens ?? '')
}

// onOutputLengthInput 在输入写成规范十进制的有效整数时同步更新输出长度，留待失焦或回车时修正空值、越界值与前导零
function onOutputLengthInput(event: Event): void {
  const value = numberInput(event)
  const limit = outputLimit(model.value) ?? Number.MAX_SAFE_INTEGER
  if (
    value !== null &&
    Number.isInteger(value) &&
    value >= 1 &&
    value <= limit &&
    (event.target as HTMLInputElement).value === String(value)
  )
    settings.value.maxOutputTokens = value
}

// setTopK 按官网规则只保留正整数的 Top K，其他输入清空
function setTopK(event: Event): void {
  const input = event.target as HTMLInputElement
  const value = numberInput(event)
  settings.value.topK = value !== null && value > 0 && Number.isInteger(value) ? value : null
  input.value = String(settings.value.topK ?? '')
}

// addStop 把输入的停止序列加入列表
function addStop(): void {
  const value = stopDraft.value
  if (value !== '' && !settings.value.stopSequences.includes(value))
    settings.value.stopSequences.push(value)
  stopDraft.value = ''
}

// reset 恢复当前模型的默认运行设置，保留系统指令
function reset(): void {
  session.settings = {
    ...defaultSettings(model.value),
    systemInstruction: settings.value.systemInstruction,
  }
}

// defaultResponseSchema 是官网关闭 Schema 编辑器时为空 Schema 填入的默认值
const defaultResponseSchema = `${JSON.stringify(
  { type: 'object', properties: { response: { type: 'string' } } },
  null,
  2,
)}
`

// toggleTool 开启或关闭工具，与官网一样开启结构化输出时打开 Schema 编辑器
function toggleTool(id: (typeof tools.value)[number]['id'], enabled: boolean): void {
  setTool(id, enabled)
  if (id === 'structured_output' && enabled) schemaOpen.value = true
}

watch(schemaOpen, (open) => {
  if (
    !open &&
    settings.value.tools.includes('structured_output') &&
    settings.value.responseSchema.trim() === ''
  )
    settings.value.responseSchema = defaultResponseSchema
})
</script>

<template>
  <RunSettingsFrame
    :open="open"
    :narrow="narrow"
    :title="title"
    :code-button="!comparing"
    @close="emit('close')"
    @code="codeOpen = true"
    @reset="reset"
  >
    <div class="field-group">
      <ModelCard
        v-if="!comparing"
        :model="model"
        kind="chat"
        :has-content="session.turns.length > 0"
        :agent-model="settings.agentModel"
        @select="selectModel"
        @agent-model="settings.agentModel = $event"
      />
      <div class="system-instructions-panel">
        <button
          v-tooltip.left="can(Capability.SystemInstruction) ? '' : t('pg.systemUnsupported')"
          type="button"
          class="settings-card system-instructions-card"
          :class="{ 'disabled-interactive': !can(Capability.SystemInstruction) }"
          :aria-label="t('pg.systemInstructions')"
          @click="can(Capability.SystemInstruction) && (systemOpen = true)"
        >
          <span class="title">{{ t('pg.systemInstructions') }}</span>
          <span class="subtitle">{{ systemSubtitle }}</span>
        </button>
        <label
          v-if="comparing"
          v-tooltip.below="t('pg.syncInstructionsTip')"
          class="sync-button"
          :class="{ disabled: !can(Capability.SystemInstruction) }"
        >
          <span class="checkbox">
            <input
              type="checkbox"
              :checked="can(Capability.SystemInstruction) && syncInstructions"
              :disabled="!can(Capability.SystemInstruction)"
              :aria-label="t('pg.syncInstructions')"
              @change="setSync(paneIndex, ($event.target as HTMLInputElement).checked)"
            />
            <span class="checkbox-background" aria-hidden="true">
              <svg viewBox="0 0 24 24">
                <path fill="none" d="M1.73,12.91 8.1,19.28 22.79,4.59" />
              </svg>
            </span>
          </span>
          <span class="sync-checkbox-label">{{ t('pg.sync') }}</span>
        </label>
      </div>
    </div>

    <div v-if="imagesProtocol" class="field-group">
      <div v-tooltip.left="t('pg.openAISizeTip')" class="settings-item-column">
        <h3 class="item-description-title">{{ t('playground.imageSize') }}</h3>
        <UiSelect
          v-model="settings.openAISize"
          class="w-full"
          :aria-label="t('playground.imageSize')"
        >
          <option v-for="size in openAISizes" :key="size" :value="size">
            {{ size === 'auto' ? t('playground.auto') : size }}
          </option>
        </UiSelect>
      </div>
      <div v-tooltip.left="t('pg.imageQualityTip')" class="settings-item-column">
        <h3 class="item-description-title">{{ t('playground.imageQuality') }}</h3>
        <UiSelect
          v-model="settings.imageQuality"
          class="w-full"
          :aria-label="t('playground.imageQuality')"
        >
          <option v-for="item in imageQualities" :key="item.value" :value="item.value">
            {{ t(item.label as 'pg.low') }}
          </option>
        </UiSelect>
      </div>
      <div v-tooltip.left="t('pg.imageCountTip')" class="settings-item-column">
        <h3 class="item-description-title">{{ t('pg.numberOfResults') }}</h3>
        <div class="ms-slider">
          <UiSlider
            v-model="settings.imageCount"
            :min="1"
            :max="4"
            :step="1"
            :label="t('pg.numberOfResults')"
          />
          <input
            ms-input
            class="small slider-number-input"
            type="number"
            min="1"
            max="4"
            step="1"
            :aria-label="t('pg.numberOfResults')"
            :value="settings.imageCount"
            @change="
              settings.imageCount = Math.min(Math.max(Math.round(numberInput($event) ?? 1), 1), 4)
            "
          />
        </div>
      </div>
      <div class="toggle-row">
        <div class="label-container">
          <p class="label">{{ t('playground.stream') }}</p>
        </div>
        <UiSwitch v-model="settings.stream" :label="t('playground.stream')" />
      </div>
    </div>

    <template v-else>
      <div v-if="imageModel" class="field-group">
        <div v-tooltip.left="t('pg.outputFormatTip')" class="settings-item-column">
          <h3 class="item-description-title">{{ t('pg.outputFormat') }}</h3>
          <div role="radiogroup" class="output-format" :aria-label="t('pg.outputFormat')">
            <button
              v-for="option in imageOutputs"
              :key="option.value"
              type="button"
              role="radio"
              class="output-format-option"
              :class="{ active: settings.imageOutput === option.value }"
              :aria-checked="settings.imageOutput === option.value"
              @click="settings.imageOutput = option.value"
            >
              <UiIcon :name="option.icon" :size="20" />
              <span class="toggle-label">{{ t(option.label as 'pg.imagesOnly') }}</span>
            </button>
          </div>
        </div>
      </div>

      <div
        v-if="
          can(Capability.Temperature) || (imageModel && (aspectRatios.length || imageSizes.length))
        "
        class="field-group"
      >
        <div
          v-if="can(Capability.Temperature)"
          v-tooltip.left="temperatureTooltip"
          class="settings-item-column"
        >
          <h3 class="item-description-title">{{ t('pg.temperature') }}</h3>
          <div class="ms-slider">
            <UiSlider
              :model-value="settings.temperature ?? model?.temperature ?? 1"
              :min="0"
              :max="model?.max_temperature ?? 1"
              :step="0.05"
              :disabled="can(Capability.FixedTemperature)"
              :label="t('pg.temperature')"
              @update:model-value="settings.temperature = $event"
            />
            <input
              ms-input
              class="small slider-number-input"
              type="number"
              :min="0"
              :max="model?.max_temperature ?? 1"
              step="0.05"
              :disabled="can(Capability.FixedTemperature)"
              :aria-label="t('pg.temperature')"
              :value="settings.temperature ?? model?.temperature ?? 1"
              @change="settings.temperature = numberInput($event)"
            />
          </div>
        </div>
        <div
          v-if="imageModel && aspectRatios.length"
          v-tooltip.left="t('pg.aspectRatioTip')"
          class="settings-item-column"
        >
          <h3 class="item-description-title">{{ t('pg.aspectRatio') }}</h3>
          <UiSelect v-model="settings.aspectRatio" class="w-full" :aria-label="t('pg.aspectRatio')">
            <option value="">{{ t('playground.auto') }}</option>
            <option v-for="ratio in aspectRatios" :key="ratio" :value="ratio">{{ ratio }}</option>
          </UiSelect>
        </div>
        <div
          v-if="imageModel && imageSizes.length"
          v-tooltip.left="t('pg.resolutionTip')"
          class="settings-item-column"
        >
          <h3 class="item-description-title">{{ t('pg.resolution') }}</h3>
          <UiSelect v-model="settings.imageSize" class="w-full" :aria-label="t('pg.resolution')">
            <option v-for="size in imageSizes" :key="size" :value="size">{{ size }}</option>
          </UiSelect>
        </div>
      </div>

      <div v-if="videoOptions" class="field-group">
        <div class="settings-item-column">
          <h3 class="item-description-title">{{ t('pg.aspectRatio') }}</h3>
          <UiSelect
            v-model="settings.videoAspectRatio"
            class="w-full"
            :aria-label="t('pg.aspectRatio')"
          >
            <option value="">{{ t('playground.auto') }}</option>
            <option v-for="ratio in videoOptions.aspectRatios" :key="ratio" :value="ratio">
              {{ ratio }}
            </option>
          </UiSelect>
        </div>
        <div class="settings-item-column">
          <h3 class="item-description-title">{{ t('pg.videoDuration') }}</h3>
          <div class="ms-slider">
            <UiSlider
              :model-value="settings.videoDuration ?? videoOptions.duration.initial"
              :min="videoOptions.duration.min"
              :max="videoOptions.duration.max"
              :step="videoOptions.duration.step"
              :label="t('pg.videoDurationSeconds')"
              @update:model-value="setVideoDuration"
            />
            <input
              ms-input
              class="small slider-number-input"
              type="number"
              :min="videoOptions.duration.min"
              :max="videoOptions.duration.max"
              :step="videoOptions.duration.step"
              :aria-label="t('pg.videoDurationSeconds')"
              :value="settings.videoDuration ?? videoOptions.duration.initial"
              @change="setVideoDuration(Number(($event.target as HTMLInputElement).value))"
            />
          </div>
        </div>
        <div v-if="videoOptions.resolutions.length" class="settings-item-column">
          <h3 class="item-description-title">{{ t('pg.resolution') }}</h3>
          <UiSelect
            v-model="settings.videoResolution"
            class="w-full"
            :disabled="videoOptions.resolutions.length === 1"
            :aria-label="t('pg.videoResolution')"
          >
            <option v-for="size in videoOptions.resolutions" :key="size" :value="size">
              {{ size }}
            </option>
          </UiSelect>
        </div>
        <div v-if="videoOptions.frameRates.length" class="settings-item-column">
          <h3 class="item-description-title">{{ t('pg.frameRate') }}</h3>
          <UiSelect
            :model-value="videoOptions.frameRates[0] ?? ''"
            class="w-full"
            :disabled="videoOptions.frameRates.length === 1"
            :aria-label="t('pg.videoFrameRate')"
          >
            <option v-for="rate in videoOptions.frameRates" :key="rate" :value="rate">
              {{ rate }}
            </option>
          </UiSelect>
        </div>
      </div>

      <div
        v-if="can(Capability.ThinkingLevel) && model?.thinking_levels?.length"
        class="field-group"
      >
        <div v-tooltip.left="t('pg.thinkingLevelTip')" class="settings-item-column">
          <h3 class="item-description-title">{{ t('pg.thinkingLevel') }}</h3>
          <UiSelect
            :model-value="settings.thinkingLevel ?? model.default_thinking_level ?? ''"
            class="w-full"
            :aria-label="t('pg.thinkingLevel')"
            @update:model-value="
              settings.thinkingLevel = String($event) as typeof settings.thinkingLevel
            "
          >
            <option
              v-for="level in model.thinking_levels"
              :key="level"
              :value="level"
              :title="thinkingLevelTooltips[level] && t(thinkingLevelTooltips[level])"
            >
              {{ t(thinkingLevelLabels[level]) }}
            </option>
          </UiSelect>
        </div>
      </div>
      <div v-else-if="can(Capability.ThinkingBudget)" class="field-group">
        <ThinkingBudgetSetting
          v-model="settings.thinkingBudget"
          :config="model?.thinking_budget"
          :disabled="!supports('thinkingBudget')"
          :disabled-tip="protocolTip"
        />
      </div>

      <div v-if="tools.length" class="field-group">
        <button
          type="button"
          class="settings-group-header"
          :aria-expanded="toolsOpen"
          :aria-label="t('pg.toggleTools')"
          @click="toolsOpen = !toolsOpen"
        >
          <span class="group-title">{{ t('pg.tools') }}</span>
          <DisclosureChevron :open="toolsOpen" :turn="180" class="expand-icon"
            ><UiIcon name="chevronDown" :size="20"
          /></DisclosureChevron>
        </button>
        <UiCollapse :open="toolsOpen">
          <div
            v-for="tool in tools"
            :key="tool.id"
            v-tooltip.left="
              tool.id === 'structured_output'
                ? settingTip('structuredOutput', t(tool.tooltip))
                : t(tool.tooltip)
            "
            class="toggle-row"
          >
            <div class="label-container">
              <p class="label">{{ t(tool.label) }}</p>
              <p v-if="tool.id === 'google_search' && tool.enabled" class="search-source">
                {{ t('pg.source') }} <UiIcon name="googleColor" :size="12" /> Google Search
              </p>
            </div>
            <div class="actions">
              <button
                v-if="tool.editable"
                type="button"
                ms-button
                class="edit-button ms-button-borderless"
                :aria-label="
                  tool.id === 'structured_output' ? t('pg.editSchema') : t('pg.editFunctions')
                "
                :aria-disabled="!tool.enabled"
                @click="
                  tool.enabled &&
                  (tool.id === 'structured_output' ? (schemaOpen = true) : (functionsOpen = true))
                "
              >
                {{ t('pg.edit') }}
              </button>
              <UiSwitch
                :model-value="tool.enabled"
                :disabled="
                  tool.disabled ||
                  (tool.id === 'structured_output' && !supports('structuredOutput'))
                "
                :label="t(tool.label)"
                @update:model-value="toggleTool(tool.id, $event)"
              />
            </div>
          </div>
          <div
            v-if="can(Capability.RemoteEnvironment)"
            v-tooltip.left="t('pg.filesystemToolsTip')"
            class="toggle-row"
          >
            <div class="label-container">
              <p class="label">{{ t('pg.filesystemTools') }}</p>
            </div>
            <UiSwitch :model-value="true" disabled :label="t('pg.filesystemTools')" />
          </div>
        </UiCollapse>
      </div>

      <EnvironmentSettings
        v-if="can(Capability.RemoteEnvironment)"
        v-model="settings.environment"
      />

      <div v-if="researchSettings.length" class="field-group">
        <div
          v-for="item in researchSettings"
          :key="item.key"
          v-tooltip.left="t(item.tooltip)"
          class="toggle-row"
        >
          <div class="label-container">
            <p class="label">{{ t(item.label) }}</p>
          </div>
          <UiSwitch v-model="settings[item.key]" :label="t(item.label)" />
        </div>
      </div>

      <div class="field-group advanced-settings">
        <button
          type="button"
          class="settings-group-header"
          :aria-expanded="advancedOpen"
          :aria-label="t('pg.toggleAdvanced')"
          @click="advancedOpen = !advancedOpen"
        >
          <span class="group-title">{{ t('pg.advancedSettings') }}</span>
          <DisclosureChevron :open="advancedOpen" :turn="180" class="expand-icon"
            ><UiIcon name="chevronDown" :size="20"
          /></DisclosureChevron>
        </button>
        <UiCollapse :open="advancedOpen">
          <div v-if="sampling && !can(Capability.FixedTemperature)" class="settings-item-column">
            <h3 class="item-description-title">{{ t('pg.samplingPreset') }}</h3>
            <UiSelect
              :model-value="samplingPreset"
              class="w-full"
              :aria-label="t('pg.samplingPreset')"
              @update:model-value="applySamplingPreset(String($event))"
            >
              <option value="custom">{{ t('pg.samplingCustom') }}</option>
              <option v-for="preset in samplingPresets" :key="preset.value" :value="preset.value">
                {{ t(preset.label) }}
              </option>
            </UiSelect>
          </div>
          <div
            v-if="can(Capability.MediaResolution)"
            v-tooltip.left="settingTip('mediaResolution', t('pg.mediaResolutionTip'))"
            class="settings-item-column"
          >
            <h3 class="item-description-title">{{ t('pg.mediaResolution') }}</h3>
            <UiSelect
              v-model="settings.mediaResolution"
              class="w-full"
              :disabled="!supports('mediaResolution')"
              :aria-label="t('pg.mediaResolution')"
            >
              <option v-for="item in mediaResolutions" :key="item.value" :value="item.value">
                {{ t(item.label as 'pg.default') }}
              </option>
            </UiSelect>
          </div>
          <div
            v-if="can(Capability.SafetySettings)"
            v-tooltip.left="settingTip('safety', t('pg.safetyTip'))"
            class="settings-item"
          >
            <h3 class="item-description-title">{{ t('pg.safetySettings') }}</h3>
            <button
              type="button"
              ms-button
              class="ms-button-borderless"
              :aria-label="t('pg.editSafety')"
              :aria-disabled="!supports('safety')"
              @click="supports('safety') && (safetyOpen = true)"
            >
              {{ t('pg.edit') }}
            </button>
          </div>
          <div
            v-if="can(Capability.StopSequences)"
            v-tooltip.left="settingTip('stopSequences', t('pg.stopTip'))"
            class="stop-sequences"
          >
            <div class="settings-item">
              <label class="item-description-title" for="stop-sequence">{{
                t('pg.addStop')
              }}</label>
              <input
                id="stop-sequence"
                v-model="stopDraft"
                ms-input
                class="small stop-input"
                :disabled="!supports('stopSequences')"
                :placeholder="t('pg.addStopPlaceholder')"
                @keydown.enter.prevent="addStop"
              />
            </div>
            <div v-if="settings.stopSequences.length" class="chips">
              <span
                v-for="(sequence, index) in settings.stopSequences"
                :key="sequence"
                class="chip"
              >
                <span class="chip-label">{{ sequence }}</span>
                <button
                  type="button"
                  class="chip-remove"
                  :aria-label="t('pg.removeStop')"
                  @click="settings.stopSequences.splice(index, 1)"
                >
                  <UiIcon name="close" :size="14" />
                </button>
              </span>
            </div>
          </div>
          <div
            v-if="can(Capability.MaxOutputTokens)"
            v-tooltip.left="t('pg.outputLengthTip')"
            class="settings-item output-length"
          >
            <h3 class="item-description-title">{{ t('pg.outputLength') }}</h3>
            <input
              ms-input
              class="small"
              type="number"
              min="1"
              step="1"
              :max="outputLimit(model)"
              :aria-label="t('pg.maxOutputTokens')"
              :value="settings.maxOutputTokens ?? outputLimit(model)"
              @input="onOutputLengthInput"
              @change="setOutputLength"
              @keydown.enter.prevent="setOutputLength"
            />
            <p v-if="model?.capabilities?.output_continuation" class="setting-hint">
              {{ t('pg.outputContinuation') }}
            </p>
          </div>
          <div
            v-if="sampling && !can(Capability.Temperature)"
            v-tooltip.left="t('pg.temperatureTip')"
            class="settings-item-column"
          >
            <h3 class="item-description-title">{{ t('pg.temperature') }}</h3>
            <div class="ms-slider">
              <UiSlider
                :model-value="settings.temperature ?? model?.temperature ?? 1"
                :min="0"
                :max="model?.max_temperature ?? 1"
                :step="0.05"
                :label="t('pg.temperature')"
                @update:model-value="settings.temperature = $event"
              />
              <input
                ms-input
                class="small slider-number-input"
                type="number"
                :min="0"
                :max="model?.max_temperature ?? 1"
                step="0.05"
                :aria-label="t('pg.temperature')"
                :value="settings.temperature ?? model?.temperature ?? 1"
                @change="settings.temperature = numberInput($event)"
              />
            </div>
            <p class="setting-hint">{{ t('pg.samplingIgnored') }}</p>
          </div>
          <div
            v-if="sampling"
            v-tooltip.left="settingTip('topK', t('pg.topKTip'))"
            class="settings-item-column"
          >
            <h3 class="item-description-title">{{ t('pg.topK') }}</h3>
            <div class="ms-slider">
              <UiSlider
                :model-value="settings.topK ?? model?.top_k ?? 64"
                :min="1"
                :max="128"
                :step="1"
                :disabled="!supports('topK')"
                :label="t('pg.topK')"
                @update:model-value="settings.topK = $event"
              />
              <input
                ms-input
                class="small slider-number-input"
                type="number"
                min="1"
                step="1"
                :disabled="!supports('topK')"
                :aria-label="t('pg.topK')"
                :value="settings.topK ?? model?.top_k ?? 64"
                @change="setTopK"
              />
            </div>
            <p v-if="!can(Capability.TopK)" class="setting-hint">{{ t('pg.samplingIgnored') }}</p>
          </div>
          <div v-if="sampling" v-tooltip.left="t('pg.topPTip')" class="settings-item-column">
            <h3 class="item-description-title">{{ t('pg.topP') }}</h3>
            <div class="ms-slider">
              <UiSlider
                :model-value="settings.topP ?? model?.top_p ?? 0.95"
                :min="0"
                :max="1"
                :step="0.05"
                :label="t('pg.topP')"
                @update:model-value="settings.topP = $event"
              />
              <input
                ms-input
                class="small slider-number-input"
                type="number"
                min="0"
                max="1"
                step="0.05"
                :aria-label="t('pg.topP')"
                :value="settings.topP ?? model?.top_p ?? 0.95"
                @change="settings.topP = numberInput($event)"
              />
            </div>
            <p v-if="!can(Capability.TopP)" class="setting-hint">{{ t('pg.samplingIgnored') }}</p>
          </div>
          <div v-if="videoOptions" class="settings-item">
            <h3 class="item-description-title">{{ t('pg.videoTask') }}</h3>
            <UiSelect
              v-model="settings.videoTask"
              class="video-task-select"
              :aria-label="t('pg.videoTaskLabel')"
            >
              <option value="">{{ t('pg.videoTaskUnspecified') }}</option>
              <option v-for="task in videoOptions.tasks" :key="task" :value="task">
                {{ t(videoTaskLabels[task]!) }}
              </option>
            </UiSelect>
          </div>
          <div class="settings-item-column protocol-setting">
            <h3 class="item-description-title">{{ t('playground.protocol') }}</h3>
            <UiSelect
              v-model="settings.protocol"
              class="w-full"
              :aria-label="t('playground.protocol')"
            >
              <option v-for="item in protocolsFor(model)" :key="item.value" :value="item.value">
                {{ item.label }}
              </option>
            </UiSelect>
          </div>
          <div class="toggle-row">
            <div class="label-container">
              <p class="label">{{ t('playground.stream') }}</p>
            </div>
            <UiSwitch v-model="settings.stream" :label="t('playground.stream')" />
          </div>
        </UiCollapse>
      </div>
    </template>
  </RunSettingsFrame>
  <SystemInstructions v-model:open="systemOpen" />
  <SafetyDialog v-model:open="safetyOpen" />
  <JsonEditorDialog
    v-model:open="schemaOpen"
    v-model:text="settings.responseSchema"
    kind="schema"
  />
  <JsonEditorDialog
    v-model:open="functionsOpen"
    v-model:text="settings.functionDeclarations"
    kind="functions"
  />
  <GetCodeDialog v-model:open="codeOpen" />
</template>

<style scoped>
.system-instructions-panel {
  display: grid;
  align-items: start;
  margin-block: 8px;
}

.system-instructions-card,
.sync-button {
  grid-column: 1;
  grid-row: 1;
}

.sync-button {
  display: flex;
  align-items: center;
  justify-self: end;
  height: 40px;
  padding-right: 12px;
  line-height: 17.5px;
  color: var(--color-run-settings-text);
  cursor: pointer;
}

.checkbox {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 40px;
  height: 40px;
}

.checkbox input {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  margin: 0;
  opacity: 0;
  cursor: inherit;
}

.checkbox-background {
  display: flex;
  width: 18px;
  height: 18px;
  border: 2px solid var(--color-v3-outline);
  border-radius: 2px;
  pointer-events: none;
  transition:
    background-color 90ms cubic-bezier(0.4, 0, 0.6, 1),
    border-color 90ms cubic-bezier(0.4, 0, 0.6, 1);
}

.checkbox-background svg {
  width: 100%;
  opacity: 0;
  color: var(--mat-sys-on-primary);
  stroke: currentColor;
  stroke-width: 3.12px;
}

.checkbox input:checked + .checkbox-background {
  border-color: var(--color-v3-text);
  background-color: var(--color-v3-text);
}

.checkbox:hover input:checked + .checkbox-background {
  border-color: var(--color-v3-text-var);
  background-color: var(--color-v3-text-var);
}

.checkbox input:checked + .checkbox-background svg {
  opacity: 1;
}

.checkbox input:disabled + .checkbox-background {
  border-color: var(--color-v3-outline-var);
}

.sync-button.disabled {
  cursor: not-allowed;
  pointer-events: none;
}

.sync-checkbox-label {
  padding-left: 4px;
  font-size: 12.25px;
}

.protocol-setting {
  margin-bottom: 8px;
}

.output-format {
  position: relative;
  display: flex;
  box-sizing: border-box;
  width: 100%;
  padding: 2px;
  border: 1px solid var(--color-v3-outline-var);
  border-radius: 12px;
  background: var(--color-v3-surface-container);
}

.output-format-option {
  display: flex;
  flex: 1;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 8px;
  border: none;
  border-radius: 8px;
  background: transparent;
  color: var(--color-v3-text-var);
  text-align: center;
  cursor: pointer;
  transition:
    color 0.2s ease,
    background-color 0.2s cubic-bezier(0.4, 0, 0.2, 1);
}

.output-format-option:hover:not(.active) {
  color: var(--color-v3-text);
}

.output-format-option.active {
  background: var(--color-v3-surface-container-highest);
  color: var(--color-v3-text);
}

.toggle-label {
  font-size: 14px;
  font-weight: 400;
  line-height: 21px;
}

.system-instructions-card.disabled-interactive {
  background: transparent;
  cursor: not-allowed;
}

.system-instructions-card.disabled-interactive :is(.title, .subtitle) {
  color: var(--color-v3-text-disable);
}

.toggle-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 4px;
  margin-block: 12px;
}

.label-container {
  flex: 1;
  min-width: 0;
}

.label {
  margin: 0;
  font-size: 14px;
  line-height: 21px;
}

.search-source {
  display: flex;
  align-items: center;
  gap: 4px;
  margin: 0;
  font-size: 11px;
  line-height: 18px;
}

.actions {
  display: flex;
  align-items: center;
  gap: 4px;
}

.edit-button {
  transform: translateY(2px);
}

.stop-sequences {
  margin-bottom: 8px;
}

.stop-input {
  --ms-input-width: 112px;
}

.chips {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  max-height: 140px;
  overflow-y: auto;
}

.chip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 28px;
  padding: 0 4px 0 8px;
  border: 1px solid var(--color-v3-outline-var);
  border-radius: 8px;
  font-size: 12px;
  line-height: 18px;
}

.chip-label {
  max-width: 150px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.chip-remove {
  display: flex;
  padding: 2px;
  border: 0;
  border-radius: 50%;
  background: none;
  color: inherit;
  cursor: pointer;
}

.output-length {
  --ms-input-width: 150px;
  flex-wrap: wrap;
}

:deep(.video-task-select) {
  width: 174px;
}

.setting-hint {
  width: 100%;
  margin: 4px 0 0;
  color: var(--color-v3-text-var);
  font-size: 12px;
  line-height: 18px;
}
</style>
