import '@fontsource-variable/inter'
import { createApp } from 'vue'
import ConsoleRoot from './ConsoleRoot.vue'
import { loadInitialLocale } from './i18n'
import { router } from './router'
import { vTooltip } from './tooltip'
import './style.css'

// warmCjkFont 在首帧绘制之后的两帧里各排版一个隐藏的汉字，常规与粗体的中文字体提前载入，之后首次显示中文时不再承担载入字体的耗时；汉字随帧排版，不在任务中强制同步布局
function warmCjkFont(): void {
  const probe = document.createElement('span')
  probe.textContent = '中'
  probe.setAttribute('aria-hidden', 'true')
  probe.style.cssText = 'position: fixed; visibility: hidden; pointer-events: none'
  const next = (step: () => void) => requestAnimationFrame(() => setTimeout(step))
  next(() => {
    document.body.prepend(probe)
    next(() => {
      probe.style.fontWeight = '700'
      next(() => probe.remove())
    })
  })
}

// 界面字体在入口求值时开始载入，首次排版时已就绪，排版中不再为等待网页字体载入系统回退字体
void document.fonts.load('1em "Inter Variable"').catch(() => [])

const app = createApp(ConsoleRoot).use(router).directive('tooltip', vTooltip)
void Promise.all([router.isReady(), loadInitialLocale()]).then(() => {
  app.mount('#app')
  warmCjkFont()
})
