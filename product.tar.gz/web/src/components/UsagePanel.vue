<script setup lang="ts">
import { computed, onActivated, onDeactivated, provide, ref, shallowRef, watch } from 'vue'
import { api } from '@/api'
import { useI18n } from '@/i18n'
import type { Model, UsageDimension, UsageReport, UsageStats } from '@/types'
import UiIcon from './UiIcon.vue'
import UiSelect, { keepSelected } from './UiSelect.vue'
import FilterMenu from './FilterMenu.vue'
import KpiCard from './usage/KpiCard.vue'
import RangePicker from './usage/RangePicker.vue'
import RankingTable from './usage/RankingTable.vue'
import RecordsTable from './usage/RecordsTable.vue'
import RefreshButton from './usage/RefreshButton.vue'
import UsageCharts from './usage/UsageCharts.vue'
import { usageClock, useUsageFormat } from './usage/format'
import { readPreference, writePreference } from '@/preference'
import {
  dimensions,
  liveRange,
  rateTone,
  resolveRange,
  successRate,
  useUsageState,
  type RangePreset,
} from './usage/model'

const props = defineProps<{ models: Model[] }>()
const { t, errorText } = useI18n()
const { compact, integer, usd, percent, duration, dateTime, dimensionLabel } = useUsageFormat()
const state = useUsageState()

// filterOptions 返回筛选候选，模型按模型目录顺序排列，目录外的取值排在最后
function filterOptions(dimension: UsageDimension): string[] {
  const options = report.value?.options[dimension] ?? []
  if (dimension !== 'model') return options
  const order = new Map(props.models.map((model, index) => [model.id, index]))
  const rank = (value: string) => order.get(value) ?? order.size
  return [...options].sort((left, right) => rank(left) - rank(right))
}
const report = shallowRef<UsageReport | null>(null)
const status = ref<'loading' | 'ready' | 'error'>('loading')
const loading = ref(false)
const error = ref('')
const updatedAt = ref(0)
const now = ref(Date.now())
provide(usageClock, now)
const recordsRefresh = ref(0)
const refreshChoices = [0, 15, 30, 60] as const
const autoRefresh = ref<number>(
  readPreference('usage.autoRefresh', 30, (value) =>
    refreshChoices.includes(value as (typeof refreshChoices)[number]),
  ),
)
watch(autoRefresh, (value) => writePreference('usage.autoRefresh', value))
const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone
let controller: AbortController | undefined
let clockTimer: number | undefined

// minute 是取整到分钟的时钟，时间范围只显示到分钟
const minute = computed(() => Math.floor(now.value / 60_000) * 60_000)
const resolved = computed(() => resolveRange(state, new Date(minute.value)))
const live = computed(() => liveRange(state.range))
const hasFilters = computed(() => dimensions.some((item) => (state.filters[item] ?? []).length > 0))
const scope = computed(() => JSON.stringify([state.range, state.from, state.to, state.filters]))

// baseQuery 在调用时解析时间范围并写入范围与筛选参数，自定义范围无效时返回 null
function baseQuery(): URLSearchParams | null {
  const range = resolveRange(state, new Date())
  if (range === null) return null
  const query = new URLSearchParams({ from: range.from.toISOString(), to: range.to.toISOString() })
  for (const dimension of dimensions) {
    const values = state.filters[dimension] ?? []
    if (values.length > 0) query.set(dimension, values.join(','))
  }
  return query
}

// load 读取用量报告，新的请求会取消尚未完成的旧请求
async function load(): Promise<void> {
  const query = baseQuery()
  if (query === null) {
    status.value = report.value === null ? 'error' : status.value
    error.value = t('usage.rangeInvalid')
    return
  }
  query.set('tz', timezone)
  query.set('stack', state.stack)
  query.set('pairs', '0')
  controller?.abort()
  const current = new AbortController()
  controller = current
  loading.value = true
  try {
    const value = await api.usage(query, current.signal)
    report.value = value
    status.value = 'ready'
    error.value = ''
    updatedAt.value = Date.now()
  } catch (reason) {
    if (current.signal.aborted) return
    error.value = errorText(reason)
    if (report.value === null) status.value = 'error'
  } finally {
    if (controller === current) loading.value = false
  }
}

// loadPairs 读取当前范围与筛选下一个账户或模型的组合明细，主报告不含组合明细
async function loadPairs(
  dimension: 'account' | 'model',
  key: string,
): Promise<UsageReport['pairs']> {
  const query = baseQuery()
  if (query === null) throw new Error(t('usage.rangeInvalid'))
  query.set(dimension, key)
  query.set('tz', timezone)
  query.set('stack', state.stack)
  return (await api.usage(query, new AbortController().signal)).pairs
}

// refresh 立即刷新报告与请求记录
function refresh(): void {
  void load()
  recordsRefresh.value++
}

watch(
  () => JSON.stringify([state.range, state.from, state.to, state.stack, state.filters]),
  () => void load(),
)

// tick 每秒更新时钟，到期且页面可见时自动刷新
function tick(): void {
  now.value = Date.now()
  if (
    autoRefresh.value > 0 &&
    live.value &&
    document.visibilityState === 'visible' &&
    !loading.value &&
    updatedAt.value > 0 &&
    now.value - updatedAt.value >= autoRefresh.value * 1000
  )
    refresh()
}

// resume 页面重新可见时补一次过期的刷新
function resume(): void {
  if (document.visibilityState === 'visible') tick()
}

onActivated(() => {
  if (report.value === null) void load()
  else tick()
  clockTimer = window.setInterval(tick, 1000)
  document.addEventListener('visibilitychange', resume)
})
onDeactivated(() => {
  controller?.abort()
  window.clearInterval(clockTimer)
  document.removeEventListener('visibilitychange', resume)
})

// applyRange 应用时间范围选择
function applyRange(range: RangePreset, from: string, to: string): void {
  Object.assign(state, { range, from, to })
}

// setFilter 替换一个维度的筛选值
function setFilter(dimension: UsageDimension, values: string[]): void {
  const filters = { ...state.filters }
  if (values.length === 0) delete filters[dimension]
  else filters[dimension] = values
  state.filters = filters
}

// addFilter 把取值加入维度筛选
function addFilter(dimension: UsageDimension, value: string): void {
  const values = state.filters[dimension] ?? []
  if (!values.includes(value)) setFilter(dimension, [...values, value])
}

// clearFilters 清除全部维度筛选
function clearFilters(): void {
  state.filters = {}
}

const activeChips = computed(() =>
  dimensions.flatMap((dimension) =>
    (state.filters[dimension] ?? []).map((value) => ({ dimension, value })),
  ),
)

// relative 返回相对变化比例，上一周期为 0 时返回 null
function relative(current: number, previous: number): number | null {
  return previous > 0 ? (current - previous) / previous : null
}

// delta 生成相对上一周期的变化标注
function delta(
  change: number | null,
  text: (value: number) => string,
  better: 'up' | 'down' | 'none',
):
  | {
      text: string
      tone: 'good' | 'bad' | 'neutral'
      direction: 'up' | 'down'
      help: string
    }
  | undefined {
  const value = report.value
  if (change === null || value === null || value.previous.requests === 0) return undefined
  const span = new Date(value.to).getTime() - new Date(value.from).getTime()
  const range = `${dateTime(new Date(new Date(value.from).getTime() - span))} – ${dateTime(value.from)}`
  const flat = Math.abs(change) < 0.0005
  return {
    text: `${change >= 0 ? '+' : '−'}${text(Math.abs(change))}`,
    tone: flat || better === 'none' ? 'neutral' : change > 0 === (better === 'up') ? 'good' : 'bad',
    direction: change >= 0 ? 'up' : 'down',
    help: t('usage.vsPrevious').replace('{range}', range),
  }
}

const kpis = computed(() => {
  const value = report.value
  if (value === null) return []
  const { totals, previous, buckets, recent } = value
  const rate = successRate(totals)
  const previousRate = successRate(previous)
  const series = (pick: (bucket: UsageStats) => number | null) =>
    buckets.map(pick).filter((item): item is number => item !== null)
  const otherErrors = totals.failed - totals.rate_limited
  const first = totals.first_event
  return [
    {
      label: t('usage.requests'),
      icon: 'requests' as const,
      value: integer(totals.requests),
      raw: totals.requests,
      help: t('usage.requestsHelp'),
      details: [
        {
          label: t('usage.failed'),
          value: integer(totals.failed),
          tone: totals.failed > 0 ? 'text-red-400' : undefined,
        },
        { label: t('usage.canceled'), value: integer(totals.canceled) },
      ],
      delta: delta(relative(totals.requests, previous.requests), (item) => percent(item), 'none'),
      spark: buckets.map((bucket) => bucket.requests),
      color: '#60a5fa',
    },
    {
      label: t('usage.successRate'),
      icon: 'success' as const,
      value: percent(rate),
      raw: rate,
      help: t('usage.successRateHelp'),
      details: [
        {
          label: t('usage.rateLimitedShort'),
          value: integer(totals.rate_limited),
          tone: totals.rate_limited > 0 ? 'text-yellow-400' : undefined,
        },
        {
          label: t('usage.otherErrors'),
          value: integer(otherErrors),
          tone: otherErrors > 0 ? 'text-red-400' : undefined,
        },
      ],
      delta: delta(
        rate === null || previousRate === null ? null : rate - previousRate,
        (item) => t('usage.points').replace('{value}', (item * 100).toFixed(1)),
        'up',
      ),
      spark: series((bucket) => {
        const item = successRate(bucket)
        return item === null ? null : item * 100
      }),
      color: '#22c55e',
      tone: rateTone(rate),
    },
    {
      label: t('usage.tokens'),
      icon: 'tokens' as const,
      value: compact(totals.total_tokens),
      raw: totals.total_tokens,
      help: `${t('usage.input')} + ${t('usage.output')}`,
      details: [
        { label: t('usage.input'), value: compact(totals.input_tokens) },
        { label: t('usage.cached'), value: compact(totals.cached_tokens) },
        { label: t('usage.output'), value: compact(totals.reasoning_tokens + totals.reply_tokens) },
      ],
      delta: delta(
        relative(totals.total_tokens, previous.total_tokens),
        (item) => percent(item),
        'none',
      ),
      spark: buckets.map((bucket) => bucket.total_tokens),
      color: '#2dd4bf',
    },
    {
      label: t('usage.throughput'),
      icon: 'throughput' as const,
      value: `${compact(recent.requests / recent.minutes)} RPM`,
      raw: recent.requests / recent.minutes,
      help: t('usage.throughputHelp').replace('{minutes}', String(recent.minutes)),
      details: [
        { label: t('usage.recentMinutes').replace('{minutes}', String(recent.minutes)), value: '' },
        { label: 'TPM', value: compact(recent.tokens / recent.minutes) },
      ],
      spark: buckets.map((bucket) => bucket.requests),
      color: '#f59e0b',
    },
    {
      label: t('usage.cost'),
      icon: 'cost' as const,
      value: value.cost === 0 && value.unpriced_models.length > 0 ? '—' : usd(value.cost),
      raw: value.cost === 0 && value.unpriced_models.length > 0 ? null : value.cost,
      help:
        value.unpriced_models.length > 0
          ? `${t('usage.costHelp')} · ${t('usage.unpriced')} ${value.unpriced_models.join(', ')}`
          : t('usage.costHelp'),
      details: [
        {
          label: t('usage.cacheHitRate'),
          value:
            totals.input_tokens > 0 ? percent(totals.cached_tokens / totals.input_tokens) : '—',
        },
        ...(value.cost === 0 && value.unpriced_models.length > 0
          ? [
              {
                label: t('usage.unpriced'),
                value: value.unpriced_models.join(', '),
                tone: 'text-amber-300',
              },
            ]
          : []),
      ],
      delta: delta(relative(value.cost, value.previous_cost), (item) => percent(item), 'none'),
      spark: buckets.map((bucket) => bucket.cost),
      color: '#34d399',
    },
    {
      label: `${t('usage.firstEvent')} P50`,
      icon: 'firstEvent' as const,
      value: duration(first.p50_ms),
      raw: first.p50_ms > 0 ? first.p50_ms : null,
      help: t('usage.firstEventHelp'),
      details: [{ label: 'P95', value: duration(first.p95_ms) }],
      delta: delta(
        relative(first.p50_ms, previous.first_event.p50_ms),
        (item) => percent(item),
        'down',
      ),
      spark: series((bucket) => (bucket.first_event.p50_ms > 0 ? bucket.first_event.p50_ms : null)),
      color: '#a78bfa',
    },
  ]
})

const statusOptions = computed(() =>
  keepSelected(
    (report.value?.groups.status ?? []).map((group) => group.key).sort(),
    state.status,
    '',
  ),
)
</script>

<template>
  <section class="flex min-h-0 flex-1 flex-col overflow-auto [scrollbar-gutter:stable]">
    <header class="page-x flex flex-wrap items-center gap-3 border-b border-line py-4">
      <div class="min-w-0 flex-1">
        <h2 class="text-xl font-semibold text-white">{{ t('usage.title') }}</h2>
        <p class="mt-1 text-sm text-gray-500">{{ t('usage.description') }}</p>
      </div>
      <div class="flex h-10 items-stretch rounded border border-line text-sm">
        <RefreshButton
          :loading="loading"
          :live="live"
          :updated-at="updatedAt"
          :latest-at="report?.latest_at"
          @refresh="refresh"
        />
        <UiSelect
          v-if="live"
          :model-value="autoRefresh"
          :aria-label="t('usage.autoRefresh')"
          class="w-max rounded-r border-l border-line px-3 text-gray-200 hover:bg-raised"
          @update:model-value="autoRefresh = Number($event)"
        >
          <option v-for="choice in refreshChoices" :key="choice" :value="choice">
            {{ t(`usage.autoRefresh.${choice}`) }}
          </option>
        </UiSelect>
      </div>
    </header>

    <div
      class="page-x sticky top-0 z-10 flex flex-wrap items-center gap-2 border-b border-line bg-canvas/95 py-2.5 backdrop-blur"
      role="toolbar"
      :aria-label="t('usage.filters')"
    >
      <RangePicker :range="state.range" :resolved="resolved" @apply="applyRange" />
      <span class="mx-1 hidden h-5 w-px bg-line sm:block" aria-hidden="true"></span>
      <FilterMenu
        v-for="dimension in dimensions"
        :key="dimension"
        :label="t(`usage.dimension.${dimension}`)"
        :options="filterOptions(dimension)"
        :selected="state.filters[dimension] ?? []"
        :format="(value: string) => dimensionLabel(dimension, value)"
        :search-label="t('usage.filterSearch')"
        :empty-label="t('usage.filterNone')"
        :clear-label="t('usage.filtersClear')"
        @change="setFilter(dimension, $event)"
      />
      <button
        v-if="hasFilters"
        type="button"
        class="rounded-md px-2 py-1.5 text-xs text-gray-400 hover:bg-raised hover:text-white"
        @click="clearFilters"
      >
        {{ t('usage.filtersClear') }}
      </button>
    </div>
    <div v-if="activeChips.length > 0" class="page-x flex flex-wrap gap-1.5 pt-3">
      <span
        v-for="chip in activeChips"
        :key="`${chip.dimension}:${chip.value}`"
        class="flex max-w-full items-center gap-1 rounded-md border border-blue-500/40 bg-blue-600/10 py-0.5 pr-1 pl-2.5 text-xs text-blue-200"
      >
        <span class="shrink-0 text-blue-300/70">{{ t(`usage.dimension.${chip.dimension}`) }}:</span>
        <span
          v-tooltip.overflow="dimensionLabel(chip.dimension, chip.value)"
          class="min-w-0 truncate"
          >{{ dimensionLabel(chip.dimension, chip.value) }}</span
        >
        <button
          type="button"
          class="shrink-0 rounded-sm p-0.5 hover:bg-blue-500/20"
          :aria-label="`${t('common.close')} ${dimensionLabel(chip.dimension, chip.value)}`"
          @click="
            setFilter(
              chip.dimension,
              (state.filters[chip.dimension] ?? []).filter((item) => item !== chip.value),
            )
          "
        >
          <UiIcon name="close" :size="11" />
        </button>
      </span>
    </div>

    <div class="@container page-x space-y-4 py-4 md:py-8">
      <div
        v-if="error && status !== 'error'"
        class="flex items-center gap-3 rounded-lg border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-300"
        role="alert"
      >
        <UiIcon name="warning" :size="16" />
        <span class="flex-1">{{ error }}</span>
        <button
          type="button"
          class="rounded-md border border-red-500/40 px-3 py-1 text-xs hover:bg-red-500/10"
          @click="load()"
        >
          {{ t('usage.retry') }}
        </button>
      </div>

      <template v-if="status === 'loading'">
        <div
          class="grid grid-cols-1 gap-3 @min-[37rem]:grid-cols-2 @min-[56rem]:grid-cols-3 @min-[110rem]:grid-cols-6"
          aria-hidden="true"
        >
          <div v-for="index in 6" :key="index" class="h-32 animate-pulse rounded-lg bg-panel"></div>
        </div>
        <div class="h-80 animate-pulse rounded-lg bg-panel" aria-hidden="true"></div>
        <p class="sr-only" role="status">{{ t('common.loading') }}</p>
      </template>

      <div
        v-else-if="status === 'error'"
        class="flex flex-col items-center gap-3 rounded-lg border border-red-500/40 bg-red-500/5 px-6 py-16 text-center"
        role="alert"
      >
        <UiIcon name="warning" :size="28" class="text-red-400" />
        <p class="text-sm text-red-300">{{ error }}</p>
        <button
          type="button"
          class="rounded-md border border-red-500/40 px-3 py-1 text-xs text-red-200 hover:bg-red-500/10"
          @click="load()"
        >
          {{ t('usage.retry') }}
        </button>
      </div>

      <template v-else-if="report !== null">
        <div class="space-y-4" :aria-busy="loading">
          <div
            v-if="report.totals.requests === 0"
            class="flex flex-col items-center justify-center rounded-lg border border-dashed border-line px-6 py-20 text-center"
          >
            <UiIcon name="empty" :size="40" class="mb-3 text-gray-600" />
            <p class="text-sm font-medium text-gray-300">
              {{ hasFilters ? t('usage.emptyFiltered') : t('usage.empty') }}
            </p>
            <p class="mt-1 max-w-md text-xs text-gray-500">
              {{ hasFilters ? t('usage.emptyFilteredHelp') : t('usage.emptyHelp') }}
            </p>
            <button
              v-if="hasFilters"
              type="button"
              class="mt-4 rounded-md border border-line px-3 py-1.5 text-xs text-gray-300 hover:bg-raised"
              @click="clearFilters"
            >
              {{ t('usage.filtersClear') }}
            </button>
          </div>
          <template v-else>
            <div
              class="grid grid-cols-1 gap-3 @min-[37rem]:grid-cols-2 @min-[56rem]:grid-cols-3 @min-[110rem]:grid-cols-6"
            >
              <KpiCard
                v-for="kpi in kpis"
                :key="kpi.label"
                :label="kpi.label"
                :icon="kpi.icon"
                :value="kpi.value"
                :raw="kpi.raw"
                :help="kpi.help"
                :details="kpi.details"
                :delta="kpi.delta"
                :spark="kpi.spark"
                :color="kpi.color"
                :tone="kpi.tone"
              />
            </div>
            <UsageCharts
              :report="report"
              :stack="state.stack"
              @update:stack="state.stack = $event"
            />
            <RankingTable
              :report="report"
              :load-pairs="loadPairs"
              @filter="addFilter"
              @status="state.status = $event"
            />
            <RecordsTable
              :scope="scope"
              :base-query="baseQuery"
              :status="state.status"
              :search="state.search"
              :total="report.totals.requests"
              :status-options="statusOptions"
              :refresh-key="recordsRefresh"
              @update:status="state.status = $event"
              @update:search="state.search = $event"
            />
          </template>
        </div>
      </template>
    </div>
  </section>
</template>
