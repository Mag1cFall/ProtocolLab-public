<script setup lang="ts">
import { computed } from 'vue'
import { useI18n, type TranslationKey } from '@/i18n'
import { isBlockField } from '@/logs'
import type { AdminLog } from '@/types'

const props = withDefaults(
  defineProps<{ entry: AdminLog; message?: boolean; part?: 'all' | 'inline' | 'block' }>(),
  { message: true, part: 'all' },
)
const { t, logText } = useI18n()

// valueKeys 是取值为固定类型的字段及其取值翻译键的前缀，没有对应翻译的取值原样显示
const valueKeys: Partial<Record<string, string>> = {
  first_event: 'logs.event',
  last_event: 'logs.event',
  current_event: 'logs.event',
  mode: 'logs.mode',
  channel: 'channel',
}

// fieldValue 返回字段取值按界面语言显示的文字
function fieldValue(key: string, value: string): string {
  const prefix = valueKeys[key]
  return (prefix && t(`${prefix}.${value}` as TranslationKey)) || logText(value)
}

// fields 是按界面语言显示的字段：part 为 inline 时只取与消息同行的短字段，为 block 时只取另起一行的长字段
const fields = computed(() =>
  (props.entry.fields ?? [])
    .filter((field) => props.part === 'all' || isBlockField(field) === (props.part === 'block'))
    .map((field) => ({
      key: field.key,
      label: t(`logs.field.${field.key}` as TranslationKey) ?? field.key,
      value: fieldValue(field.key, field.value),
      block: isBlockField(field),
    })),
)
</script>

<template>
  <span v-if="message" class="log-line-message">{{ logText(entry.message) }}</span
  ><slot />
  <template v-for="(field, index) in fields" :key="field.key"
    >{{ message || index > 0 ? ' ' : ''
    }}<span
      class="log-field"
      :class="{ 'log-field-block': field.block, 'log-field-error': field.key === 'error' }"
      ><span class="log-field-key">{{ field.label }}</span
      >&nbsp;{{ field.value }}</span
    ></template
  >
</template>

<style>
/* 日志字段为浅色字段名加取值，字段之间靠间距分隔，日志页的消息、阶段卡片与请求卡片共用 */
.log-line-message {
  margin-inline-end: 8px;
  color: var(--color-fg);
}
/* 字段名不断行，与取值以不换行空格相连，换行只发生在字段之间或取值之内 */
.log-field {
  margin-inline-end: 8px;
  color: var(--color-gray-300);
  font-variant-numeric: tabular-nums;
}
.log-field-key {
  color: var(--color-gray-500);
  white-space: nowrap;
}
.log-field-block {
  display: block;
  margin-inline-end: 0;
}
.log-field-error {
  color: var(--color-red-300);
}
</style>
