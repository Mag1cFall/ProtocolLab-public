module github.com/Mag1cFall/AIStudio2API

go 1.27.3

require (
	github.com/HugoSmits86/nativewebp v1.3.0
	github.com/Mag1cFall/fhttp v0.6.8-firefox.2
	github.com/Mag1cFall/go-mp3 v0.1.1
	github.com/Mag1cFall/go-sentencepiece v0.7.1
	github.com/Mag1cFall/uquic v0.0.6-firefox.6
	github.com/Mag1cFall/utls v1.8.2-firefox.3
	github.com/bogdanfinn/fhttp v0.6.8
	github.com/bogdanfinn/tls-client v1.15.1
	github.com/bogdanfinn/utls v1.7.7-barnius
	github.com/brainplusplus/go-browserforge v0.1.0
	github.com/dlclark/regexp2/v2 v2.5.2
	github.com/godbus/dbus/v5 v5.2.2
	github.com/gofrs/flock v0.13.0
	github.com/google/uuid v1.6.0
	github.com/gorilla/websocket v1.5.3
	github.com/klauspost/compress v1.20.1
	github.com/mattn/go-sqlite3 v1.14.52
	github.com/mewkiz/flac v1.0.14
	github.com/minio/selfupdate v0.6.0
	github.com/modelcontextprotocol/go-sdk v1.8.0
	github.com/nlnwa/whatwg-url v0.6.2
	github.com/oschwald/maxminddb-golang/v2 v2.9.0
	github.com/santhosh-tekuri/jsonschema/v6 v6.0.3
	github.com/shirou/gopsutil/v4 v4.26.9
	github.com/thesyncim/gopus v0.2.3
	github.com/tphakala/go-aac v0.7.2
	github.com/vearutop/statigz v1.5.0
	github.com/wailsapp/wails/v3 v3.0.0-beta.29
	github.com/zaf/g711 v1.4.0
	golang.org/x/crypto/x509roots/fallback v0.0.0-20261030153154-30a33513ff6d
	golang.org/x/image v0.41.0
	golang.org/x/mod v0.42.0
	golang.org/x/net v0.60.0
	golang.org/x/sync v0.24.0
	golang.org/x/sys v0.49.0
	golang.org/x/text v0.42.0
	gopkg.in/natefinch/lumberjack.v2 v2.2.1
)

require (
	aead.dev/minisign v0.2.0 // indirect
	github.com/adrg/xdg v0.5.3 // indirect
	github.com/andybalholm/brotli v1.2.0 // indirect
	github.com/bdandy/go-errors v1.2.2 // indirect
	github.com/bdandy/go-socks4 v1.2.3 // indirect
	github.com/bits-and-blooms/bitset v1.20.0 // indirect
	github.com/bogdanfinn/quic-go-utls v1.0.9-utls // indirect
	github.com/bogdanfinn/websocket v1.5.5-barnius // indirect
	github.com/coder/websocket v1.8.14 // indirect
	github.com/ebitengine/purego v0.11.1 // indirect
	github.com/go-ole/go-ole v1.3.0 // indirect
	github.com/google/jsonschema-go v0.4.3 // indirect
	github.com/icza/bitio v1.1.0 // indirect
	github.com/lufia/plan9stats v0.0.0-20211012122336-39d0f177ccd0 // indirect
	github.com/mattn/go-colorable v0.1.14 // indirect
	github.com/mattn/go-isatty v0.0.24 // indirect
	github.com/mewkiz/pkg v0.0.0-20250417130911-3f050ff8c56d // indirect
	github.com/mewpkg/term v0.0.0-20241026122259-37a80af23985 // indirect
	github.com/molecule-man/go-brrr v1.2.0 // indirect
	github.com/power-devops/perfstat v0.0.0-20260805114148-88456608a4f6 // indirect
	github.com/quic-go/qpack v0.6.0 // indirect
	github.com/segmentio/asm v1.1.3 // indirect
	github.com/segmentio/encoding v0.5.4 // indirect
	github.com/tam7t/hpkp v0.0.0-20160821193359-2b70b4024ed5 // indirect
	github.com/tklauser/go-sysconf v0.4.0 // indirect
	github.com/tklauser/numcpus v0.12.0 // indirect
	github.com/tphakala/simd v1.15.0 // indirect
	github.com/yosida95/uritemplate/v3 v3.0.2 // indirect
	github.com/yusufpapurcu/wmi v1.2.4 // indirect
	golang.org/x/crypto v0.57.0 // indirect
	golang.org/x/oauth2 v0.35.0 // indirect
	golang.org/x/time v0.15.0 // indirect
	google.golang.org/protobuf v1.36.6 // indirect
)
